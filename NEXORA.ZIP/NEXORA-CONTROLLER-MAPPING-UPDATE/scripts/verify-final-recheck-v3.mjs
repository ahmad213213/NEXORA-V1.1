import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const checks = [];
function ok(name, cond) { checks.push([name, !!cond]); if (!cond) throw new Error(`FAIL: ${name}`); }
const html = read('apps/host/src/ui/index.html');
const js = read('apps/host/src/ui/app.js');
const settings = read('apps/host/src/ui/settings-store.js');
const main = read('apps/host/src/main.ts');
const rtc = read('apps/receiver/android/app/src/main/java/com/nexora/receiver/webrtc/WebRtcReceiver.kt');
const manifest = read('apps/receiver/android/app/src/main/AndroidManifest.xml');
const widx = read('apps/host/src/webrtc/index.ts');
const win = read('apps/host/src/input/windows-send-input.ts');
const media = read('apps/host/src/webrtc/media-bridge.ts');
const winsink = read('apps/host/src/input/windows-send-input.ts');

// UI checks intentionally follow the user's exact uploaded renderer tree.
ok('original Add Game flow exists in renderer', html.includes('data-preview-empty-add') && js.includes('async function handleAddGame') && js.includes('nexora-add-overlay'));
ok('original Desktop and Console navigation exists', html.includes('data-view="dashboard"') && html.includes('data-view="remoteplay"') && html.includes('>Home</span>') && html.includes('>Remote Play</span>'));
ok('original Controls and Key Mapping surface exists', html.includes('data-view="controls"') && html.includes('id="mapping-list"') && html.includes('id="mapping-save-status"'));
ok('original Settings modules own update UI', !html.includes('id="update-check"') && settings.includes('Check for updates'));
ok('no stale Part 4/5 promises in renderer', !js.includes('will connect in Part 4') && !js.includes('will connect in Part 5'));
ok('default layouts initialized', main.includes('await layoutController.ensureDefaults()'));
ok('WebRTC index uses NodeNext-safe extension', widx.includes("'./peer-session.js'"));
ok('Android Internet permission', manifest.includes('android.permission.INTERNET'));
ok('Android WebRTC initialization is guarded', rtc.includes('initializeFactory(context)') && rtc.includes('Volatile private var initialized'));
ok('Windows input does not silently succeed', win.includes('Native Windows SendInput provider is not installed'));
ok('no obvious secret key material', !/-----BEGIN (RSA|EC|OPENSSH|PRIVATE) KEY-----/.test(read('README.md')));
// Original renderer keeps a single selected-game object and uses a first-game fallback only when no prior selection survives.
ok('selected game state is initialized before renderer handlers', /let selectedGame = null;/.test(js) && js.indexOf('let selectedGame = null;') < js.indexOf('function renderConsoleLibrary'));
ok('console selection retains the current game before falling back', /clean\.find\(x => x\.id === selectedId\)\s*\|\|\s*clean\[0\]/.test(js));
ok('remove flow clears selection before refreshing the library', /selectedGame = null;[\s\S]{0,220}renderHomeLibrary\(currentGames\)/.test(js));
ok('WebRtcMediaBridge exists and is honest about readiness', media.includes('class WebRtcMediaBridge') && media.includes('get ready()'));
ok('WindowsInputSink uses optional native loader', winsink.includes('nexora-sendinput') && winsink.includes('get available()'));
console.log(checks.map(([n, p]) => `${p ? 'PASS' : 'FAIL'} ${n}`).join('\n'));
console.log(`${checks.filter(x => x[1]).length}/${checks.length} PASS`);
