import { readFile } from 'node:fs/promises';
import path from 'node:path';

const root = new URL('..', import.meta.url).pathname;
const read = file => readFile(path.join(root, file), 'utf8');
const checks = [];
const expect = (name, value) => { if (!value) throw new Error(`FAIL: ${name}`); checks.push(name); console.log(`PASS: ${name}`); };

const library = await read('apps/host/src/library.ts');
const metadata = await read('apps/host/src/metadata.ts');
const controller = await read('apps/host/src/library-controller.ts');
const provider = await read('apps/host/src/steam-provider.ts');
const preload = await read('apps/host/src/preload.cts');
const main = await read('apps/host/src/main.ts');
const ui = await read('apps/host/src/ui/app.js');
const html = await read('apps/host/src/ui/index.html');

expect('pending game before verification', /status: 'pending'/.test(library));
expect('Windows EXE validation', /WINDOWS_EXE/.test(library));
expect('global metadata ranking', /rankGlobally/.test(metadata));
expect('metadata acceptance gate', /acceptanceGate/.test(metadata));
expect('image signature validation', /detectCoverMime/.test(metadata));
expect('ambiguous candidate retention', /status === 'ambiguous'/.test(controller));
expect('atomic library persistence', /saveLibrary\(this\.games\)/.test(controller));
expect('Steam HTTPS provider', /store\.steampowered\.com/.test(provider));
expect('cover host allowlist', /COVER_HOSTS/.test(provider));
expect('library IPC bridge', /library:add-dialog/.test(preload) && /library:list/.test(preload));
expect('trusted IPC remains enforced', /isTrustedSender/.test(main));
expect('real add-game UI', /data-preview-empty-add/.test(html) && /async function handleAddGame/.test(ui) && /nexora-add-overlay/.test(ui));
expect('no HTML interpolation for game data', /textContent/.test(ui));

console.log(`Part 3 verification: ${checks.length}/${checks.length}`);
