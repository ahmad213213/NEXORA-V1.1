import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const required = [
  'package.json', 'pnpm-workspace.yaml', 'apps/host/package.json',
  'apps/host/src/main.ts', 'apps/host/src/preload.cts',
  'apps/host/src/ui/index.html', 'apps/host/src/ui/styles.css',
  'apps/host/src/ui/app.js', 'apps/host/src/ui/assets/dualsense-mode.svg',
  'packages/shared/package.json', 'packages/shared/src/index.ts',
  'apps/receiver/android/app/src/main/AndroidManifest.xml',
  'PREVIEW.bat',
  'design-reference/current-frosted-glass-ui-prototype/index.html',
  'design-reference/current-frosted-glass-ui-prototype/app.js',
  'design-reference/current-frosted-glass-ui-prototype/styles.css',
  'design-reference/previews/preview-desktop.png',
  'docs/PHASE0-RECHECK-REPORT.md',
  'docs/BUILD-AND-TEST-GUIDE.md',
  'docs/PHASE0-SOURCE-INVENTORY.csv',
  'docs/PHASE0-BASELINE-IDENTITY.md',
  'PHASE0-RECHECKED-PACKAGE-MANIFEST.sha256',
  'baseline/NEXORA-V1-UPLOADED-ARCHIVE-UNMODIFIED.zip',
  'baseline/NEXORA-PHASE1-UI-RESTORED-SOURCE-BASELINE-UNMODIFIED.zip',
];
let failed = 0;
const ok = (msg) => console.log(`PASS  ${msg}`);
const fail = (msg) => { console.error(`FAIL  ${msg}`); failed++; };
const warn = (msg) => console.warn(`WARN  ${msg}`);

console.log('NEXORA cumulative source preflight (Phase 0/1)');
console.log(`Project: ${root}`);
for (const rel of required) {
  if (fs.existsSync(path.join(root, rel))) ok(`required file: ${rel}`);
  else fail(`missing required file: ${rel}`);
}

for (const rel of ['package.json', 'apps/host/package.json', 'packages/shared/package.json']) {
  try { JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8')); ok(`valid JSON: ${rel}`); }
  catch (e) { fail(`invalid JSON: ${rel} (${e.message})`); }
}

const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (packageJson.packageManager === 'pnpm@10.17.1') ok('package manager is pinned to pnpm@10.17.1');
else fail(`unexpected packageManager: ${packageJson.packageManager ?? '(missing)'}`);
if (packageJson.devDependencies?.['electron-builder'] === '26.0.12') ok('electron-builder version is pinned locally to 26.0.12');
else fail('electron-builder is not pinned to 26.0.12 as expected');
const testScript = String(packageJson.scripts?.test ?? '');
if (/pnpm\s+build\s*&&\s*node\s+--test/.test(testScript)) ok('root test script builds both workspace packages before running tests');
else fail('root test script must build the workspace before running tests');

const previewBat = fs.readFileSync(path.join(root, 'PREVIEW.bat'), 'utf8');
if (/apps\\host\\src\\ui\\index\.html/i.test(previewBat)) ok('PREVIEW.bat opens the live Electron renderer');
else fail('PREVIEW.bat does not target the live Electron renderer');
for (const rel of ['make-installer.bat', 'Make-Program.bat', 'Bootstrap-Phase0.bat']) {
  if (fs.existsSync(path.join(root, rel))) fail(`${rel} should be deferred in this Phase 1 source-only package`);
}
ok('program-build, dependency-bootstrap, and installer BAT files are deferred; PREVIEW.bat is the only root BAT file');

const baselineArtifacts = [
  { path: 'baseline/NEXORA-V1-UPLOADED-ARCHIVE-UNMODIFIED.zip', bytes: 5377893, sha256: '217cff3f1edff82035fb8556298e23f5e89dba70e10c641ae41a5d4284acca7f' },
  { path: 'baseline/NEXORA-PHASE1-UI-RESTORED-SOURCE-BASELINE-UNMODIFIED.zip', bytes: 11962805, sha256: '2f8900951339ca074d1b2438df2902435334bed63047c078a2fe7a0aa6644175' },
];
for (const baseline of baselineArtifacts) {
  const target = path.join(root, baseline.path);
  if (!fs.existsSync(target)) { fail(`missing immutable baseline: ${baseline.path}`); continue; }
  const bytes = fs.statSync(target).size;
  const sha = createHash('sha256').update(fs.readFileSync(target)).digest('hex');
  if (bytes === baseline.bytes && sha === baseline.sha256) ok(`immutable baseline verified: ${baseline.path}`);
  else fail(`immutable baseline identity mismatch: ${baseline.path} (bytes=${bytes}, sha256=${sha})`);
}

const deliveryManifest = path.join(root, 'PHASE0-RECHECKED-PACKAGE-MANIFEST.sha256');
if (fs.existsSync(deliveryManifest)) {
  const entries = fs.readFileSync(deliveryManifest, 'utf8').split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  let checked = 0;
  for (const entry of entries) {
    const match = entry.match(/^([a-f0-9]{64})\s+(.+)$/i);
    if (!match) { fail(`invalid delivery manifest line: ${entry}`); continue; }
    const [, expected, rel] = match;
    const target = path.resolve(root, rel);
    if (!(target === root || target.startsWith(root + path.sep))) { fail(`delivery manifest path escapes project root: ${rel}`); continue; }
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) { fail(`delivery manifest file missing: ${rel}`); continue; }
    const actual = createHash('sha256').update(fs.readFileSync(target)).digest('hex');
    if (actual !== expected.toLowerCase()) fail(`delivery manifest hash mismatch: ${rel}`);
    else checked++;
  }
  if (checked === entries.length) ok(`delivery SHA-256 manifest: ${checked}/${entries.length} entries verified`);
} else {
  fail('delivery SHA-256 manifest is missing');
}

const renderer = path.join(root, 'apps/host/src/ui/app.js');
const check = spawnSync(process.execPath, ['--check', renderer], { encoding: 'utf8' });
if (check.status === 0) ok('live Electron renderer JavaScript syntax');
else fail(`live renderer syntax check failed: ${(check.stderr || check.stdout).trim()}`);

const htmlPath = path.join(root, 'apps/host/src/ui/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
let refs = 0;
for (const [, value] of html.matchAll(/(?:src|href)=["']([^"']+)["']/g)) {
  if (/^(?:#|https?:|data:|mailto:|javascript:)/i.test(value)) continue;
  refs++;
  const resolved = path.resolve(path.dirname(htmlPath), value);
  if (fs.existsSync(resolved)) ok(`live UI asset: ${value}`);
  else fail(`missing live UI asset: ${value}`);
}
console.log(`Live UI local asset references checked: ${refs}`);

const lock = path.join(root, 'pnpm-lock.yaml');
if (fs.existsSync(lock)) ok('pnpm-lock.yaml exists');
else warn('pnpm-lock.yaml is not included; generate it during a later build phase on a network-enabled machine');

const nm = path.join(root, 'node_modules');
if (fs.existsSync(nm)) warn('node_modules is present in the source folder; do not distribute it or rely on it as the dependency source');
else ok('source package excludes node_modules');

if (failed) {
  console.error(`\nPreflight failed: ${failed} issue(s).`);
  process.exitCode = 1;
} else {
  console.log('\nPreflight passed. Warnings, if any, are listed above; this is a structural check, not an Electron/NSIS runtime certification.');
}
