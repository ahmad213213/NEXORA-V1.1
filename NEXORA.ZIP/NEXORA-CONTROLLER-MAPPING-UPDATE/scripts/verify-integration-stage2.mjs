import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const checks = [];
const must = (p) => { const ok=fs.existsSync(path.join(root,p)); checks.push(ok); if(!ok) throw new Error(`missing ${p}`); };
must('apps/host/src/webrtc/peer-session.ts');
must('apps/host/src/webrtc/index.ts');
must('apps/host/test/webrtc-peer-session.test.mjs');
must('apps/receiver/android/app/src/main/java/com/nexora/receiver/webrtc/WebRtcReceiver.kt');
must('docs/INTEGRATION-STAGE2-WEBRTC.md');
const gradle=fs.readFileSync(path.join(root,'apps/receiver/android/app/build.gradle.kts'),'utf8');
checks.push(gradle.includes('org.webrtc:google-webrtc:1.0.32006')); if(!checks.at(-1)) throw new Error('WebRTC dependency not pinned');
const host=fs.readFileSync(path.join(root,'apps/host/src/webrtc/peer-session.ts'),'utf8');
for(const x of ['256 * 1024','generation','setRemoteDescription','addIceCandidate']) { const ok=host.includes(x); checks.push(ok); if(!ok) throw new Error(`missing WebRTC guard ${x}`); }
console.log(`Integration Stage 2 verification: ${checks.filter(Boolean).length}/${checks.length} PASS`);
