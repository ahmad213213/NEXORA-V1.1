import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const required=[
 'apps/host/src/integration/session-orchestrator.ts',
 'apps/host/src/streaming/capture-engine.ts',
 'apps/host/src/networking/signaling-client.ts',
 'apps/host/src/networking/session-security.ts',
 'apps/host/src/input/input-manager.ts',
 'docs/INTEGRATION-STAGE-1.md',
 'apps/host/test/integration-boundary.test.mjs'
];
for(const f of required){if(!fs.existsSync(path.join(root,f))) throw new Error(`missing ${f}`)}
const s=fs.readFileSync(path.join(root,'apps/host/src/integration/session-orchestrator.ts'),'utf8');
for(const token of ['PeerMediaTransport','generation','activeSession','CaptureEngine','InputManager']) if(!s.includes(token)) throw new Error(`missing integration token ${token}`);
const arch=fs.readFileSync(path.join(root,'docs/ARCHITECTURE.md'),'utf8');
if(!arch.includes('Part 4 streaming boundary')||!arch.includes('Part 5 networking/security boundary')) throw new Error('architecture boundary regression');
console.log('Integration Stage 1 verification: 7/7 PASS');
