import { readFile, access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = [
  'apps/host/src/main.ts','apps/host/src/preload.cts','apps/host/src/config.ts','apps/host/src/lifecycle.ts',
  'apps/host/src/runtime.ts','apps/host/src/placeholder.html','packages/shared/src/protocol.ts','packages/shared/src/identity.ts',
  'apps/receiver/android/app/src/main/AndroidManifest.xml','apps/receiver/android/app/src/main/java/com/nexora/receiver/MainActivity.kt',
  'apps/receiver/android/app/src/main/res/layout/activity_main.xml','docs/OLD-PROJECT-COMPATIBILITY.md'
];
for (const file of files) await access(path.join(root, file));
const main = await readFile(path.join(root, 'apps/host/src/main.ts'), 'utf8');
const protocol = await readFile(path.join(root, 'packages/shared/src/protocol.ts'), 'utf8');
const manifest = await readFile(path.join(root, 'apps/receiver/android/app/src/main/AndroidManifest.xml'), 'utf8');
const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
const checks = [
  ['Electron isolation', /contextIsolation:\s*true/.test(main) && /nodeIntegration:\s*false/.test(main) && /sandbox:\s*true/.test(main)],
  ['IPC sender guard', /event\.sender === mainWindow\.webContents/.test(main)],
  ['Lifecycle guard', /lifecycle\.canAcceptWork\(\)/.test(main)],
  ['Awaitable shutdown', /lifecycle\.shutdown\(/.test(main) && /\.then\(\(\) => app\.exit\(0\)\)/.test(main)],
  ['Strict session states', /SESSION_TRANSITIONS/.test(protocol) && /created/.test(protocol) && /negotiating/.test(protocol) && /connected/.test(protocol) && /disconnected/.test(protocol) && /closed/.test(protocol)],
  ['Android landscape', /android:screenOrientation="landscape"/.test(manifest)],
  ['Pinned toolchain versions', pkg.packageManager === 'pnpm@10.17.1' && pkg.devDependencies?.electron === '38.2.0' && pkg.devDependencies?.typescript === '5.9.2']
];
for (const [name, ok] of checks) { if (!ok) throw new Error(`FAIL: ${name}`); console.log(`PASS: ${name}`); }
console.log(`Foundation verification: ${checks.length}/${checks.length}`);
