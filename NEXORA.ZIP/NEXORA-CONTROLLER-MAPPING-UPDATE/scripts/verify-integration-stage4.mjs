import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const checks = [
 ['connection flow exists', fs.existsSync(path.join(root,'apps/host/src/integration/connection-flow.ts'))],
 ['connection flow exports', fs.readFileSync(path.join(root,'apps/host/src/integration/index.ts'),'utf8').includes('connection-flow')],
 ['signed SDP signaling', fs.readFileSync(path.join(root,'apps/host/src/integration/connection-flow.ts'),'utf8').includes("sendSession('sdp.offer'")],
 ['signed ICE signaling', fs.readFileSync(path.join(root,'apps/host/src/integration/connection-flow.ts'),'utf8').includes("sendSession('ice.candidate'")],
 ['media starts only through orchestrator', fs.readFileSync(path.join(root,'apps/host/src/integration/connection-flow.ts'),'utf8').includes('await this.media.start(id)')],
 ['media is not sent to signaling', !fs.readFileSync(path.join(root,'apps/host/src/integration/connection-flow.ts'),'utf8').includes('sendVideoRtp')],
 ['generation protection', fs.readFileSync(path.join(root,'apps/host/src/integration/connection-flow.ts'),'utf8').includes('this.generation')],
 ['close tears down peer', fs.readFileSync(path.join(root,'apps/host/src/integration/connection-flow.ts'),'utf8').includes('await peer.close()')],
 ['close tears down media', fs.readFileSync(path.join(root,'apps/host/src/integration/connection-flow.ts'),'utf8').includes('await this.media.stop()')],
 ['docs present', fs.existsSync(path.join(root,'docs/INTEGRATION-STAGE4-CONNECTION.md'))],
 ['receiver signaling validator', fs.existsSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/connection/SignalingMessage.kt'))],
 ['receiver connection controller', fs.existsSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/connection/ConnectionController.kt'))],
 ['receiver media boundary', fs.readFileSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/connection/ConnectionController.kt'),'utf8').includes('WebRtcReceiver')],
];
let ok=0; for(const [n,v] of checks){ console.log(`${v?'PASS':'FAIL'} ${n}`); if(v)ok++; }
console.log(`Stage 4 verification: ${ok}/${checks.length}`); if(ok!==checks.length) process.exit(1);
