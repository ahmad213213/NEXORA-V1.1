# NEXORA Windows Release Checklist

1. Build the Host on Windows with the pinned toolchain.
2. Bundle `vendor/ffmpeg.exe` in the production build.
3. Produce `NEXORA-Host.exe` and all Electron resources.
4. Package with `package-portable.ps1`.
5. Generate a manifest with `create-manifest.mjs`.
6. Sign the manifest with `sign-manifest.mjs` using the offline Ed25519 private key.
7. Publish the ZIP and manifest over HTTPS.
8. Configure `NEXORA_UPDATE_PUBLIC_KEY_B64` and `NEXORA_UPDATE_MANIFEST_URL` in the release build.
9. Test update from the previous release on a writable Windows install.
10. Test update under `Program Files` and confirm UAC elevation.
11. Test a deliberately corrupted ZIP and confirm the old installation remains intact.
12. Test cancellation/failure before release.
