// Bundles the compiled @nexora/shared package INSIDE the app's dist folder and rewrites the
// bare '@nexora/shared' imports to relative paths. This removes any dependence on node_modules
// inside the packaged app (electron-builder may prune undeclared packages).
//
// usage: node vendor-shared.mjs <stagedAppDir> <sharedDistDir>
import { cp, readdir, readFile, writeFile, stat } from 'node:fs/promises';
import path from 'node:path';

const [appDir, sharedDist] = process.argv.slice(2);
if (!appDir || !sharedDist) { console.error('usage: vendor-shared.mjs <appDir> <sharedDist>'); process.exit(2); }

const distDir = path.join(appDir, 'dist');
const target = path.join(distDir, '_shared');
await stat(path.join(sharedDist, 'index.js'));
await cp(sharedDist, target, { recursive: true, filter: s => !/\.(map|d\.ts)$/.test(s) });

const BARE = /(\bfrom\s*|\bimport\s*\(\s*|\bimport\s*)(['"])@nexora\/shared\2/g;
let rewritten = 0;
async function walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) { if (full !== target) await walk(full); continue; }
    if (!/\.(js|mjs|cjs)$/.test(entry.name)) continue;
    const src = await readFile(full, 'utf8');
    if (!src.includes('@nexora/shared')) continue;
    let rel = path.relative(path.dirname(full), path.join(target, 'index.js')).split(path.sep).join('/');
    if (!rel.startsWith('.')) rel = './' + rel;
    const out = src.replace(BARE, (_m, kw, q) => `${kw}${q}${rel}${q}`);
    if (out.includes('@nexora/shared')) throw new Error(`Unrewritten @nexora/shared import left in ${full}`);
    await writeFile(full, out);
    rewritten += 1;
  }
}
await walk(distDir);
console.log(`vendor-shared: bundled shared into dist/_shared, rewrote imports in ${rewritten} file(s)`);
