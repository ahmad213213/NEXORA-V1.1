import { readFile, writeFile } from 'node:fs/promises';
import { createPrivateKey, sign } from 'node:crypto';
import path from 'node:path';

const [, , manifestPath, privateKeyPath] = process.argv;
if (!manifestPath || !privateKeyPath) throw new Error('Usage: node sign-manifest.mjs <manifest.json> <private-key.pem>');
const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
const { signature: _ignored, ...payload } = manifest;
const canonical = JSON.stringify({ schema: payload.schema, product: payload.product, version: payload.version, platform: payload.platform, url: payload.url, sha256: String(payload.sha256).toLowerCase(), size: payload.size, publishedAt: payload.publishedAt });
const key = createPrivateKey(await readFile(privateKeyPath));
manifest.signature = sign(null, Buffer.from(canonical), key).toString('base64');
await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
console.log(path.resolve(manifestPath));
