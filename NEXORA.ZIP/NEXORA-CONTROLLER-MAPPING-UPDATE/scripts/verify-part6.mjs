import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';

const root = process.cwd();
const read = (p) => fs.readFileSync(path.join(root,p),'utf8');
const checks = [];
function check(name, fn) { try { fn(); checks.push([name,'PASS']); } catch (e) { checks.push([name,`FAIL: ${e.message}`]); } }

check('shared input contract exported', () => {
  const s = read('packages/shared/src/index.ts'); assert.match(s,/\.\/input\.js/);
  const i = read('packages/shared/src/input.ts');
  assert.match(i,/export type InputKind/); assert.match(i,/isValidInputEvent/); assert.match(i,/sequence/);
});
check('input validation bounds codes and coordinates', () => {
  const s = read('packages/shared/src/input.ts');
  assert.match(s,/CODE_RE/); assert.match(s,/x\.x > 1/); assert.match(s,/x\.y > 1/); assert.match(s,/Math\.abs\(x\.value\) > 1/);
});
check('host replay protection', () => {
  const s = read('apps/host/src/input/input-manager.ts');
  assert.match(s,/event\.sequence <= this\.lastSequence/); assert.match(s,/releaseAll/);
});
check('Windows adapter isolated', () => {
  const s = read('apps/host/src/input/windows-send-input.ts'); assert.match(s,/process\.platform !== 'win32'/); assert.match(s,/SendInput/);
});
check('Android landscape enforced', () => {
  const s = read('apps/receiver/android/app/src/main/java/com/nexora/receiver/gameplay/LandscapeGameplayController.kt');
  assert.match(s,/SCREEN_ORIENTATION_LANDSCAPE/); assert.match(s,/IMMERSIVE_STICKY/);
});
check('Android real touch controls', () => {
  const s = read('apps/receiver/android/app/src/main/java/com/nexora/receiver/gameplay/ControlOverlayView.kt');
  assert.match(s,/onTouchEvent/); assert.match(s,/gamepad-button/); assert.match(s,/ACTION_DOWN/); assert.match(s,/ACTION_UP/);
});
check('Android transport dispatcher sequences input', () => {
  const s = read('apps/receiver/android/app/src/main/java/com/nexora/receiver/input/InputDispatcher.kt');
  assert.match(s,/event\.sequence <= sequence/); assert.match(s,/releaseAll/);
});
check('duplicate Android Activity removed', () => {
  assert.equal(fs.existsSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/MainActivity.java')),false);
});
check('Part 5 signaling remains media-free', () => {
  const s = read('packages/shared/src/protocol.ts');
  assert.doesNotMatch(s,/input\.event|stream\.stats/);
});
check('Part 6 docs present', () => {
  assert.ok(fs.existsSync(path.join(root,'docs/PART6-CONTROLLER-ANDROID-SPEC.md')));
  assert.ok(fs.existsSync(path.join(root,'docs/PART6-VERIFICATION.md')));
});

for (const [n,r] of checks) console.log(`${r} ${n}`);
const failed = checks.filter(([,r]) => r !== 'PASS');
console.log(`Part 6 verification: ${checks.length-failed.length}/${checks.length}`);
if (failed.length) process.exit(1);
