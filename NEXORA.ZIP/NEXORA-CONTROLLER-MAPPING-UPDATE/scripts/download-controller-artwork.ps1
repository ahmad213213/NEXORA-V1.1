$ErrorActionPreference = 'Stop'

# Downloads the two sourced controller pictures into the local app assets folder.
# Run from any directory with: powershell -ExecutionPolicy Bypass -File .\scripts\download-controller-artwork.ps1
$repoRoot = Split-Path -Parent $PSScriptRoot
$assetDir = Join-Path $repoRoot 'apps\host\src\ui\assets\controllers'
New-Item -ItemType Directory -Path $assetDir -Force | Out-Null

$items = @(
    @{
        Name = 'playstation-dualsense.png'
        Uri = 'https://www.citypng.com/public/uploads/preview/sony-playstation5-ps5-white-controller-design-701751695142717blpzualcqv.png?v=2026010405'
        SourcePage = 'https://www.citypng.com/photo/851/sony-playstation5-ps5-white-controller-design'
    },
    @{
        Name = 'xbox-wireless.png'
        Uri = 'https://img.itch.zone/aW1nLzI0NzM5OTIyLnBuZw%3D%3D/original/qbTOf3.png'
        SourcePage = 'https://zj-goloyogo.itch.io/balete-mansion-2'
    }
)

$signature = [byte[]](137, 80, 78, 71, 13, 10, 26, 10)
$manifest = [System.Collections.Generic.List[string]]::new()
$manifest.Add('NEXORA controller artwork download manifest')
$manifest.Add(('Created UTC: {0}' -f [DateTime]::UtcNow.ToString('o')))
$manifest.Add('')

foreach ($item in $items) {
    $destination = Join-Path $assetDir $item.Name
    $temporary = "$destination.download"
    try {
        Write-Host "Downloading $($item.Name) ..." -ForegroundColor Cyan
        Invoke-WebRequest -Uri $item.Uri -OutFile $temporary -TimeoutSec 45 -Headers @{ 'User-Agent' = 'NEXORA Controller Artwork Setup/1.0' }
        $bytes = [System.IO.File]::ReadAllBytes($temporary)
        $isPng = $bytes.Length -ge 24
        if ($isPng) {
            for ($i = 0; $i -lt $signature.Length; $i++) {
                if ($bytes[$i] -ne $signature[$i]) { $isPng = $false; break }
            }
        }
        if (-not $isPng) { throw 'Downloaded response is not a valid PNG file.' }

        # Replace only after the temporary download has passed its PNG signature check.
        Move-Item -LiteralPath $temporary -Destination $destination -Force
        $hash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()
        $manifest.Add(('{0} | bytes={1} | sha256={2}' -f $item.Name, (Get-Item -LiteralPath $destination).Length, $hash))
        $manifest.Add(('Source: {0}' -f $item.SourcePage))
        Write-Host "Saved: $destination" -ForegroundColor Green
    }
    catch {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
        throw "Could not download $($item.Name). Nothing at the target path was replaced by an invalid response. $($_.Exception.Message)"
    }
}

$manifestPath = Join-Path $assetDir 'SOURCES.txt'
$manifest | Set-Content -LiteralPath $manifestPath -Encoding UTF8
Write-Host "Both controller images passed PNG signature checks. Manifest: $manifestPath" -ForegroundColor Green
