import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'package.json',
  'pnpm-workspace.yaml',
  'apps/host/src/networking/security.ts',
  'apps/host/src/networking/signaling-client.ts',
  'apps/host/src/networking/pairing.ts',
  'apps/host/test/production-release.test.mjs',
  'apps/host/test/integration-health.test.mjs',
  'scripts/verify-integration-stage5.mjs',
  'docs/PART8-PRODUCTION-RELEASE-SPEC.md'
];
let pass = 0;
for (const rel of required) {
  if (fs.existsSync(path.join(root, rel))) pass++;
  else throw new Error(`Missing required release file: ${rel}`);
}
const forbidden = /BEGIN (?:RSA|EC|OPENSSH|PRIVATE) KEY/i;
const files = [];
function walk(dir) { for (const e of fs.readdirSync(dir,{withFileTypes:true})) { if (['node_modules','.git','dist','build','verify-final-release.mjs'].includes(e.name)) continue; const p=path.join(dir,e.name); if(e.isDirectory()) walk(p); else files.push(p); } }
walk(root);
for (const f of files) { if (!/(src|docs)/.test(path.relative(root,f))) continue; const s=fs.readFileSync(f,'utf8'); if (forbidden.test(s)) throw new Error(`Potential secret material in ${path.relative(root,f)}`); }
console.log(`FINAL RELEASE STATIC AUDIT: ${pass}/${required.length} required checks PASS`);
console.log(`Scanned ${files.length} source/docs files for obvious private-key/secret material: PASS`);
