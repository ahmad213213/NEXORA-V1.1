@echo off
setlocal

rem NEXORA Phase 1 visual preview. Opens the live Electron renderer as a browser preview.
rem Electron-only actions (native window controls, saved configuration, network and streaming IPC)
rem require the actual Electron app and are not expected to operate in a regular browser.
set "PREVIEW=%~dp0apps\host\src\ui\index.html"
if not exist "%PREVIEW%" (
  echo ERROR: The live NEXORA renderer was not found:
  echo "%PREVIEW%"
  echo Please extract the complete NEXORA source ZIP first.
  pause
  exit /b 1
)

echo Opening the NEXORA Phase 1 renderer preview in your default browser...
start "NEXORA Phase 1 Preview" "%PREVIEW%"
if errorlevel 1 (
  echo Could not open the preview automatically.
  echo Open this file manually in your browser:
  echo "%PREVIEW%"
  pause
  exit /b 1
)

echo.
echo This is a visual preview, not the running Electron app.
echo Settings that require the Electron bridge will only work in the actual app.
endlocal
