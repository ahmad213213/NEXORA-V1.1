(() => {
  const clock = document.getElementById('clock');
  const toast = document.getElementById('toast');
  const pinForm = document.getElementById('pinForm');
  const message = document.getElementById('formMessage');
  const gameRow = document.getElementById('gameRow');
  const addGameBtn = document.getElementById('addGameBtn');
  const metadataModal = document.getElementById('metadataModal');
  const candidateList = document.getElementById('candidateList');
  const metadataSubtitle = document.getElementById('metadataSubtitle');
  const closeMetadata = document.getElementById('closeMetadata');
  const librarySubtext = document.getElementById('librarySubtext');
  const pinnedGames = document.getElementById('pinnedGames');
  const heroTitle = document.getElementById('hero-title');
  const heroDescription = document.getElementById('heroDescription');
  const heroMeta = document.getElementById('heroMeta');
  let toastTimer;
  let pendingId = null;
  let games = [];
  let selectedGameId = null;

  const tick = () => {
    if (!clock) return;
    const d = new Date();
    clock.textContent = d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
  };
  tick();
  setInterval(tick, 30000);

  // lastPlayedAt is an ISO date string, so it has to be parsed (Number('2026-10-05T…') is NaN).
  const playedAt = (game) => { const t = Date.parse(game?.lastPlayedAt || ''); return Number.isFinite(t) ? t : 0; };

  // One place that shows the real stream quality (bottom bar, dashboard tag, usage panel, console).
  function friendlyQuality(cfg) {
    const h = cfg?.video?.height || 720;
    if (h <= 480) return 'Light';
    if (h <= 720) return 'Smooth';
    if (h <= 1080) return 'HD';
    return 'Ultra';
  }
  function applyQuality(cfg) {
    if (!cfg?.video) return;
    const text = `${cfg.video.height}p · ${cfg.video.fps} FPS`;
    const bar = document.querySelector('.stream-bar .quality'); if (bar) bar.textContent = text;
    const tag = document.getElementById('featureQuality'); if (tag) tag.textContent = text;
    const usage = document.getElementById('usageStream'); if (usage) usage.textContent = text;
    const label = friendlyQuality(cfg);
    const quickQuality = document.getElementById('quickQualityValue');
    if (quickQuality) quickQuality.textContent = `${cfg.video.height}p`;
    const detail = `${cfg.video.height}p ${cfg.video.fps}fps`;
    const cx = document.getElementById('cxStreamQuality'); if (cx) cx.textContent = detail;
    const cxHeroQ = document.getElementById('cxHeroQuality'); if (cxHeroQ) cxHeroQ.textContent = label;
    const cxGpu = document.getElementById('cxGpu'); if (cxGpu) cxGpu.textContent = label;
  }

  const accentPalette = {
    cyan: { primary: '#94c0c1', secondary: '#b8a8b9' },
    blue: { primary: '#5b9dff', secondary: '#7b6cff' },
    violet: { primary: '#a18aff', secondary: '#d18bff' },
    amber: { primary: '#e6b25f', secondary: '#c9875f' },
    emerald: { primary: '#58d6a6', secondary: '#64bec6' },
    rose: { primary: '#ff82a8', secondary: '#bd8cff' }
  };
  function applyPreferences(cfg) {
    const root = document.documentElement;
    const appearance = cfg?.appearance || {};
    const theme = ['midnight', 'obsidian', 'earth'].includes(appearance.theme) ? appearance.theme : 'midnight';
    const accent = accentPalette[appearance.accent] ? appearance.accent : 'cyan';
    const palette = accentPalette[accent];
    root.dataset.theme = theme;
    root.dataset.accent = accent;
    root.dataset.reducedMotion = appearance.reducedMotion === true ? 'true' : 'false';
    setEmptyLibraryBackground(appearance.emptyLibraryBackground || 'space-horizon');
    root.style.setProperty('--blue', palette.primary);
    root.style.setProperty('--blue2', palette.secondary);
    document.querySelectorAll('.settings-accent').forEach((button) => {
      button.setAttribute('aria-pressed', String(button.dataset.accent === accent));
    });
    const name = (typeof cfg?.profileName === 'string' && cfg.profileName.trim()) ? cfg.profileName.trim().slice(0, 32) : 'My PC';
    for (const id of ['profileName', 'statusPcName', 'cxUserName', 'topPcName']) {
      const el = document.getElementById(id);
      if (el) el.textContent = name;
    }
    const avatar = document.querySelector('.profile .avatar');
    if (avatar) avatar.textContent = name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase() || 'PC';
  }

  const show = (text) => {
    if (!toast) return;
    toast.textContent = text;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
  };


  // Styled confirm dialog (replaces the plain browser pop-up). Resolves true on OK, false on Cancel/Esc/outside click.
  const confirmModal = document.getElementById('confirmModal');
  function askConfirm(text, { title = 'Are you sure?', okLabel = 'OK', danger = false } = {}) {
    return new Promise((resolve) => {
      const titleEl = document.getElementById('confirmTitle');
      const textEl = document.getElementById('confirmText');
      const ok = document.getElementById('confirmOk');
      const cancel = document.getElementById('confirmCancel');
      if (!confirmModal || !titleEl || !textEl || !ok || !cancel) { resolve(false); return; }
      titleEl.textContent = title; textEl.textContent = text; ok.textContent = okLabel;
      ok.classList.toggle('danger', danger);
      const finish = (value) => {
        confirmModal.hidden = true;
        ok.removeEventListener('click', onOk); cancel.removeEventListener('click', onCancel);
        confirmModal.removeEventListener('click', onBackdrop); document.removeEventListener('keydown', onKey, true);
        resolve(value);
      };
      const onOk = () => finish(true);
      const onCancel = () => finish(false);
      const onBackdrop = (event) => { if (event.target === confirmModal) finish(false); };
      const onKey = (event) => { if (event.key === 'Escape') { event.stopPropagation(); event.preventDefault(); finish(false); } };
      ok.addEventListener('click', onOk); cancel.addEventListener('click', onCancel);
      confirmModal.addEventListener('click', onBackdrop); document.addEventListener('keydown', onKey, true);
      confirmModal.hidden = false;
      cancel.focus();
    });
  }

  const create = (tag, className, text) => {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = text;
    return el;
  };

  const FALLBACK_COVER = './assets/placeholder.svg';

  function escapeCssId(value) {
    const s = String(value ?? '');
    if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') return CSS.escape(s);
    return s.replace(/[^a-zA-Z0-9_-]/g, '\\$&');
  }

  function bindCover(img, url) {
    if (!img) return;
    img.loading = 'lazy';
    img.decoding = 'async';
    img.onerror = () => { img.onerror = null; img.src = FALLBACK_COVER; };
    img.src = url || FALLBACK_COVER;
  }


  const EMPTY_BACKGROUND_OPTIONS = [
    { id: 'space-horizon', label: 'Space Horizon', file: 'space-horizon.jpg' },
    { id: 'nebula', label: 'Nebula', file: 'nebula.jpg' },
    { id: 'forest-vista', label: 'Forest Vista', file: 'forest-vista.jpg' },
    { id: 'earth-orbit', label: 'Earth Orbit', file: 'earth-orbit.jpg' }
  ];
  let activeEmptyBackgroundId = 'space-horizon';
  let DEFAULT_HERO = './assets/backgrounds/space-horizon.jpg';
  let EMPTY_CONSOLE_BACKGROUND = DEFAULT_HERO;

  function setEmptyLibraryBackground(id) {
    const selected = EMPTY_BACKGROUND_OPTIONS.find(item => item.id === id) || EMPTY_BACKGROUND_OPTIONS[0];
    activeEmptyBackgroundId = selected.id;
    DEFAULT_HERO = `./assets/backgrounds/${selected.file}`;
    EMPTY_CONSOLE_BACKGROUND = DEFAULT_HERO;
    document.documentElement.style.setProperty('--nexora-empty-wallpaper', cssUrl(DEFAULT_HERO));
    if (!selectedGameId) {
      setHeroBackground(DEFAULT_HERO);
      setConsoleHeroBackground(null);
    }
  }

  function nextEmptyLibraryBackground(id) {
    const index = EMPTY_BACKGROUND_OPTIONS.findIndex(item => item.id === id);
    return EMPTY_BACKGROUND_OPTIONS[(index + 1 + EMPTY_BACKGROUND_OPTIONS.length) % EMPTY_BACKGROUND_OPTIONS.length].id;
  }

  function setStreamLabel(gameTitle) {
    if (!streamGameLabel) return;
    streamGameLabel.replaceChildren();
    if (gameTitle) {
      streamGameLabel.append(document.createTextNode(gameTitle), document.createTextNode(' '));
      const dot = create('i');
      streamGameLabel.append(dot, document.createTextNode(' Ready on Host PC'));
    } else {
      streamGameLabel.append(document.createTextNode('No game selected '), create('i'), document.createTextNode(' Host ready'));
    }
  }

  const heroArt = document.getElementById('heroArt');
  const continueRow = document.getElementById('continueRow');
  const deskHome = document.getElementById('deskHome');
  const page = document.getElementById('page');
  const heroEyebrow = document.getElementById('heroEyebrow');
  const streamGameLabel = document.getElementById('streamLabel');
  const gameSummaryCover = document.getElementById('gameSummaryCover');
  const gameSummaryTitle = document.getElementById('gameSummaryTitle');
  const gameSummaryProvider = document.getElementById('gameSummaryProvider');
  const gameSummaryGenre = document.getElementById('gameSummaryGenre');
  const gameSummaryPlatform = document.getElementById('gameSummaryPlatform');
  const gameSummaryPlay = document.getElementById('gameSummaryPlay');
  const gameSummaryLast = document.getElementById('gameSummaryLast');
  const gameSummaryAdded = document.getElementById('gameSummaryAdded');

  const coverFor = (game) => game?.metadata?.cover?.url || FALLBACK_COVER;

  function cssUrl(url) {
    return `url(${JSON.stringify(String(url || ''))})`;
  }

  function setHeroBackground(url) {
    if (!heroArt) return;
    const src = url || DEFAULT_HERO;
    heroArt.style.backgroundImage = `linear-gradient(125deg,rgba(7,13,23,.35),rgba(7,13,23,.1)),${cssUrl(src)}`;
  }

  function formatPlayTime(seconds) {
    const h = Math.floor((seconds || 0) / 3600);
    const m = Math.floor(((seconds || 0) % 3600) / 60);
    return `${h}h ${String(m).padStart(2, '0')}m`;
  }

  function formatDate(value) {
    if (!value) return '—';
    try { return new Date(value).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }); }
    catch { return '—'; }
  }

  function updateGameInfo(game) {
    if (!game) {
      if (gameSummaryCover) { gameSummaryCover.hidden = true; gameSummaryCover.removeAttribute('src'); }
      if (gameSummaryTitle) gameSummaryTitle.textContent = 'No game selected';
      if (gameSummaryProvider) gameSummaryProvider.textContent = 'Add a game to begin';
      if (gameSummaryGenre) gameSummaryGenre.textContent = '⌁ —';
      if (gameSummaryPlatform) gameSummaryPlatform.textContent = '▣ Windows PC';
      if (gameSummaryPlay) gameSummaryPlay.textContent = '—';
      if (gameSummaryLast) gameSummaryLast.textContent = '—';
      if (gameSummaryAdded) gameSummaryAdded.textContent = '—';
      setStreamLabel(null);
      return;
    }
    const title = game.metadata?.title || game.name;
    const cover = coverFor(game);
    if (gameSummaryCover) { gameSummaryCover.hidden = false; bindCover(gameSummaryCover, cover); }
    if (gameSummaryTitle) gameSummaryTitle.textContent = title;
    if (gameSummaryProvider) gameSummaryProvider.textContent = `◈ ${game.metadata?.provider || 'Verified metadata'}`;
    if (gameSummaryGenre) gameSummaryGenre.textContent = `⌁ ${(game.metadata?.genres || [game.metadata?.gameType || 'Game']).join(' / ')}`;
    if (gameSummaryPlatform) gameSummaryPlatform.textContent = '▣ Windows PC';
    if (gameSummaryPlay) gameSummaryPlay.textContent = formatPlayTime(game.playTimeSeconds);
    if (gameSummaryLast) gameSummaryLast.textContent = formatDate(game.lastPlayedAt);
    if (gameSummaryAdded) gameSummaryAdded.textContent = formatDate(game.createdAt);
    setStreamLabel(title);
  }

  function selectGame(game) {
    if (!game) {
      selectedGameId = null;
      document.querySelectorAll('.game-card').forEach(x => x.classList.remove('selected'));
      if (heroEyebrow) heroEyebrow.textContent = 'READY';
      if (heroTitle) heroTitle.textContent = 'Your games';
      if (heroDescription) heroDescription.textContent = 'Add a game, then play it on your phone.';
      if (heroMeta) {
        heroMeta.replaceChildren();
        const a = create('span', '', '◈ NEXORA Host');
        const d1 = create('i');
        const b = create('span', '', '◷ Windows PC');
        const d2 = create('i');
        const c = create('span', '', '▣ Verified games only');
        heroMeta.append(a, d1, b, d2, c);
      }
      setHeroBackground(DEFAULT_HERO);
      updateGameInfo(null);
      if (typeof syncConsoleFromSelection === 'function') syncConsoleFromSelection(null);
      return;
    }
    selectedGameId = game.id;
    document.querySelectorAll('.game-card').forEach(x => x.classList.remove('selected'));
    const active = document.querySelector(`.game-card[data-id="${escapeCssId(game.id)}"]`);
    active?.classList.add('selected');
    const title = game.metadata?.title || game.name;
    if (heroEyebrow) heroEyebrow.textContent = 'SELECTED';
    if (heroTitle) {
      heroTitle.replaceChildren();
      title.split(/\s+/).forEach((part, index, parts) => {
        heroTitle.append(document.createTextNode(part), index === parts.length - 1 ? '' : ' ');
        if (index === Math.ceil(parts.length / 2) - 1 && parts.length > 2) heroTitle.append(document.createElement('br'));
      });
    }
    if (heroDescription) heroDescription.textContent = game.metadata?.description || 'Verified local Windows game.';
    if (heroMeta) {
      heroMeta.replaceChildren();
      const publisher = create('span', '', `◈ ${game.metadata?.provider || 'Verified metadata'}`);
      const divider1 = create('i');
      const genre = create('span', '', `◷ ${(game.metadata?.genres || [game.metadata?.gameType || 'Game']).join(' / ')}`);
      const divider2 = create('i');
      const platform = create('span', '', '▣ Windows PC');
      heroMeta.append(publisher, divider1, genre, divider2, platform);
    }
    setHeroBackground(coverFor(game));
    updateGameInfo(game);
    if (typeof syncConsoleFromSelection === 'function') syncConsoleFromSelection(game);
  }

  /* ——— Console Mode ——— */
  const consoleShell = document.getElementById('consoleShell');
  const cxTileRow = document.getElementById('cxTileRow');
  const cxRecentList = document.getElementById('cxRecentList');
  const cxHeroArt = document.getElementById('cxHeroArt');
  const cxHeroTitle = document.getElementById('cxHeroTitle');
  const cxHeroDesc = document.getElementById('cxHeroDesc');
  const cxHeroMeta = document.getElementById('cxHeroMeta');
  const cxClock = document.getElementById('cxClock');
  const cxStreamQuality = document.getElementById('cxStreamQuality');
  let consoleMode = false;
  let settingsCategory = 'general';
  let cxFilter = '';
  function syncConsoleFromSelection(game) {
    if (!consoleMode) return;
    syncConsoleHero(game);
    renderConsoleTiles();
    renderConsoleRecent();
  }

  function setConsoleHeroBackground(url) {
    const src = url || EMPTY_CONSOLE_BACKGROUND;
    if (cxHeroArt) cxHeroArt.style.backgroundImage = cssUrl(src);
    const focus = document.getElementById('cxFocusArt');
    if (focus) focus.style.backgroundImage = cssUrl(url || DEFAULT_HERO);
  }

  function syncConsoleHero(game) {
    if (!game) {
      if (cxHeroTitle) cxHeroTitle.textContent = 'Your games';
      if (cxHeroDesc) cxHeroDesc.textContent = 'Add a game to start.';
      setConsoleHeroBackground(null);
      const info = document.getElementById('cxStreamInfo');
      if (info) info.textContent = 'No game selected';
      return;
    }
    const title = game.metadata?.title || game.name;
    if (cxHeroTitle) cxHeroTitle.textContent = title;
    const desc = game.metadata?.shortDescription || game.metadata?.description || 'Press Play when your phone is ready.';
    if (cxHeroDesc) cxHeroDesc.textContent = desc.length > 90 ? desc.slice(0, 87) + '…' : desc;
    setConsoleHeroBackground(coverFor(game));
    const info = document.getElementById('cxStreamInfo');
    if (info) info.textContent = 'Ready to play';
  }

  function renderConsoleTiles() {
    if (!cxTileRow) return;
    cxTileRow.replaceChildren();
    const q = (cxFilter || '').trim().toLowerCase();
    const list = games.slice().sort((a, b) => playedAt(b) - playedAt(a)).filter(game => {
      if (!q) return true;
      const title = String(game.metadata?.title || game.name || '').toLowerCase();
      return title.includes(q);
    });
    if (!list.length) {
      const empty = create('div', 'cx-empty');
      empty.append(
        create('b', '', q ? 'No games match that name' : 'No games yet'),
        create('span', '', q ? 'Try another name, or clear the search.' : 'Press “Add a game” to get started.')
      );
      cxTileRow.append(empty);
      return;
    }
    list.forEach(game => {
      const tile = create('button', 'cx-tile' + (selectedGameId === game.id ? ' selected' : ''));
      tile.type = 'button';
      tile.dataset.id = game.id;
      tile.setAttribute('aria-label', game.metadata?.title || game.name || 'Game');
      tile.setAttribute('role', 'listitem');
      const art = create('div', 'cx-tile-art');
      art.style.backgroundImage = cssUrl(coverFor(game));
      tile.append(art);
      tile.addEventListener('click', () => selectGame(game));
      cxTileRow.append(tile);
    });
  }

  function renderConsoleRecent() {
    if (!cxRecentList) return;
    cxRecentList.replaceChildren();
    const list = games.slice().sort((a, b) => playedAt(b) - playedAt(a)).slice(0, 4);
    if (!list.length) {
      cxRecentList.append(create('small', '', 'Nothing played yet'));
      return;
    }
    list.forEach(game => {
      const btn = create('button', 'cx-recent-item');
      btn.type = 'button';
      const img = create('img');
      img.alt = '';
      bindCover(img, coverFor(game));
      btn.append(img);
      const wrap = create('div');
      wrap.append(create('b', '', game.metadata?.title || game.name));
      wrap.append(create('small', '', formatPlayTime(game.playTimeSeconds)));
      btn.append(wrap);
      btn.addEventListener('click', () => { selectGame(game); renderConsoleTiles(); renderConsoleRecent(); });
      cxRecentList.append(btn);
    });
  }


  function closeConsoleDetail() {
    const el = document.getElementById('cxDetail');
    if (el) el.hidden = true;
    const about = document.getElementById('cxdAbout');
    if (about) about.classList.remove('expanded');
    const more = document.getElementById('cxdReadMore');
    if (more) { more.hidden = true; more.textContent = 'Read More ›'; }
  }

  function openConsoleDetail(game) {
    if (!game) return show('Pick a game first.');
    const el = document.getElementById('cxDetail');
    if (!el) return;
    const title = game.metadata?.title || game.name || 'Game';
    const cover = coverFor(game);
    const shots = Array.isArray(game.metadata?.screenshots) ? game.metadata.screenshots.filter(Boolean) : [];
    const media = shots.length ? shots : [cover];

    const setBg = (url) => {
      const main = document.getElementById('cxdMainShot');
      if (main) main.style.backgroundImage = cssUrl(url);
    };
    setConsoleHeroBackground(cover);
    setBg(media[0]);

    const brand = document.getElementById('cxdBrandArt');
    if (brand) brand.style.backgroundImage = cssUrl(cover);

    const tEl = document.getElementById('cxdTitle');
    if (tEl) tEl.textContent = title;
    const tag = document.getElementById('cxdTagline');
    if (tag) {
      const d = game.metadata?.shortDescription || game.metadata?.description || '';
      tag.textContent = d ? (d.length > 120 ? d.slice(0, 117) + '…' : d) : 'Ready to play on your phone.';
    }

    const tags = document.getElementById('cxdTags');
    if (tags) {
      tags.replaceChildren();
      const list = [...(game.metadata?.genres || []).slice(0, 3)];
      if (game.metadata?.provider) list.push(String(game.metadata.provider));
      if (!list.length) list.push('Game');
      list.forEach(x => tags.append(create('span', 'cxd-tag', x)));
    }

    const facts = document.getElementById('cxdFacts');
    if (facts) {
      facts.replaceChildren();
      const add = (icon, label, value) => {
        const row = create('div', 'cxd-fact');
        row.append(create('span', 'cxd-fact-icon', icon));
        const copy = create('div');
        copy.append(create('b', '', label), create('span', '', value || '—'));
        row.append(copy);
        facts.append(row);
      };
      const dev = (game.metadata?.developers && game.metadata.developers[0]) || game.metadata?.publisher || '—';
      add('👤', 'Developer', Array.isArray(game.metadata?.developers) ? game.metadata.developers.slice(0, 2).join(', ') : dev);
      add('🎮', 'Category', (game.metadata?.genres || []).slice(0, 2).join(' / ') || 'Game');
      add('📅', 'Release', formatDate(game.metadata?.releaseDate));
      add('⏱', 'Play time', formatPlayTime(game.playTimeSeconds));
    }

    const thumbs = document.getElementById('cxdThumbs');
    if (thumbs) {
      thumbs.replaceChildren();
      media.slice(0, 4).forEach((url, i) => {
        const btn = create('button', 'cxd-thumb' + (i === 0 ? ' active' : ''));
        btn.type = 'button';
        btn.style.backgroundImage = cssUrl(url);
        btn.setAttribute('aria-label', `Image ${i + 1}`);
        btn.addEventListener('click', () => {
          thumbs.querySelectorAll('.cxd-thumb').forEach(x => x.classList.remove('active'));
          btn.classList.add('active');
          setBg(url);
        });
        thumbs.append(btn);
      });
    }

    const about = document.getElementById('cxdAbout');
    const full = game.metadata?.description || game.metadata?.shortDescription || 'No description yet. You can still play this game.';
    if (about) {
      about.textContent = full;
      about.classList.remove('expanded');
    }
    const more = document.getElementById('cxdReadMore');
    if (more) {
      more.hidden = full.length < 160;
      more.textContent = 'Read More ›';
      more.onclick = () => {
        const open = about?.classList.toggle('expanded');
        more.textContent = open ? 'Show less' : 'Read More ›';
      };
    }

    const pub = document.getElementById('cxdPublisher');
    if (pub) pub.textContent = game.metadata?.publisher || (game.metadata?.developers && game.metadata.developers[0]) || '—';
    const plat = document.getElementById('cxdPlatforms');
    if (plat) plat.textContent = 'Windows PC';
    const pt = document.getElementById('cxdPlayTime');
    if (pt) pt.textContent = formatPlayTime(game.playTimeSeconds);
    const foot = document.getElementById('cxdFootName');
    if (foot) foot.textContent = title.toUpperCase();
    const footTag = document.getElementById('cxdFootTag');
    if (footTag) footTag.textContent = 'Play Beyond Your Screen.';

    const clk = document.getElementById('cxDetailClock');
    const mainClk = document.getElementById('cxClock');
    if (clk && mainClk) clk.textContent = mainClk.textContent;

    el.hidden = false;
  }

  function enterConsoleMode() {
    consoleMode = true;
    document.body.classList.add('console-mode');
    document.getElementById('winConsoleBtn')?.classList.add('active');
    const desktop = document.querySelector('.app-shell');
    if (desktop) {
      desktop.setAttribute('aria-hidden', 'true');
      desktop.inert = true;
    }
    if (consoleShell) {
      consoleShell.hidden = false;
      consoleShell.setAttribute('aria-hidden', 'false');
    }
    // Refresh only Console Mode artwork from current selection; no game means the default background.
    setConsoleHeroBackground(games.length ? coverFor(games.find(g => g.id === selectedGameId) || games[0]) : null);
    renderConsoleTiles();
    renderConsoleRecent();
    try {
      window.nexora?.getConfig?.().then(cfg => applyQuality(cfg)).catch(() => {});
    } catch {}
    const bar = document.getElementById('cxFindBar');
    if (bar) bar.hidden = true;
    cxFilter = '';
    const input = document.getElementById('cxFindInput');
    if (input) input.value = '';
  }

  function exitConsoleMode() {
    closeConsoleDetail();
    consoleMode = false;
    document.body.classList.remove('console-mode');
    document.getElementById('winConsoleBtn')?.classList.remove('active');
    const desktop = document.querySelector('.app-shell');
    if (desktop) {
      desktop.removeAttribute('aria-hidden');
      desktop.inert = false;
    }
    if (consoleShell) {
      consoleShell.hidden = true;
      consoleShell.setAttribute('aria-hidden', 'true');
    }
    if (desktop) {
      desktop.style.animation = 'nexora-desktop-return .28s cubic-bezier(.2,.7,.2,1) both';
      desktop.addEventListener('animationend', () => { desktop.style.animation = ''; }, { once: true });
    }
  }


  document.getElementById('cxSearch')?.addEventListener('click', () => {
    const bar = document.getElementById('cxFindBar');
    const input = document.getElementById('cxFindInput');
    if (!bar) return;
    const open = bar.hidden;
    bar.hidden = !open;
    if (open) { input?.focus(); }
    else { cxFilter = ''; if (input) input.value = ''; renderConsoleTiles(); }
  });
  document.getElementById('cxFindInput')?.addEventListener('input', (e) => {
    cxFilter = String(e.target?.value || '');
    renderConsoleTiles();
  });
  document.getElementById('cxFindClear')?.addEventListener('click', () => {
    cxFilter = '';
    const input = document.getElementById('cxFindInput');
    if (input) input.value = '';
    renderConsoleTiles();
    input?.focus();
  });
  document.getElementById('cxMoreBtn')?.addEventListener('click', async () => {
    const g = games.find(x => x.id === selectedGameId);
    if (!g) return show('Pick a game first.');
    const title = g.metadata?.title || g.name;
    const pinLabel = g.pinned ? 'Unpin from sidebar' : 'Pin to sidebar';
    if (await askConfirm(`${title}\n\nWhat would you like to do?`, { title: 'Game options', okLabel: pinLabel })) {
      try {
        const updated = await window.nexora.togglePin(g.id);
        if (updated) {
          const i = games.findIndex(x => x.id === g.id);
          if (i >= 0) games[i] = updated;
          renderGames(); renderPinned(); selectGame(updated);
          show(updated.pinned ? 'Pinned.' : 'Unpinned.');
        }
      } catch { show('Could not update pin.'); }
      return;
    }
    if (await askConfirm(`Remove ${title} from NEXORA?`, { title: 'Remove game', okLabel: 'Remove', danger: true })) {
      try {
        if (await window.nexora.removeGame(g.id)) {
          games = games.filter(x => x.id !== g.id);
          if (selectedGameId === g.id) selectedGameId = null;
          renderGames(); renderPinned(); selectGame(null);
          show('Game removed.');
        }
      } catch { show('Could not remove game.'); }
    }
  });
  document.getElementById('cxPlayBtn')?.addEventListener('click', async () => {
    const g = games.find(x => x.id === selectedGameId);
    if (!g) return show('Select a game first.');
    try {
      if (typeof window.nexora.markPlayed === 'function') {
        const updated = await window.nexora.markPlayed(g.id, 0);
        if (updated) { const i = games.findIndex(x => x.id === g.id); if (i >= 0) games[i] = updated; renderGames(); renderPinned(); selectGame(updated); }
      }
    } catch { /* ignore */ }
    show(`“${g.metadata?.title || g.name}” is ready. Open NEXORA on your phone to play.`);
  });
  document.getElementById('cxAddGame')?.addEventListener('click', () => document.getElementById('addGameBtn')?.click());
  document.getElementById('cxExitConsole')?.addEventListener('click', exitConsoleMode);
  document.querySelectorAll('[data-cx-jump="library"]').forEach(el => el.addEventListener('click', () => {
    exitConsoleMode();
    document.querySelector('[data-view="games"]')?.click();
  }));
  document.querySelectorAll('.cx-rail-btn').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.cx-rail-btn').forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.cx;
    if (tab === 'settings') {
      exitConsoleMode();
      document.querySelector('[data-view="settings"]')?.click();
    } else if (tab === 'devices') {
      exitConsoleMode();
      document.querySelector('[data-view="devices"]')?.click();
      show('Connect your phone with a short code.');
    } else if (tab === 'library') {
      cxFilter = '';
      const input = document.getElementById('cxFindInput');
      const bar = document.getElementById('cxFindBar');
      if (input) input.value = '';
      if (bar) bar.hidden = true;
      renderConsoleTiles();
      renderConsoleRecent();
      show(games.length ? `${games.length} games in your library` : 'Add a game to get started');
    } else if (tab === 'home') {
      const bar = document.getElementById('cxFindBar');
      if (bar) bar.hidden = true;
      cxFilter = '';
      renderConsoleTiles();
      renderConsoleRecent();
    }
  }));

  // Console clock
  const tickCx = () => {
    if (cxClock) cxClock.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  tickCx();
  setInterval(tickCx, 30000);

  function renderPinned() {
    if (!pinnedGames) return;
    pinnedGames.replaceChildren();
    games.filter(game => game.pinned).slice(0, 5).forEach(game => {
      const button = create('button', 'mini-game');
      const img = create('img'); img.alt = ''; bindCover(img, coverFor(game)); button.append(img);
      const span = create('span'); span.append(create('b','',game.metadata?.title || game.name), create('small','', '● Windows PC')); button.append(span);
      button.addEventListener('click', () => selectGame(game));
      pinnedGames.append(button);
    });
    if (!pinnedGames.children.length) pinnedGames.append(create('small','pinned-empty','No pinned games'));
  }

  function renderCard(game) {
    const card = create('article', 'game-card' + (selectedGameId === game.id ? ' selected' : ''));
    card.dataset.id = game.id;
    card.tabIndex = 0;

    const img = create('img');
    img.alt = '';
    bindCover(img, coverFor(game));
    img.loading = 'lazy';
    card.append(img);

    const info = create('div', 'game-info');
    info.append(create('b', '', game.metadata?.title || game.name));
    info.append(create('small', '', `▣ ${game.metadata?.platform === 'windows' ? 'Windows PC' : 'Local PC'}`));
    const hours = Math.floor((game.playTimeSeconds || 0) / 3600);
    const minutes = Math.floor(((game.playTimeSeconds || 0) % 3600) / 60);
    info.append(create('small', '', `◷ ${hours}h ${String(minutes).padStart(2, '0')}m`));
    card.append(info);

    const actions = create('div', 'game-card-actions');
    const pin = create('button', 'card-action', game.pinned ? '★' : '☆');
    pin.type = 'button'; pin.title = game.pinned ? 'Unpin game' : 'Pin game';
    pin.addEventListener('click', async (event) => {
      event.stopPropagation();
      const updated = await window.nexora.togglePin(game.id);
      if (updated) { const index = games.findIndex(x => x.id === game.id); if (index >= 0) games[index] = updated; renderGames(); renderPinned(); }
    });
    const remove = create('button', 'card-action danger', '×');
    remove.type = 'button'; remove.title = 'Remove game';
    remove.addEventListener('click', async (event) => {
      event.stopPropagation();
      if (!await askConfirm(`Remove ${game.metadata?.title || game.name} from NEXORA? Its cover and screenshots are deleted too.`, { title: 'Remove game', okLabel: 'Remove', danger: true })) return;
      if (await window.nexora.removeGame(game.id)) {
        games = games.filter(x => x.id !== game.id);
        if (selectedGameId === game.id) selectedGameId = null;
        renderGames();
        renderPinned();
        show('Game removed.');
      }
    });
    actions.append(pin, remove);
    card.append(actions);

    const select = () => { selectGame(game); show(`${game.metadata?.title || game.name} selected.`); };
    card.addEventListener('click', select);
    card.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); select(); } });
    card.addEventListener('mouseenter', () => setHeroBackground(coverFor(game)));
    card.addEventListener('mouseleave', () => {
      const current = games.find(g => g.id === selectedGameId);
      setHeroBackground(current ? coverFor(current) : DEFAULT_HERO);
    });
    return card;
  }

  function upsertGame(game) {
    const index = games.findIndex(item => item.id === game.id);
    if (index >= 0) games[index] = game; else games.push(game);
  }


  function renderContinue() {
    if (!continueRow) return;
    continueRow.replaceChildren();
    const list = games.slice().sort((a, b) => playedAt(b) - playedAt(a)).filter(g => playedAt(g) > 0).slice(0, 8);
    if (!list.length) {
      const empty = create('div', 'library-empty');
      empty.append(create('b', '', 'Nothing played yet'), create('span', '', 'When you play a game, it shows up here.'));
      continueRow.append(empty);
      return;
    }
    list.forEach(game => continueRow.append(renderCard(game)));
  }

  function renderGames() {
    if (!gameRow) return;
    gameRow.replaceChildren();
    if (!games.length) {
      const empty = create('div', 'library-empty');
      empty.append(create('b', '', 'Your verified games will appear here.'), create('span', '', 'Use “＋ Add Game” to select a Windows .exe. NEXORA verifies its metadata before saving it.'));
      gameRow.append(empty);
    } else {
      games.slice().sort((a,b) => playedAt(b) - playedAt(a)).forEach(game => gameRow.append(renderCard(game)));
    }
    if (librarySubtext) librarySubtext.textContent = games.length ? `${games.length} verified game${games.length === 1 ? '' : 's'} · metadata protected` : 'Your verified game library';
    renderPinned();
    if (games.length) selectGame(games.find(g => g.id === selectedGameId) || games[0]);
    else selectGame(null);
    if (typeof consoleMode !== 'undefined' && consoleMode) { renderConsoleTiles(); renderConsoleRecent(); }
  }

  function openMetadata(result) {
    if (!metadataModal || !candidateList) return;
    pendingId = result.pendingId;
    candidateList.replaceChildren();
    if (metadataSubtitle) metadataSubtitle.textContent = result.reasons?.[0] || 'Multiple verified matches were found.';
    result.candidates.forEach((candidate, index) => {
      const item = create('button', 'candidate-card');
      item.type = 'button';
      const title = create('b', '', candidate.title);
      const provider = create('small', '', `${candidate.provider} · ${candidate.gameType} · ${Math.round(candidate.score)} confidence`);
      const desc = create('span', '', candidate.description || 'Description unavailable');
      item.append(title, provider, desc);
      item.addEventListener('click', async () => {
        item.disabled = true;
        item.classList.add('loading');
        show('Verifying selected game…');
        const selected = await window.nexora.selectMetadataCandidate(pendingId, index);
        if (selected.status === 'accepted' && selected.game) {
          upsertGame(selected.game); renderGames(); renderPinned(); selectGame(selected.game); closeMetadataModal(); show('Game added.');
        } else {
          item.disabled = false; item.classList.remove('loading'); show(selected.reasons?.[0] || 'Could not verify this game. Nothing was added.');
        }
      });
      candidateList.append(item);
    });
    metadataModal.hidden = false;
    closeMetadata?.focus();
  }

  function closeMetadataModal() {
    if (metadataModal) metadataModal.hidden = true;
    if (candidateList) candidateList.replaceChildren();
    pendingId = null;
  }

  // ---- NEXORA ORBIT add-game flow --------------------------------------------------------------
  // .exe picked -> name box (pre-filled) -> user presses Add Game -> search runs
  // -> the best matches (up to 4) appear -> the user picks one -> details, cover and screenshots are loaded.
  const orbitModal = document.getElementById('orbitModal');
  const orbitName = document.getElementById('orbitName');
  const orbitExe = document.getElementById('orbitExe');
  const orbitStatusEl = document.getElementById('orbitStatus');
  const orbitStatusText = document.getElementById('orbitStatusText');
  const orbitBar = document.getElementById('orbitBar');
  const orbitOptions = document.getElementById('orbitOptions');
  const orbitSources = document.getElementById('orbitSources');
  const orbitClose = document.getElementById('orbitClose');
  const orbitGo = document.getElementById('orbitGo');
  const ORBIT_STAGE_TEXT = {
    details: 'Loading game details…',
    cover: 'Finding the best cover…',
    screenshots: 'Downloading screenshots',
    saving: 'Saving to your library…'
  };
  const orbit = { pendingId: null, requestId: 0, shownRequestId: null, timer: null, dirty: false, busy: false, unsubscribe: null };

  function orbitStatus(text, mode) {
    if (orbitStatusText) orbitStatusText.textContent = text;
    if (orbitStatusEl) orbitStatusEl.dataset.mode = mode;
    if (orbitBar) orbitBar.hidden = !(mode === 'searching' || mode === 'loading');
  }

  function orbitClear() {
    orbit.shownRequestId = null;
    orbitOptions?.replaceChildren();
    orbitSources?.replaceChildren();
  }

  function orbitRenderOptions(options) {
    orbitOptions.replaceChildren();
    orbitOptions.classList.remove('stale');
    options.forEach((option) => {
      const card = create('button', 'orbit-option');
      card.type = 'button';
      let thumb;
      if (option.thumbnail) {
        thumb = create('img', 'orbit-thumb');
        thumb.src = option.thumbnail;
        thumb.alt = '';
      } else {
        thumb = create('div', 'orbit-thumb empty', '◈');
      }
      const info = create('div', 'orbit-info');
      info.append(create('b', '', option.title), create('small', '', `${[option.provider, ...option.alsoOn].join(' + ')} · ${option.matchPercent}% match`));
      if (option.index === 0 && option.matchPercent >= 90) info.append(create('span', 'orbit-tag', 'BEST MATCH'));
      card.append(thumb, info);
      card.addEventListener('click', () => orbitChoose(option.index, card));
      orbitOptions.append(card);
    });
  }

  function orbitRenderSources(providers) {
    orbitSources.replaceChildren();
    providers.filter(p => p.status !== 'needs_config').forEach((p) => {
      const ok = p.status === 'ok' || p.status === 'partial';
      orbitSources.append(create('span', `orbit-chip ${ok ? 'ok' : 'fail'}`, `${ok ? '✓' : '✕'} ${p.label}`));
    });
  }

  // Typing only clears old results. The search starts when the user presses Add Game (or Enter).
  function orbitQueue(immediate) {
    clearTimeout(orbit.timer);
    const query = orbitName.value.replace(/\s+/g, ' ').trim();
    if (orbitGo) orbitGo.disabled = query.length < 2;
    if (!immediate || query.length < 2) {
      orbit.requestId += 1; // anything still in flight is now outdated
      orbit.dirty = false;
      orbitClear();
      orbitStatus(query.length < 2 ? 'Type the game name.' : 'Check the game name, then press Add Game.', 'idle');
      return;
    }
    orbit.dirty = true;
    orbitOptions.classList.add('stale');
    orbitStatus('Searching…', 'searching');
    orbit.timer = setTimeout(() => orbitRun(query), 0);
  }

  async function orbitRun(query) {
    const pendingId = orbit.pendingId;
    if (!pendingId) return;
    const requestId = ++orbit.requestId;
    orbit.dirty = false;
    let out;
    try {
      out = await window.nexora.orbitSearch(pendingId, query, requestId);
    } catch {
      if (orbit.pendingId === pendingId && requestId === orbit.requestId) { orbitClear(); orbitStatus('Search failed. Press Add Game to try again.', 'error'); }
      return;
    }
    // Ignore answers for text the user has already changed.
    if (orbit.pendingId !== pendingId || requestId !== orbit.requestId || orbit.dirty) return;
    if (out.status === 'superseded') return;
    if (out.status === 'unknown-session') { closeOrbit(false); show('That add-game session expired. Start again.'); return; }
    if (out.status === 'error') { orbitClear(); orbitStatus(out.message || 'Search failed.', 'error'); return; }
    orbit.shownRequestId = out.requestId;
    orbitRenderSources(out.providers || []);
    if (!out.options.length) {
      orbitOptions.replaceChildren();
      orbitStatus(out.message || 'No matching game found. Try the full title.', 'error');
      return;
    }
    orbitRenderOptions(out.options);
    const base = out.didYouMean ? 'No exact match. Closest titles - pick the right one:' : `${out.options.length === 1 ? '1 match' : `${out.options.length} matches`} found - pick the right game:`;
    orbitStatus(out.message ? `${base} (${out.message})` : base, 'ready');
  }

  async function orbitChoose(index, card) {
    if (orbit.busy || orbit.shownRequestId == null || !orbit.pendingId) return;
    clearTimeout(orbit.timer);
    orbit.busy = true;
    orbitName.disabled = true;
    if (orbitGo) orbitGo.disabled = true;
    orbitOptions.querySelectorAll('button').forEach(b => { b.disabled = true; });
    card.classList.add('loading');
    orbitStatus(ORBIT_STAGE_TEXT.details, 'loading');
    const pendingId = orbit.pendingId;
    try {
      const res = await window.nexora.orbitChoose(pendingId, orbit.shownRequestId, index);
      if (res.status === 'accepted' && res.game) {
        upsertGame(res.game); renderGames(); renderPinned(); selectGame(res.game);
        closeOrbit(false);
        show(res.notices?.length ? `Game added. ${res.notices[0]}` : 'Game added.');
        return;
      }
      orbitStatus(res.reasons?.[0] || 'Could not load this game. Pick another option.', 'error');
    } catch {
      orbitStatus('Loading failed safely. Nothing was added.', 'error');
    }
    orbit.busy = false;
    if (orbit.pendingId === pendingId) {
      orbitName.disabled = false;
      if (orbitGo) orbitGo.disabled = false;
      card.classList.remove('loading');
      orbitOptions.querySelectorAll('button').forEach(b => { b.disabled = false; });
    }
  }

  function openOrbit(begun) {
    if (!orbitModal || !orbitName) return;
    orbit.pendingId = begun.pendingId;
    orbit.requestId = 0;
    orbit.busy = false;
    orbit.dirty = false;
    orbitClear();
    if (orbitExe) orbitExe.textContent = begun.exeFile || 'Windows executable';
    orbitName.disabled = false;
    orbitName.value = begun.suggestedName || '';
    orbit.unsubscribe?.();
    orbit.unsubscribe = typeof window.nexora.onOrbitProgress === 'function'
      ? window.nexora.onOrbitProgress((p) => {
          if (p.pendingId !== orbit.pendingId || !orbit.busy) return;
          const text = ORBIT_STAGE_TEXT[p.stage];
          if (text) orbitStatus(p.detail ? `${text} ${p.detail}` : text, 'loading');
        })
      : null;
    orbitModal.hidden = false;
    orbitName.focus();
    orbitName.select();
    orbitQueue(false); // name is pre-filled from the file; the search starts when the user presses Add Game
  }

  function closeOrbit(cancelOnMain = true) {
    if (!orbitModal || orbitModal.hidden) return;
    clearTimeout(orbit.timer);
    const pendingId = orbit.pendingId;
    orbitModal.hidden = true;
    orbit.pendingId = null;
    orbit.requestId += 1;
    orbit.busy = false;
    orbit.unsubscribe?.();
    orbit.unsubscribe = null;
    orbitClear();
    if (cancelOnMain && pendingId) window.nexora.orbitCancel(pendingId).catch(() => {});
  }

  const tryCloseOrbit = () => { if (!orbit.busy) closeOrbit(true); };
  orbitName?.addEventListener('input', () => orbitQueue(false));
  orbitGo?.addEventListener('click', () => orbitQueue(true));
  orbitName?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); orbitQueue(true); } });
  orbitClose?.addEventListener('click', tryCloseOrbit);
  orbitModal?.addEventListener('click', (event) => { if (event.target === orbitModal) tryCloseOrbit(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && orbitModal && !orbitModal.hidden) tryCloseOrbit(); });

  addGameBtn?.addEventListener('click', async () => {
    addGameBtn.disabled = true;
    show('Select a Windows .exe…');
    try {
      if (typeof window.nexora.beginAddGame === 'function') {
        const begun = await window.nexora.beginAddGame();
        if (begun.status === 'ready') openOrbit(begun);
        else if (begun.status === 'exists' && begun.game) { upsertGame(begun.game); renderGames(); renderPinned(); selectGame(begun.game); show('That game is already in your library.'); }
        return;
      }
      // Older bridge without ORBIT: previous Steam-only flow.
      const result = await window.nexora.addGame();
      if (result.status === 'accepted' && result.game) { upsertGame(result.game); renderGames(); renderPinned(); selectGame(result.game); show('Game added.'); }
      else if (result.status === 'ambiguous') openMetadata(result);
      else if (result.status !== 'cancelled') show('Could not verify this game. Nothing was added.');
    } catch (error) {
      show('Game lookup failed safely. Nothing was added.');
    } finally { addGameBtn.disabled = false; }
  });

  closeMetadata?.addEventListener('click', closeMetadataModal);
  metadataModal?.addEventListener('click', event => { if (event.target === metadataModal) closeMetadataModal(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && metadataModal && !metadataModal.hidden) closeMetadataModal(); });



  const PAD_CONTROLS = [
    { control: 'A', label: 'A (confirm / shot)' },
    { control: 'B', label: 'B (back / cancel)' },
    { control: 'X', label: 'X' },
    { control: 'Y', label: 'Y' },
    { control: 'L1', label: 'L1 / LB' },
    { control: 'R1', label: 'R1 / RB' },
    { control: 'L2', label: 'L2 / LT' },
    { control: 'R2', label: 'R2 / RT' },
    { control: 'L3', label: 'L3 (stick click)' },
    { control: 'R3', label: 'R3 (stick click)' },
    { control: 'Start', label: 'Start / Menu' },
    { control: 'Select', label: 'Select / View' },
    { control: 'DpadUp', label: 'D-pad Up' },
    { control: 'DpadDown', label: 'D-pad Down' },
    { control: 'DpadLeft', label: 'D-pad Left' },
    { control: 'DpadRight', label: 'D-pad Right' },
    { control: 'LeftStickY', label: 'Left stick Up', axisDir: 'neg' },
    { control: 'LeftStickY', label: 'Left stick Down', axisDir: 'pos' },
    { control: 'LeftStickX', label: 'Left stick Left', axisDir: 'neg' },
    { control: 'LeftStickX', label: 'Left stick Right', axisDir: 'pos' },
    { control: 'RightStickY', label: 'Right stick Up', axisDir: 'neg' },
    { control: 'RightStickY', label: 'Right stick Down', axisDir: 'pos' },
    { control: 'RightStickX', label: 'Right stick Left', axisDir: 'neg' },
    { control: 'RightStickX', label: 'Right stick Right', axisDir: 'pos' }
  ];

  function friendlyKeyName(code) {
    if (!code) return 'Not set';
    return String(code)
      .replace(/^Key/, '')
      .replace(/^Digit/, '')
      .replace(/^Arrow/, 'Arrow ')
      .replace(/^Control/, 'Ctrl')
      .replace(/^Shift/, 'Shift')
      .replace(/^Alt/, 'Alt')
      .replace(/Left$/, ' Left')
      .replace(/Right$/, ' Right')
      .replace(/^MouseLeft$/, 'Mouse Left')
      .replace(/^MouseRight$/, 'Mouse Right')
      .replace(/^Space$/, 'Space')
      .replace(/^Enter$/, 'Enter')
      .replace(/^Tab$/, 'Tab')
      .replace(/^Escape$/, 'Esc');
  }

  function bindingKey(b) {
    return `${b.control}:${b.axisDir || ''}`;
  }

  /** Full manual mapper — click a row, press any key. Nothing is locked. */
  function renderManualKeyMapper(host, profile, onSaved) {
    host.replaceChildren();
    const panel = create('div', 'km-panel');
    panel.append(create('h3', '', 'Manual key mapping'));
    panel.append(create('p', 'km-hint', 'Click a controller button, then press the keyboard key you want. For games like Cricket 22, the key will act like that controller button.'));

    const nameRow = create('div', 'km-toolbar');
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.maxLength = 48;
    nameInput.value = profile.name || 'My map';
    nameInput.placeholder = 'Map name';
    nameRow.append(nameInput);

    // Working copy of bindings
    const binds = new Map();
    for (const b of (profile.bindings || [])) {
      binds.set(bindingKey(b), { control: b.control, key: b.key, ...(b.axisDir ? { axisDir: b.axisDir } : {}) });
    }
    // Ensure every standard control exists so user can set them
    for (const c of PAD_CONTROLS) {
      const k = `${c.control}:${c.axisDir || ''}`;
      if (!binds.has(k)) binds.set(k, { control: c.control, key: '', ...(c.axisDir ? { axisDir: c.axisDir } : {}) });
    }

    let listening = null;
    let keyHandler = null;

    const stopListen = () => {
      if (keyHandler) window.removeEventListener('keydown', keyHandler, true);
      keyHandler = null;
      listening = null;
      panel.querySelectorAll('.km-bind.listening').forEach(el => el.classList.remove('listening'));
    };

    const grid = create('div', 'km-grid');

    const redraw = () => {
      grid.replaceChildren();
      for (const c of PAD_CONTROLS) {
        const k = `${c.control}:${c.axisDir || ''}`;
        const bind = binds.get(k);
        const btn = create('button', 'km-bind' + (listening === k ? ' listening' : ''));
        btn.type = 'button';
        const left = create('div');
        left.append(create('span', 'km-ctrl', c.label));
        if (c.axisDir) left.append(create('span', 'km-axis', c.axisDir === 'neg' ? ' (−)' : ' (+)'));
        const keyEl = create('span', 'km-key' + (!bind?.key ? ' empty' : ''), friendlyKeyName(bind?.key));
        btn.append(left, keyEl);
        btn.addEventListener('click', () => {
          if (listening === k) { stopListen(); redraw(); return; }
          stopListen();
          listening = k;
          show(`Press a key for ${c.label}… (Esc to clear)`);
          keyHandler = (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            const cur = binds.get(k) || { control: c.control, key: '', ...(c.axisDir ? { axisDir: c.axisDir } : {}) };
            if (ev.code === 'Escape') cur.key = '';
            else cur.key = ev.code;
            binds.set(k, cur);
            stopListen();
            redraw();
            show(cur.key ? `${c.label} → ${friendlyKeyName(cur.key)}` : `${c.label} cleared`);
          };
          window.addEventListener('keydown', keyHandler, true);
          redraw();
        });
        grid.append(btn);
      }
    };
    redraw();

    const actions = create('div', 'km-toolbar');
    const saveBtn = create('button', 'primary', 'Save map');
    saveBtn.addEventListener('click', async () => {
      stopListen();
      const bindings = [...binds.values()].filter(b => b.key);
      const id = profile.id && String(profile.id).startsWith('keymap_custom')
        ? profile.id
        : `keymap_custom_${Date.now().toString(36)}`;
      const payload = {
        id,
        name: (nameInput.value || 'My map').trim().slice(0, 48),
        description: 'Manual map — set by you',
        genre: 'custom',
        version: 1,
        bindings
      };
      try {
        await window.nexora.saveKeyMapProfile(payload);
        await window.nexora.setKeyMapActive(id);
        await window.nexora.setKeyMapMode('controller');
        show('Map saved. Keyboard will act like a controller.');
        if (typeof onSaved === 'function') onSaved();
      } catch {
        show('Could not save map.');
      }
    });
    const clearBtn = create('button', 'secondary', 'Clear all');
    clearBtn.addEventListener('click', async () => {
      if (!await askConfirm('Clear every key in this map?', { title: 'Clear map', okLabel: 'Clear' })) return;
      stopListen();
      for (const [k, b] of binds) binds.set(k, { ...b, key: '' });
      redraw();
      show('All keys cleared — click each button to set.');
    });
    const cancelBtn = create('button', 'secondary', 'Close');
    cancelBtn.addEventListener('click', () => {
      stopListen();
      host.replaceChildren();
    });
    actions.append(saveBtn, clearBtn, cancelBtn);

    panel.append(nameRow, grid, actions);
    host.append(panel);
  }

  function openKeyMapEditor(profile) {
    const page = document.getElementById('page');
    if (!page) return;
    // Ensure we are on controls page surface
    const host = create('div', 'km-editor-host');
    page.append(host);
    renderManualKeyMapper(host, profile || {
      id: '',
      name: 'My map',
      description: '',
      genre: 'custom',
      version: 1,
      bindings: []
    }, () => { void renderView('key-mapping'); });
  }


  const renderView = async (view) => {
    const home = document.getElementById('deskHome');
    const page = document.getElementById('page');
    if (view === 'dashboard' || view === 'games') {
      if (home) home.hidden = false;
      if (page) page.hidden = true;
      const libTitle = document.getElementById('library-title');
      if (libTitle) libTitle.textContent = view === 'games' ? 'Library' : 'All Games';
      renderGames();
      return;
    }
    if (home) home.hidden = true;
    if (!page) return;
    page.hidden = false;
    page.replaceChildren();
    const title = view === 'controls' ? 'Controls' : view === 'key-mapping' ? 'Key Mapping' : view === 'devices' ? 'Remote Play' : view === 'ai-patcher' ? 'AI Patcher' : 'Settings';
    const subtitle = view === 'controls' ? 'Choose your preferred controller visual and review phone control layouts' : view === 'key-mapping' ? 'Customize keyboard and controller bindings' : view === 'devices' ? 'Connect your phone with a short code' : view === 'ai-patcher' ? 'Describe a fix. Review the patch. Apply safely.' : 'Picture quality and updates';
    const head = create('div','section-head');
    const headText = create('div'); headText.append(create('h2','',title), create('span','',subtitle)); head.append(headText); page.append(head);
    const body = create('div','view-body');
    if (view === 'controls' || view === 'key-mapping') {
      if (view === 'controls') {
        const visualPanel = create('section', 'controller-visual-panel');
        visualPanel.append(create('div', 'controller-visual-heading', 'Controller preference'));
        visualPanel.append(create('p', 'empty-note', 'Choose which controller illustration to show here. This is a visual preference only; automatic device detection is not enabled in this phase.'));
        const choiceGrid = create('div', 'controller-choice-grid');
        let selectedVisual = 'playstation';
        try { selectedVisual = window.localStorage.getItem('nexora.ui.controllerVisual') === 'xbox' ? 'xbox' : 'playstation'; } catch { /* session default */ }
        const choices = [
          { id: 'playstation', title: 'PlayStation DualSense', description: 'PlayStation-style layout', asset: './assets/controller-playstation.svg' },
          { id: 'xbox', title: 'Xbox Wireless Controller', description: 'Xbox-style layout', asset: './assets/controller-xbox.svg' }
        ];
        const buttons = [];
        choices.forEach(choice => {
          const button = create('button', `controller-choice${selectedVisual === choice.id ? ' selected' : ''}`);
          button.type = 'button'; button.dataset.controllerVisual = choice.id; button.setAttribute('aria-pressed', String(selectedVisual === choice.id));
          const img = create('img'); img.src = choice.asset; img.alt = `${choice.title} illustration`;
          const copy = create('span', 'controller-choice-copy'); copy.append(create('b', '', choice.title), create('small', '', choice.description));
          button.append(img, copy);
          button.addEventListener('click', () => {
            selectedVisual = choice.id;
            try { window.localStorage.setItem('nexora.ui.controllerVisual', selectedVisual); } catch { /* visual selection remains active for this session */ }
            buttons.forEach(item => { const active = item.dataset.controllerVisual === selectedVisual; item.classList.toggle('selected', active); item.setAttribute('aria-pressed', String(active)); });
            const status = document.getElementById('controllerVisualStatus');
            if (status) status.textContent = `Selected visual: ${choice.title}. No device-detection claim is made.`;
          });
          buttons.push(button); choiceGrid.append(button);
        });
        visualPanel.append(choiceGrid);
        visualPanel.append(create('p', 'controller-visual-status', `Selected visual: ${choices.find(choice => choice.id === selectedVisual).title}. No device-detection claim is made.`));
        const status = visualPanel.querySelector('.controller-visual-status'); if (status) status.id = 'controllerVisualStatus';
        body.append(visualPanel);
      }
      // Key bindings live on their own page; Controls only shows controller visuals and phone layouts.
      if (view === 'key-mapping') {
      try {
        const km = typeof window.nexora.getKeyMap === 'function' ? await window.nexora.getKeyMap() : null;
        if (km) {
          body.append(create('p', 'empty-note', 'Games like Cricket 22 need a controller. NEXORA can turn keyboard keys into Xbox controller buttons so the game accepts them.'));
          const modeRow = create('div', 'setting-row');
          const modeCopy = create('div');
          const modeLabel =
            km.mode === 'controller' ? 'Keyboard acts like a controller (best for Cricket 22)'
            : km.mode === 'keyboard' ? 'Controller acts like a keyboard'
            : 'No conversion';
          modeCopy.append(create('b', '', 'Input mode'), create('small', '', modeLabel));
          const modeBtn = create('button', 'secondary',
            km.mode === 'controller' ? 'Switch mode' : km.mode === 'keyboard' ? 'Switch mode' : 'Switch mode');
          modeBtn.addEventListener('click', async () => {
            try {
              const next = km.mode === 'controller' ? 'keyboard' : km.mode === 'keyboard' ? 'off' : 'controller';
              await window.nexora.setKeyMapMode(next);
              void renderView(view === 'key-mapping' ? 'key-mapping' : 'controls');
              show(next === 'controller' ? 'Keyboard will mimic a controller' : next === 'keyboard' ? 'Controller will type keys' : 'Mapping off');
            } catch { show('Could not change input mode.'); }
          });
          modeRow.append(modeCopy, modeBtn);
          body.append(modeRow);

          (km.profiles || []).forEach(profile => {
            const row = create('div', 'setting-row');
            const copy = create('div');
            const active = profile.id === km.activeProfileId;
            copy.append(
              create('b', '', (active ? '✓ ' : '') + profile.name),
              create('small', '', profile.description || `${profile.bindings?.length || 0} keys mapped`)
            );
            const actions = create('div');
            actions.style.display = 'flex';
            actions.style.gap = '8px';
            if (!active) {
              const use = create('button', 'secondary', 'Use');
              use.addEventListener('click', async () => {
                try {
                  await window.nexora.setKeyMapActive(profile.id);
                  void renderView(view === 'key-mapping' ? 'key-mapping' : 'controls');
                  show(`Using ${profile.name}`);
                } catch { show('Could not switch map.'); }
              });
              actions.append(use);
            }
            const edit = create('button', 'secondary', 'Edit manually');
            edit.addEventListener('click', () => openKeyMapEditor(profile));
            actions.append(edit);
            const reset = create('button', 'secondary', 'Reset');
            reset.addEventListener('click', async () => {
              if (!await askConfirm(`Reset ${profile.name} to defaults?`, { title: 'Reset map', okLabel: 'Reset' })) return;
              try {
                await window.nexora.resetKeyMapProfile(profile.id);
                void renderView(view === 'key-mapping' ? 'key-mapping' : 'controls');
                show('Map reset.');
              } catch { show('Could not reset.'); }
            });
            actions.append(reset);
            row.append(copy, actions);
            body.append(row);
          });
          const createRow = create('div', 'setting-row');
          const createCopy = create('div');
          createCopy.append(create('b', '', 'Create your own map'), create('small', '', 'Set every key yourself — nothing is fixed'));
          const createBtn = create('button', 'primary', 'Map keys');
          createBtn.addEventListener('click', () => openKeyMapEditor({
            id: '', name: 'My map', description: '', genre: 'custom', version: 1, bindings: []
          }));
          createRow.append(createCopy, createBtn);
          body.append(createRow);
          body.append(create('p', 'empty-note', 'Or open a preset and press Edit keys to change any binding manually.'));
        }
      } catch { /* key map optional */ }
      }

      if (view === 'controls') {
      body.append(create('p', 'empty-note', 'On-screen touch layouts for your phone:'));
      try {
        const layouts = await window.nexora.listLayouts();
        if (!layouts.length) body.append(create('p','empty-note','No layouts yet. Default layouts will be created when the Host initializes.'));
        layouts.forEach(layout => {
          const card = create('div','setting-row');
          const copy = create('div'); copy.append(create('b','',layout.name), create('small','',`${layout.genre} · ${layout.controls.length} controls`));
          const edit = create('button','secondary','View layout');
          const detail = create('p','empty-note','');
          detail.hidden = true;
          edit.addEventListener('click', () => {
            if (!layout.controls.length) return show('This layout has no controls yet.');
            if (!detail.hidden) { detail.hidden = true; edit.textContent = 'View layout'; return; }
            const lines = layout.controls
              .slice()
              .sort((a, b) => (a.z || 0) - (b.z || 0) || String(a.label).localeCompare(String(b.label)))
              .map(c => `${c.label || c.id} (${c.type}${c.action ? ' · ' + c.action : ''})`)
              .join(' · ');
            detail.textContent = lines || 'No controls.';
            detail.hidden = false;
            edit.textContent = 'Hide';
          });
          card.append(copy, edit);
          body.append(card, detail);
        });
      } catch { body.append(create('p','empty-note','Control layouts are unavailable until the Host storage is initialized.')); }
      }
    } else if (view === 'devices') {
      body.append(create('div','device-status','● Host ready for receiver pairing'));
      body.append(create('p','empty-note','Generate a temporary 6-digit PIN on this PC. Enter the same PIN on the receiver to pair. PINs expire after about 2 minutes and are single-use.'));
      const pinRow = create('div','setting-row');
      const pinCopy = create('div');
      pinCopy.append(create('b','','Pairing PIN'), create('small','','Show a code the receiver can type'));
      const pinBtn = create('button','secondary','Show PIN');
      const pinOut = create('p','empty-note','');
      pinOut.hidden = true;
      pinBtn.addEventListener('click', async () => {
        try {
          const r = await window.nexora.openPairing();
          const until = r?.expiresAt ? new Date(r.expiresAt).toLocaleTimeString() : '';
          pinOut.textContent = r?.pin ? `PIN ${r.pin}  ·  expires ${until}` : 'Could not open pairing.';
          pinOut.hidden = false;
          show(r?.pin ? `Pairing PIN ${r.pin}` : 'Pairing unavailable.');
        } catch { show('Could not open pairing.'); }
      });
      pinRow.append(pinCopy, pinBtn); body.append(pinRow, pinOut);
      try {
        const devices = await window.nexora.listDevices();
        if (!devices.length) body.append(create('p','empty-note','No paired receivers yet.'));
        devices.forEach(d => {
          const row = create('div','setting-row');
          const copy = create('div');
          const seen = d.lastSeenAt ? formatDate(d.lastSeenAt) : 'never';
          copy.append(create('b','',d.name || 'Receiver'), create('small','',`ID ${String(d.deviceId).slice(0,8)}… · last seen ${seen}`));
          const rev = create('button','secondary','Revoke');
          rev.addEventListener('click', async () => {
            if (!await askConfirm(`Revoke ${d.name || 'this receiver'}? It will need to pair again.`, { title: 'Revoke device', okLabel: 'Revoke', danger: true })) return;
            try {
              await window.nexora.revokeDevice(d.deviceId);
              show('Device revoked.');
              void renderView('devices');
            } catch { show('Could not revoke device.'); }
          });
          row.append(copy, rev); body.append(row);
        });
      } catch { body.append(create('p','empty-note','Device list unavailable until the Host finishes starting.')); }
      const button = create('button','secondary','Return to Dashboard'); button.addEventListener('click',()=>document.querySelector('[data-view="dashboard"]').click()); body.append(button);
    } else if (view === 'ai-patcher') {
      body.append(create('p', 'empty-note', 'Describe a bug or change in plain language. NEXORA reads a limited set of source files, asks a cloud coding model for a proposed patch, then waits for your approval before touching project files.'));
      const panel = create('section', 'ai-patcher-panel');
      const settings = await window.nexora.getAiPatcherSettings();
      const providerRow = create('div', 'setting-row');
      const providerCopy = create('div');
      providerCopy.append(create('b', '', 'Cloud model'), create('small', '', 'Free access and quotas vary; Groq may bill by usage'));
      const provider = document.createElement('select');
      provider.className = 'ai-patcher-input';
      [['gemini','Google Gemini API'],['openrouter','OpenRouter · free router'],['groq','Groq API · check pricing']].forEach(([value,label]) => { const option = document.createElement('option'); option.value = value; option.textContent = label; provider.append(option); });
      provider.value = settings.provider || 'gemini';
      provider.addEventListener('change', () => {
        const defaults = { gemini: 'gemini-3.7-flash', groq: 'openai/gpt-oss-120b', openrouter: 'openrouter/free' };
        if (['gemini-3.7-flash','gemini-2.5-flash','openai/gpt-oss-120b','openrouter/free'].includes(model.value.trim())) model.value = defaults[provider.value] || defaults.gemini;
      });
      providerRow.append(providerCopy, provider); panel.append(providerRow);

      const modelRow = create('div', 'setting-row');
      const modelCopy = create('div'); modelCopy.append(create('b','','Model ID'), create('small','','Use a model ID supported by your chosen provider'));
      const model = document.createElement('input'); model.className = 'ai-patcher-input'; model.value = settings.model || 'gemini-3.7-flash'; model.placeholder = 'gemini-2.5-flash';
      modelRow.append(modelCopy, model); panel.append(modelRow);

      const keyRow = create('div', 'setting-row');
      const keyCopy = create('div'); keyCopy.append(create('b','','API key'), create('small','',settings.keyConfigured ? 'A key is saved encrypted on this PC. Enter a new key to replace it.' : 'Key is encrypted locally; code is sent only to the selected provider when you approve analysis.'));
      const key = document.createElement('input'); key.type = 'password'; key.autocomplete = 'new-password'; key.className = 'ai-patcher-input'; key.placeholder = settings.keyConfigured ? 'Saved securely · leave blank to keep' : 'Paste provider API key';
      keyRow.append(keyCopy, key); panel.append(keyRow);
      const saveRow = create('div','setting-row'); const saveCopy = create('div'); saveCopy.append(create('b','','Save provider settings'), create('small','','API keys are not shown back to the interface'));
      const save = create('button','primary','Save settings');
      save.addEventListener('click', async () => { try { const payload = { provider: provider.value, model: model.value.trim() }; if (key.value.trim()) payload.apiKey = key.value.trim(); const result = await window.nexora.setAiPatcherSettings(payload); key.value = ''; key.placeholder = result.keyConfigured ? 'Saved securely · leave blank to keep' : 'Paste provider API key'; keyCopy.querySelector('small').textContent = result.keyConfigured ? 'A key is saved encrypted on this PC.' : 'Add an API key to enable proposals.'; show('AI Patcher settings saved.'); } catch (error) { show(error?.message || 'Could not save AI settings.'); } });
      const clearKey = create('button','secondary','Clear key');
      clearKey.addEventListener('click', async () => { if (!await askConfirm('Remove the saved AI provider key from this PC?', { title: 'Remove API key', okLabel: 'Remove' })) return; try { const result = await window.nexora.setAiPatcherSettings({ provider: provider.value, model: model.value.trim(), apiKey: '' }); key.value = ''; key.placeholder = 'Paste provider API key'; keyCopy.querySelector('small').textContent = 'No API key saved.'; show('Saved key removed.'); } catch (error) { show(error?.message || 'Could not remove key.'); } });
      const saveActions = create('div'); saveActions.className = 'ai-patcher-actions'; saveActions.append(save, clearKey); saveRow.append(saveCopy, saveActions); panel.append(saveRow);

      const workspaceRow = create('div','setting-row'); const workspaceCopy = create('div'); workspaceCopy.append(create('b','','Project source folder'), create('small','',settings.workspace || 'No folder selected — choose the root of the source project you want to patch.'));
      const choose = create('button','secondary','Choose folder');
      choose.addEventListener('click', async () => { try { const r = await window.nexora.chooseAiPatcherWorkspace(); if (!r.cancelled) { show('Project folder selected.'); void renderView('ai-patcher'); } } catch (error) { show(error?.message || 'Could not select folder.'); } });
      workspaceRow.append(workspaceCopy, choose); panel.append(workspaceRow);
      body.append(panel);

      const requestLabel = create('label','ai-patcher-label','What should I fix or change?');
      const request = document.createElement('textarea'); request.className = 'ai-patcher-request'; request.rows = 5; request.maxLength = 4000; request.placeholder = 'Example: Fix the crash when the library opens. Find the root cause, keep the current UI, and add a regression test.';
      const requestHint = create('small','ai-patcher-hint','Be specific about what is broken, what should happen, and what must not change.');
      const toolsRow = create('div','ai-patcher-actions');
      const checkSelect = document.createElement('select'); checkSelect.className = 'ai-patcher-input';
      [['typecheck','Type check'],['build','Build'],['test','Tests']].forEach(([value,label]) => { const option = document.createElement('option'); option.value = value; option.textContent = label; checkSelect.append(option); });
      const runCheck = create('button','secondary','Run check');
      runCheck.addEventListener('click', async () => {
        const kind = checkSelect.value;
        if (!await askConfirm(`Run the selected project's \"${kind}\" script? Project scripts execute code from the folder you selected; only continue if you trust that project.`, { title: 'Run project check', okLabel: 'Run check' })) return;
        runCheck.disabled = true; runCheck.textContent = 'Running…';
        try { const r = await window.nexora.runAiPatchCheck(kind); const out = create('pre','ai-patcher-check-output',`${r.command} · ${r.ok ? 'PASSED' : `FAILED (${r.code ?? 'unknown'})`}\n\n${r.output || '(no output)'}`); result.replaceChildren(out); show(r.ok ? `${kind} passed.` : `${kind} failed. Review the output.`); }
        catch (error) { result.replaceChildren(create('p','ai-patcher-error',error?.message || 'Could not run check.')); }
        finally { runCheck.disabled = false; runCheck.textContent = 'Run check'; }
      });
      const rollback = create('button','secondary','Rollback last patch');
      rollback.addEventListener('click', async () => {
        if (!await askConfirm('Restore files from the backup made before the most recent AI patch? Changes made manually after that patch may be overwritten.', { title: 'Rollback last patch', okLabel: 'Restore backup', danger: true })) return;
        rollback.disabled = true;
        try { const r = await window.nexora.rollbackAiPatch(); result.replaceChildren(create('p','ai-patcher-summary',`Restored ${r.restored.length} file(s) from the last patch backup.`)); show('Last patch rolled back.'); }
        catch (error) { show(error?.message || 'Could not roll back.'); }
        finally { rollback.disabled = false; }
      });
      toolsRow.append(checkSelect, runCheck, rollback);
      const propose = create('button','primary','Analyze and propose patch');
      const result = create('div','ai-patcher-result');
      const status = create('p','ai-patcher-hint','Nothing changed yet. Proposals are reviewed before files are edited.');
      result.append(status);
      propose.addEventListener('click', async () => {
        if (request.value.trim().length < 8) { show('Describe the change in a little more detail.'); return; }
        if (!await askConfirm('The selected source files will be sent to your chosen cloud AI provider for analysis. Do not continue if the project contains confidential code or data you are not allowed to share.', { title: 'Send code to cloud AI?', okLabel: 'Analyze source' })) return;
        propose.disabled = true; propose.textContent = 'Analyzing project…'; result.replaceChildren(create('p','ai-patcher-hint','Reading project files and requesting a patch. This can take up to 90 seconds.'));
        try {
          const proposal = await window.nexora.proposeAiPatch(request.value.trim());
          result.replaceChildren();
          result.append(create('h3','','Proposed patch'), create('p','ai-patcher-summary',proposal.summary));
          if (!proposal.files.length) { result.append(create('p','ai-patcher-hint','No files were changed in this proposal. Add more context or make the request more specific.')); }
          proposal.files.forEach(file => {
            const details = document.createElement('details'); details.className = 'ai-patcher-file';
            const summary = document.createElement('summary'); summary.textContent = `${file.existed ? 'Modify' : 'Create'} · ${file.path}`;
            const explanation = create('p','ai-patcher-hint',file.summary);
            const pre = document.createElement('pre'); pre.textContent = file.diff || file.content; pre.setAttribute('aria-label', `Diff preview for ${file.path}`);
            details.append(summary, explanation, pre); result.append(details);
          });
          const actions = create('div','ai-patcher-actions');
          const apply = create('button','primary','Apply reviewed patch');
          const discard = create('button','secondary','Discard proposal');
          apply.disabled = !proposal.files.length;
          apply.addEventListener('click', async () => {
            if (!await askConfirm(`Apply ${proposal.files.length} file change(s) to the selected project? Existing files will be backed up first. Review the complete proposed contents before continuing.`, { title: 'Apply AI patch', okLabel: 'Apply patch' })) return;
            apply.disabled = true; apply.textContent = 'Applying…';
            try { const applied = await window.nexora.applyAiPatch(proposal.id); result.replaceChildren(create('h3','','Patch applied'), create('p','ai-patcher-summary',`Changed ${applied.changed.length} file(s). A backup was saved before editing.`)); const backup = create('p','ai-patcher-hint',`Backup location: ${applied.backup}`); result.append(backup, create('p','ai-patcher-hint','Run a project check below. If it fails, use Rollback last patch to restore the backup.')); show('Patch applied; backup created.'); }
            catch (error) { show(error?.message || 'Patch could not be applied.'); apply.disabled = false; apply.textContent = 'Apply reviewed patch'; }
          });
          discard.addEventListener('click', async () => { try { await window.nexora.discardAiPatch(); result.replaceChildren(create('p','ai-patcher-hint','Proposal discarded. No files were changed.')); } catch { show('Could not discard proposal.'); } });
          actions.append(apply, discard); result.append(actions);
          if (!proposal.files.length) result.append(create('p','ai-patcher-hint','No files have been changed.'));
        } catch (error) { result.replaceChildren(create('p','ai-patcher-error',error?.message || 'Could not create a patch. Check the provider, API key, network, and selected folder.')); }
        finally { propose.disabled = false; propose.textContent = 'Analyze and propose patch'; }
      });
      body.append(requestLabel, request, requestHint, toolsRow, propose, result);
    } else {
      let cfg = null;
      let capabilities = { startupSupported: false, startupWarning: null, storagePath: 'App data folder' };
      try { cfg = await window.nexora.getConfig(); } catch { cfg = null; }
      try { capabilities = { ...capabilities, ...(await window.nexora.getSettingsCapabilities()) }; } catch { /* older bridge */ }

      const categories = [
        { id: 'general', label: 'General', icon: '⚙' },
        { id: 'appearance', label: 'Appearance', icon: '◐' },
        { id: 'streaming', label: 'Streaming', icon: '▤' },
        { id: 'network', label: 'Network', icon: '⌁' },
        { id: 'updates', label: 'Updates', icon: '↻' },
        { id: 'privacy', label: 'Privacy & Security', icon: '◇' }
      ];
      if (!categories.some(item => item.id === settingsCategory)) settingsCategory = 'general';
      const tabs = create('div', 'settings-tabs');
      tabs.setAttribute('role', 'tablist');
      tabs.setAttribute('aria-label', 'Settings categories');
      categories.forEach((item) => {
        const tab = create('button', `settings-tab${settingsCategory === item.id ? ' active' : ''}`);
        tab.type = 'button';
        tab.setAttribute('role', 'tab');
        tab.setAttribute('aria-selected', String(settingsCategory === item.id));
        tab.setAttribute('aria-controls', 'settingsCategoryBody');
        tab.append(create('span', 'settings-tab-icon', item.icon), create('span', '', item.label));
        tab.addEventListener('click', () => {
          settingsCategory = item.id;
          void renderView('settings');
        });
        tabs.append(tab);
      });
      body.append(tabs);
      const settingsBody = create('div', 'settings-category-body');
      settingsBody.id = 'settingsCategoryBody';
      settingsBody.setAttribute('role', 'tabpanel');
      body.append(settingsBody);

      const applyModeUi = (mode) => document.body.classList.toggle('power-saving', mode === 'power_saving');
      if (cfg?.mode) applyModeUi(cfg.mode);
      const savePatch = async (patch, successMessage = 'Settings saved.') => {
        try {
          cfg = await window.nexora.setConfig(patch);
          applyPreferences(cfg);
          applyQuality(cfg);
          applyModeUi(cfg.mode);
          if (document.getElementById('cxStreamQuality') && cfg.video) {
            document.getElementById('cxStreamQuality').textContent = `${cfg.video.height}p · ${cfg.video.fps} FPS`;
          }
          if (successMessage) show(successMessage);
          return true;
        } catch (error) {
          show(error?.message || 'Could not save settings. Your previous values were kept.');
          return false;
        }
      };
      const addRow = (parent, title, description, control, extraClass = '') => {
        const row = create('div', `setting-row${extraClass ? ` ${extraClass}` : ''}`);
        const copy = create('div', 'setting-row-copy');
        copy.append(create('b', '', title), create('small', '', description));
        row.append(copy, control);
        parent.append(row);
        return row;
      };
      const addSelect = (parent, title, description, value, options, onChange) => {
        const select = document.createElement('select');
        select.className = 'settings-select';
        select.setAttribute('aria-label', title);
        options.forEach(([optionValue, label]) => {
          const option = document.createElement('option');
          option.value = optionValue; option.textContent = label;
          select.append(option);
        });
        select.value = value;
        select.addEventListener('change', () => { void onChange(select.value); });
        addRow(parent, title, description, select);
        return select;
      };
      const addToggle = (parent, title, description, checked, disabled, onChange, statusText = '') => {
        const wrapper = create('label', 'settings-toggle');
        const input = document.createElement('input');
        input.type = 'checkbox'; input.checked = checked; input.disabled = disabled;
        const track = create('span', 'settings-toggle-track');
        track.setAttribute('aria-hidden', 'true');
        wrapper.append(input, track);
        if (statusText) wrapper.title = statusText;
        input.addEventListener('change', () => { void onChange(input.checked, input); });
        addRow(parent, title, description, wrapper);
        return input;
      };
      const addSectionHeading = (title, subtitle) => {
        const heading = create('div', 'settings-section-heading');
        heading.append(create('h3', '', title), create('p', '', subtitle));
        settingsBody.append(heading);
      };

      if (settingsCategory === 'general') {
        addSectionHeading('General', 'Personalize this PC and decide how NEXORA opens.');
        const nameInput = document.createElement('input');
        nameInput.type = 'text'; nameInput.className = 'settings-input';
        nameInput.value = cfg?.profileName || 'My PC'; nameInput.maxLength = 32;
        nameInput.autocomplete = 'off'; nameInput.spellcheck = false;
        nameInput.setAttribute('aria-label', 'PC display name');
        const nameSave = create('button', 'secondary', 'Save name');
        nameSave.addEventListener('click', async () => {
          const name = nameInput.value.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 32);
          if (!name) { show('Enter a name between 1 and 32 characters.'); nameInput.focus(); return; }
          nameInput.value = name;
          await savePatch({ profileName: name }, `PC name changed to “${name}”.`);
        });
        addRow(settingsBody, 'PC display name', 'Shown in Desktop Mode and Console Mode.', (() => { const group = create('div', 'settings-control-group'); group.append(nameInput, nameSave); return group; })());

        addToggle(settingsBody, 'Open NEXORA with Windows', 'Starts NEXORA when you sign in. Requires the installed Windows build.', cfg?.startWithWindows === true, !capabilities.startupSupported, async (checked, input) => {
          const ok = await savePatch({ startWithWindows: checked }, checked ? 'Startup preference saved.' : 'Startup preference turned off.');
          if (!ok) input.checked = cfg?.startWithWindows === true;
          if (ok && typeof window.nexora.getSettingsCapabilities === 'function') {
            try {
              const refreshed = await window.nexora.getSettingsCapabilities();
              if (refreshed.startupWarning) show(refreshed.startupWarning);
            } catch { /* saved settings remain available even if capability refresh fails */ }
          }
        }, capabilities.startupSupported ? '' : 'Available in the packaged Windows app');
        if (!capabilities.startupSupported) settingsBody.append(create('p', 'settings-inline-note', 'Windows startup registration becomes available in the packaged Windows application. This preview/development build cannot register itself at sign-in.'));
        if (capabilities.startupWarning) settingsBody.append(create('p', 'settings-inline-note', capabilities.startupWarning));

        addSelect(settingsBody, 'Launch view', 'Choose which interface opens the next time NEXORA starts.', cfg?.launchMode || 'desktop', [['desktop', 'Desktop Mode'], ['console', 'Console Mode']], async (value) => {
          await savePatch({ launchMode: value }, value === 'console' ? 'Console Mode will open next time NEXORA starts.' : 'Desktop Mode will open next time NEXORA starts.');
          // Rebuild from the last persisted config even if saving failed, so the control cannot lie.
          void renderView('settings');
        });

        const hint = create('div', 'settings-info-card');
        hint.append(create('b', '', 'Preferences sync across both modes'), create('p', '', 'Your theme, accent, reduced-motion setting, PC name, and saved stream profile are shared by Desktop Mode and Console Mode. They are stored locally on this PC.'));
        settingsBody.append(hint);
      } else if (settingsCategory === 'appearance') {
        addSectionHeading('Appearance', 'Customize the glass interface without changing your library or streaming settings.');
        addSelect(settingsBody, 'Interface theme', 'Switch between the default midnight, monochrome obsidian, and warmer earth-horizon palettes.', cfg?.appearance?.theme || 'midnight', [
          ['midnight', 'Midnight glass'], ['obsidian', 'Obsidian'], ['earth', 'Earth horizon']
        ], async (value) => {
          await savePatch({ appearance: { ...cfg?.appearance, theme: value } }, 'Theme applied across both modes.');
          // Rebuild from the persisted value on both success and failure.
          void renderView('settings');
        });

        const accentSection = create('section', 'settings-accent-section');
        accentSection.append(create('b', '', 'Accent color'), create('p', '', 'Used for focus, selection, buttons, and highlights in both modes.'));
        const swatches = create('div', 'settings-accent-grid');
        const colors = [
          ['cyan', 'Cyan', '#94c0c1'], ['blue', 'Blue', '#5b9dff'], ['violet', 'Violet', '#a18aff'],
          ['amber', 'Amber', '#e6b25f'], ['emerald', 'Emerald', '#58d6a6'], ['rose', 'Rose', '#ff82a8']
        ];
        colors.forEach(([id, label, color]) => {
          const button = create('button', 'settings-accent');
          button.type = 'button'; button.dataset.accent = id;
          button.setAttribute('aria-label', `${label} accent`);
          button.setAttribute('aria-pressed', String((cfg?.appearance?.accent || 'cyan') === id));
          button.append(create('span', 'settings-accent-dot'));
          button.querySelector('.settings-accent-dot').style.background = color;
          button.append(create('span', '', label));
          button.addEventListener('click', async () => {
            if (await savePatch({ appearance: { ...cfg?.appearance, accent: id } }, `${label} accent applied.`)) {
              swatches.querySelectorAll('.settings-accent').forEach(item => item.setAttribute('aria-pressed', String(item.dataset.accent === id)));
            }
          });
          swatches.append(button);
        });
        accentSection.append(swatches);
        settingsBody.append(accentSection);

        addToggle(settingsBody, 'Reduced motion', 'Turn down decorative transitions and animated effects, including Console Mode.', cfg?.appearance?.reducedMotion === true, false, async (checked, input) => {
          const ok = await savePatch({ appearance: { ...cfg?.appearance, reducedMotion: checked } }, checked ? 'Reduced motion enabled.' : 'Reduced motion disabled.');
          if (!ok) input.checked = cfg?.appearance?.reducedMotion === true;
        });
        addSelect(settingsBody, 'Default no-game background', 'Choose the scenery shown when no game is selected. The same background is used behind the glass in Desktop and Console Mode.', cfg?.appearance?.emptyLibraryBackground || activeEmptyBackgroundId, EMPTY_BACKGROUND_OPTIONS.map(item => [item.id, item.label]), async (value) => {
          const ok = await savePatch({ appearance: { ...cfg?.appearance, emptyLibraryBackground: value } }, 'Default background saved.');
          if (ok) setEmptyLibraryBackground(value);
          void renderView('settings');
        });
        addToggle(settingsBody, 'Rotate background on each launch', 'Advance to the next scene whenever NEXORA opens. Turn this off to keep the selected scene.', cfg?.appearance?.rotateEmptyBackground !== false, false, async (checked, input) => {
          const ok = await savePatch({ appearance: { ...cfg?.appearance, rotateEmptyBackground: checked } }, checked ? 'Background rotation enabled.' : 'Background rotation disabled.');
          if (!ok) input.checked = cfg?.appearance?.rotateEmptyBackground !== false;
        });
        settingsBody.append(create('p', 'settings-inline-note', 'Appearance changes apply immediately and are saved in the NEXORA settings file.'));
      } else if (settingsCategory === 'streaming') {
        addSectionHeading('Streaming', 'Choose the host mode and default picture profile. These saved settings are the source of truth for the capture pipeline.');
        settingsBody.append(create('p', 'empty-note', 'Host mode controls the preferred stream quality and UI cost. Quality changes are saved now; the live capture engine will consume these values when a stream is running.'));
        const modes = [
          { id: 'balanced', label: 'Balanced', desc: 'Best everyday choice' },
          { id: 'power_saving', label: 'Power Saving', desc: 'Uses less power on PC and phone' },
          { id: 'data_saver', label: 'Data Saver', desc: 'Caps stream quality to conserve data' },
          { id: 'performance', label: 'Performance', desc: 'Higher quality when the connection is strong' }
        ];
        modes.forEach(m => {
          const active = cfg?.mode === m.id;
          const btn = create('button', `secondary${active ? ' settings-selected' : ''}`, active ? 'Active' : 'Use mode');
          if (active) btn.disabled = true;
          btn.setAttribute('aria-pressed', String(active));
          btn.addEventListener('click', async () => {
            if (await savePatch({ mode: m.id }, `${m.label} mode enabled.`)) void renderView('settings');
          });
          addRow(settingsBody, m.label, m.desc, btn);
        });

        settingsBody.append(create('div', 'settings-divider'));
        settingsBody.append(create('p', 'empty-note', 'Quality preset (used in Balanced and Performance; Power Saving and Data Saver may override it).'));
        const presets = [
          { id: '480p', label: 'Light · 480p', desc: 'Easiest on slower connections' },
          { id: '720p', label: 'Smooth · 720p', desc: 'A good baseline for most networks' },
          { id: '1080p', label: 'HD · 1080p', desc: 'Clear picture on a capable link' },
          { id: '1440p', label: 'Ultra · 1440p', desc: 'Highest detail; needs more host and network capacity' }
        ];
        presets.forEach(q => {
          const active = cfg?.qualityPreset === q.id;
          const btn = create('button', `secondary${active ? ' settings-selected' : ''}`, active ? 'Selected' : 'Select');
          if (active) btn.disabled = true;
          btn.setAttribute('aria-pressed', String(active));
          btn.addEventListener('click', async () => {
            if (await savePatch({ qualityPreset: q.id }, `Picture profile set to ${q.label}.`)) void renderView('settings');
          });
          addRow(settingsBody, q.label, q.desc, btn);
        });
        if (cfg?.video) {
          const info = create('div', 'settings-info-card');
          info.append(create('b', '', `Effective output: ${cfg.video.width} × ${cfg.video.height} at ${cfg.video.fps} FPS`), create('p', '', `Current profile: ${friendlyQuality(cfg)}. Target bitrate: ${cfg.video.bitrateKbps} Kbps. Actual delivered quality depends on the active capture/transport implementation and network conditions.`));
          settingsBody.append(info);
        }
      } else if (settingsCategory === 'network') {
        addSectionHeading('Network & devices', 'Review saved receiver trust and open the dedicated Remote Play controls.');
        let pairedDevices = [];
        try { pairedDevices = await window.nexora.listDevices(); } catch { pairedDevices = []; }
        const pairRow = create('div', 'settings-info-card');
        pairRow.append(create('b', '', `${pairedDevices.length} paired receiver${pairedDevices.length === 1 ? '' : 's'}`));
        pairRow.append(create('p', '', pairedDevices.length ? 'Only receivers saved in this host’s trusted-device list appear here.' : 'No receiver is currently paired with this host. Open Remote Play to create a pairing PIN and manage trusted devices.'));
        const manage = create('button', 'secondary', 'Manage Remote Play');
        manage.addEventListener('click', () => document.querySelector('[data-view="devices"]')?.click());
        pairRow.append(manage);
        settingsBody.append(pairRow);
        const security = create('div', 'settings-info-card');
        security.append(create('b', '', 'Security controls stay explicit'), create('p', '', 'Paired-device revocation and PIN/session controls remain in Remote Play. NEXORA does not expose a switch here for network services that are not currently running, so this page will not imply that a transport toggle is active when it is not.'));
        settingsBody.append(security);
      } else if (settingsCategory === 'updates') {
        const version = typeof window.nexora?.getVersion === 'function'
          ? await window.nexora.getVersion().catch(() => 'unknown')
          : 'browser preview';
        const versionRow = create('div', 'setting-row');
        const versionCopy = create('div'); versionCopy.append(create('b', '', `NEXORA Host ${version}`), create('small', '', 'Check signed online updates or install a trusted local update file.'));
        const update = create('button', 'secondary', 'Check for updates');
        update.addEventListener('click', async () => {
          update.disabled = true; update.textContent = 'Checking…';
          try {
            const r = await window.nexora.checkForUpdate();
            if (r?.reason === 'Update service not configured') show('Online updates are not set up. Use “Update from a file” below.');
            else if (r?.reason === 'Invalid update signature') show('This update could not be verified, so it was not installed.');
            else if (r?.reason) show(r.reason);
            else if (!r?.available || !r.manifest) show('NEXORA is up to date.');
            else if (await askConfirm(`NEXORA ${r.manifest.version} is available. NEXORA will close, update and start again.`, { title: 'Update available', okLabel: 'Update now' })) {
              show('Preparing the update…'); await window.nexora.stageUpdate(r.manifest);
            }
          } catch { show('Could not check for updates. Check your internet connection.'); }
          finally { update.disabled = false; update.textContent = 'Check for updates'; }
        });
        versionRow.append(versionCopy, update); settingsBody.append(versionRow);

        try {
          const us = typeof window.nexora.getUpdateSettings === 'function' ? await window.nexora.getUpdateSettings() : null;
          settingsBody.append(create('p', 'empty-note', us?.configured
            ? (us.envLocked ? 'Online updates are configured (locked by environment variables).' : 'Online updates are configured.')
            : 'Online updates are not set up. Enter the HTTPS manifest URL and release public key below, or use “Update from a file”.'));
          if (us && !us.envLocked) {
            const urlRow = create('div', 'setting-row');
            const urlCopy = create('div'); urlCopy.append(create('b', '', 'Manifest URL'), create('small', '', 'HTTPS address of the signed update manifest'));
            const urlInput = document.createElement('input'); urlInput.type = 'url'; urlInput.placeholder = 'https://…/manifest.json';
            urlInput.value = us.manifestUrl || ''; urlInput.className = 'settings-input'; urlInput.setAttribute('aria-label', 'Update manifest URL');
            urlRow.append(urlCopy, urlInput); settingsBody.append(urlRow);
            const keyRow = create('div', 'setting-row');
            const keyCopy = create('div'); keyCopy.append(create('b', '', 'Release public key'), create('small', '', 'Base64 Ed25519 key used to verify update manifests'));
            const keyInput = document.createElement('input'); keyInput.type = 'text'; keyInput.placeholder = 'Base64 public key'; keyInput.value = '';
            keyInput.className = 'settings-input'; keyInput.setAttribute('aria-label', 'Release public key');
            keyRow.append(keyCopy, keyInput); settingsBody.append(keyRow);
            const saveRow = create('div', 'setting-row');
            const saveCopy = create('div'); saveCopy.append(create('b', '', 'Save update settings'), create('small', '', 'Stored separately under app data / update /'));
            const saveBtn = create('button', 'secondary', 'Save');
            saveBtn.addEventListener('click', async () => {
              try {
                const payload = { manifestUrl: urlInput.value.trim() };
                if (keyInput.value.trim()) payload.publicKeyB64 = keyInput.value.trim();
                const r = await window.nexora.setUpdateSettings(payload);
                show(r?.configured ? 'Online updates configured.' : 'Saved. Add both URL and public key to enable checks.');
                void renderView('settings');
              } catch (err) { show(err instanceof Error ? err.message : 'Could not save update settings.'); }
            });
            saveRow.append(saveCopy, saveBtn); settingsBody.append(saveRow);
          }
        } catch { settingsBody.append(create('p', 'settings-inline-note', 'Update configuration is unavailable in this build.')); }

        const localUpdate = async (mode, button, label) => {
          const ok = await askConfirm(
            mode === 'patch'
              ? 'Choose the patch file, then NEXORA saves a backup before applying it. Only use update files from a source you trust.'
              : 'Choose a backup file you saved earlier. NEXORA returns to that version while preserving your games and settings.',
            { title: mode === 'patch' ? 'Update from a file' : 'Restore a backup', okLabel: 'Choose file…' }
          );
          if (!ok) return;
          button.disabled = true;
          try {
            const r = await window.nexora.updateFromFile(mode);
            if (r?.status === 'started') show('NEXORA is closing to finish. A progress window will open.');
            else if (r?.status === 'unavailable' || r?.status === 'rejected') show(r.reason || 'That file cannot be used.');
          } catch { show('Could not start. Nothing was changed.'); }
          finally { button.disabled = false; button.textContent = label; }
        };
        const patchRow = create('div', 'setting-row');
        const patchCopy = create('div'); patchCopy.append(create('b', '', 'Update from a file'), create('small', '', 'Choose a patch .zip; a backup is saved before replacement.'));
        const patchBtn = create('button', 'secondary', 'Choose patch…');
        patchBtn.addEventListener('click', () => { void localUpdate('patch', patchBtn, 'Choose patch…'); });
        patchRow.append(patchCopy, patchBtn); settingsBody.append(patchRow);
        const restoreRow = create('div', 'setting-row');
        const restoreCopy = create('div'); restoreCopy.append(create('b', '', 'Restore a backup'), create('small', '', 'Return to a previous NEXORA build you backed up.'));
        const restoreBtn = create('button', 'secondary', 'Choose backup…');
        restoreBtn.addEventListener('click', () => { void localUpdate('restore', restoreBtn, 'Choose backup…'); });
        restoreRow.append(restoreCopy, restoreBtn); settingsBody.append(restoreRow);
      } else {
        addSectionHeading('Privacy & security', 'Your preferences stay on this PC. Export or restore a settings backup when needed.');
        const storage = create('div', 'settings-info-card');
        storage.append(create('b', '', 'Local settings storage'), create('p', '', `Preferences and stream defaults are saved in NEXORA’s app-data configuration file. ${capabilities.storagePath || ''}`));
        settingsBody.append(storage);
        const exportRow = create('div', 'setting-row');
        const exportCopy = create('div'); exportCopy.append(create('b', '', 'Export settings backup'), create('small', '', 'Save a JSON backup of app preferences and stream defaults. AI provider secrets, paired-device identities, and update signing material are not included.'));
        const exportBtn = create('button', 'secondary', 'Export…');
        exportBtn.addEventListener('click', async () => {
          exportBtn.disabled = true;
          try { const result = await window.nexora.exportSettings(); if (!result.cancelled) show(`Settings exported to ${result.fileName}.`); }
          catch (error) { show(error?.message || 'Could not export settings.'); }
          finally { exportBtn.disabled = false; }
        });
        exportRow.append(exportCopy, exportBtn); settingsBody.append(exportRow);

        const importRow = create('div', 'setting-row');
        const importCopy = create('div'); importCopy.append(create('b', '', 'Import settings backup'), create('small', '', 'Validate and restore a NEXORA JSON backup. This replaces the current app and stream preferences, not games or paired devices.'));
        const importBtn = create('button', 'secondary', 'Import…');
        importBtn.addEventListener('click', async () => {
          if (!await askConfirm('Importing replaces your current app preferences and stream defaults. Your library, paired devices, AI provider credentials, and update signing settings are kept. Continue?', { title: 'Import settings', okLabel: 'Choose backup…' })) return;
          importBtn.disabled = true;
          try {
            const result = await window.nexora.importSettings();
            if (result.cancelled || !result.config) return;
            cfg = result.config; applyPreferences(cfg); applyQuality(cfg); applyModeUi(cfg.mode);
            show('Settings imported and applied.'); void renderView('settings');
          } catch (error) { show(error?.message || 'Settings could not be imported. Your previous settings were preserved.'); }
          finally { importBtn.disabled = false; }
        });
        importRow.append(importCopy, importBtn); settingsBody.append(importRow);

        const resetRow = create('div', 'setting-row');
        const resetCopy = create('div'); resetCopy.append(create('b', '', 'Reset app preferences'), create('small', '', 'Restore NEXORA defaults for appearance, launch behavior, and stream presets. Your games and device pairings remain.'));
        const resetBtn = create('button', 'secondary danger', 'Reset to defaults');
        resetBtn.addEventListener('click', async () => {
          if (!await askConfirm('Reset appearance, launch behavior, and streaming defaults? Your game library, paired receivers, AI provider credentials, and update settings will remain.', { title: 'Reset settings', okLabel: 'Reset settings', danger: true })) return;
          resetBtn.disabled = true;
          try {
            cfg = await window.nexora.resetSettings(); applyPreferences(cfg); applyQuality(cfg); applyModeUi(cfg.mode);
            try { window.localStorage.removeItem('nexora.ui.sidebarCollapsed'); } catch { /* clear layout preference when storage is available */ }
            applySidebarPreference();
            settingsCategory = 'general'; show('NEXORA preferences were reset to defaults.'); void renderView('settings');
          } catch (error) { show(error?.message || 'Settings could not be reset.'); }
          finally { resetBtn.disabled = false; }
        });
        resetRow.append(resetCopy, resetBtn); settingsBody.append(resetRow);
      }
    }


    page.append(body);
  };

  document.querySelector('.stream-bar .power')?.addEventListener('click', () => {
    show('No active stream to stop.');
  });
  document.querySelector('.stream-bar .quality')?.addEventListener('click', () => {
    document.querySelector('[data-view="settings"]')?.click();
  });

  // The desktop sidebar can collapse to icons; this is a layout preference, not app/game data.
  const sidebarCollapseBtn = document.getElementById('sidebarCollapseBtn');
  function applySidebarPreference() {
    let collapsed = false;
    try { collapsed = window.localStorage.getItem('nexora.ui.sidebarCollapsed') === '1'; } catch { /* storage can be disabled by policy */ }
    document.body.classList.toggle('sidebar-collapsed', collapsed);
    if (sidebarCollapseBtn) {
      sidebarCollapseBtn.textContent = collapsed ? '›' : '‹';
      sidebarCollapseBtn.setAttribute('aria-pressed', String(collapsed));
      sidebarCollapseBtn.setAttribute('aria-label', collapsed ? 'Expand sidebar' : 'Collapse sidebar');
      sidebarCollapseBtn.title = collapsed ? 'Expand sidebar' : 'Collapse sidebar';
    }
    document.querySelectorAll('.nav-item[data-view]').forEach((item) => {
      const label = item.querySelector('span:not(.icon)')?.textContent?.trim();
      if (label) item.title = label;
    });
  }
  sidebarCollapseBtn?.addEventListener('click', () => {
    const collapsed = !document.body.classList.contains('sidebar-collapsed');
    document.body.classList.toggle('sidebar-collapsed', collapsed);
    try { window.localStorage.setItem('nexora.ui.sidebarCollapsed', collapsed ? '1' : '0'); } catch { /* collapsed state still works for this session */ }
    if (sidebarCollapseBtn) {
      sidebarCollapseBtn.textContent = collapsed ? '›' : '‹';
      sidebarCollapseBtn.setAttribute('aria-pressed', String(collapsed));
      sidebarCollapseBtn.setAttribute('aria-label', collapsed ? 'Expand sidebar' : 'Collapse sidebar');
      sidebarCollapseBtn.title = collapsed ? 'Expand sidebar' : 'Collapse sidebar';
    }
  });
  applySidebarPreference();

  document.getElementById('quickQualityBtn')?.addEventListener('click', () => {
    settingsCategory = 'streaming';
    document.querySelector('[data-view="settings"]')?.click();
  });
  document.getElementById('consoleToggle')?.addEventListener('click', () => enterConsoleMode());
  document.getElementById('deskSearchBtn')?.addEventListener('click', () => {
    document.querySelector('[data-view="games"]')?.click();
    show(games.length ? 'Scroll your library, or add a new game.' : 'Add a game to start.');
  });
  document.getElementById('winConsoleBtn')?.addEventListener('click', () => {
    if (consoleMode) exitConsoleMode();
    else enterConsoleMode();
  });
  document.getElementById('winMin')?.addEventListener('click', () => {
    if (typeof window.nexora?.windowMinimize === 'function') void window.nexora.windowMinimize();
  });
  document.getElementById('winMax')?.addEventListener('click', async () => {
    if (typeof window.nexora?.windowMaximize !== 'function') return;
    const maxed = await window.nexora.windowMaximize();
    const btn = document.getElementById('winMax');
    if (btn) btn.textContent = maxed ? '❐' : '□';
  });
  document.getElementById('winClose')?.addEventListener('click', () => {
    if (typeof window.nexora?.windowClose === 'function') void window.nexora.windowClose();
  });

  
  document.getElementById('cxViewBtn')?.addEventListener('click', () => {
    const g = games.find(x => x.id === selectedGameId);
    openConsoleDetail(g);
  });
  document.getElementById('cxDetailClose')?.addEventListener('click', closeConsoleDetail);
  document.getElementById('cxDetailDesktop')?.addEventListener('click', () => { closeConsoleDetail(); exitConsoleMode(); });
  document.getElementById('cxdViewBack')?.addEventListener('click', closeConsoleDetail);
  document.getElementById('cxdPlay')?.addEventListener('click', () => document.getElementById('cxPlayBtn')?.click());
  document.getElementById('cxdMediaPlay')?.addEventListener('click', () => document.getElementById('cxPlayBtn')?.click());


  document.getElementById('cxActionSettings')?.addEventListener('click', () => {
    settingsCategory = 'general';
    exitConsoleMode();
    document.querySelector('[data-view="settings"]')?.click();
  });
  document.getElementById('cxActionUpdates')?.addEventListener('click', async () => {
    settingsCategory = 'updates';
    exitConsoleMode();
    document.querySelector('[data-view="settings"]')?.click();
    show('Checking for updates…');
    try {
      const r = await window.nexora.checkForUpdate();
      if (r?.reason === 'Update service not configured') show('Online updates are not set up. Open Settings to configure or update from a file.');
      else if (r?.reason) show(r.reason);
      else if (!r?.available) show('NEXORA is up to date.');
      else show(`Update ${r.manifest?.version || ''} is available in Settings.`);
    } catch { show('Could not check for updates.'); }
  });
  const qualityOrder = ['480p', '720p', '1080p', '1440p'];
  document.getElementById('cxActionQuality')?.addEventListener('click', async (ev) => {
    const goPrev = ev.target?.classList?.contains('cx-chev') && String(ev.target.textContent || '').includes('‹');
    try {
      const cfg = await window.nexora.getConfig();
      const cur = cfg?.video?.height <= 480 ? '480p' : cfg?.video?.height <= 720 ? '720p' : cfg?.video?.height <= 1080 ? '1080p' : '1440p';
      let i = qualityOrder.indexOf(cur);
      if (i < 0) i = 1;
      i = goPrev ? (i + qualityOrder.length - 1) % qualityOrder.length : (i + 1) % qualityOrder.length;
      const next = qualityOrder[i];
      const updated = await window.nexora.setConfig({ qualityPreset: next });
      applyQuality(updated);
      show(`Picture: ${friendlyQuality(updated)} (${updated.video.height}p)`);
    } catch {
      settingsCategory = 'streaming';
      exitConsoleMode();
      document.querySelector('[data-view="settings"]')?.click();
      show('Choose picture quality in Settings.');
    }
  });
  document.getElementById('cxActionStream')?.addEventListener('click', () => {
    const g = games.find(x => x.id === selectedGameId);
    show(g
      ? `“${g.metadata?.title || g.name}” — open NEXORA on your phone to play.`
      : 'Pick a game, then open NEXORA on your phone.');
  });


  document.getElementById('viewAllGames')?.addEventListener('click', () => {
    document.querySelector('[data-view="games"]')?.click();
  });

  document.querySelectorAll('.nav-item').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    void renderView(btn.dataset.view || 'dashboard');
  }));

  document.querySelectorAll('[data-action]').forEach(btn => btn.addEventListener('click', () => {
    const action = btn.dataset.action;
    if (action === 'controls') document.querySelector('[data-view="controls"]')?.click();
    else if (action === 'settings') document.querySelector('[data-view="settings"]')?.click();
    else if (action === 'more') document.getElementById('cxMoreBtn')?.click();
    else if (action === 'play') {
      const g = games.find(x => x.id === selectedGameId);
      if (!g) show('Select a game first.');
      else {
        void (async () => {
          try {
            if (typeof window.nexora.markPlayed === 'function') {
              const updated = await window.nexora.markPlayed(g.id, 0);
              if (updated) { const i = games.findIndex(x => x.id === g.id); if (i >= 0) games[i] = updated; renderGames(); renderPinned(); selectGame(updated); }
            }
          } catch { /* ignore */ }
          show(`“${g.metadata?.title || g.name}” is ready. Open NEXORA on your phone to play.`);
        })();
      }
    }
  }));

  document.getElementById('pin')?.addEventListener('input', (e) => {
    const el = e.target;
    el.value = el.value.replace(/\D/g, '').slice(0, 6);
  });

  pinForm?.addEventListener('submit', e => {
    e.preventDefault();
    const pinEl = document.getElementById('pin');
    const pin = (pinEl?.value || '').trim();
    if (!/^\d{6}$/.test(pin)) {
      if (message) message.textContent = 'Enter the 6-digit receiver PIN.';
      return;
    }
    // Host generates the PIN under Devices → Show PIN; receivers type that code.
    if (message) message.textContent = 'Use Devices → Show PIN to generate a host code, then enter it on the receiver.';
    show('Open Devices and tap Show PIN, then type that code on the receiver.');
  });




  // ---- Live system usage (real numbers from the PC) ---------------------------------------------
  let statsTick = 0;
  const setRing = (id, percent) => { const el = document.getElementById(id); if (el) el.style.setProperty('--p', String(Math.max(0, Math.min(100, percent)))); };
  function renderStats(stats) {
    const cpu = document.getElementById('usageCpu'); if (cpu) cpu.textContent = `${stats.cpuPercent}%`;
    const cpuSub = document.getElementById('usageCpuSub'); if (cpuSub) cpuSub.textContent = stats.cpuGhz ? `${stats.cpuGhz} GHz` : '—';
    const ram = document.getElementById('usageRam'); if (ram) ram.textContent = `${stats.ramPercent}%`;
    const ramSub = document.getElementById('usageRamSub'); if (ramSub) ramSub.textContent = `${stats.ramUsedGb} / ${stats.ramTotalGb} GB`;
    setRing('ringCpu', stats.cpuPercent); setRing('ringRam', stats.ramPercent);
    const cxCpu = document.getElementById('cxCpu'); if (cxCpu) cxCpu.textContent = `${stats.cpuPercent}%`;
    const cxRam = document.getElementById('cxRam'); if (cxRam) cxRam.textContent = `${stats.ramPercent}%`;
  }
  async function pollStats() {
    if (document.hidden || typeof window.nexora?.getSystemStats !== 'function') return;
    if (document.body.classList.contains('power-saving') && (statsTick++ % 3) !== 0) return; // slower in Power Saving
    try { renderStats(await window.nexora.getSystemStats()); } catch { /* keep the last numbers */ }
  }
  void pollStats();
  setInterval(pollStats, 2000);

  // Esc leaves Console Mode (unless a dialog is open on top of it).
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || !consoleMode) return;
    if ([orbitModal, metadataModal, confirmModal].some(m => m && !m.hidden)) return;
    exitConsoleMode();
  });

  setHeroBackground(DEFAULT_HERO);
  updateGameInfo(null);

  (async () => {
    try {
      let cfg = await window.nexora.getConfig();
      if (cfg?.appearance?.rotateEmptyBackground !== false) {
        const nextBackground = nextEmptyLibraryBackground(cfg?.appearance?.emptyLibraryBackground || 'space-horizon');
        try {
          cfg = await window.nexora.setConfig({ appearance: { ...cfg?.appearance, emptyLibraryBackground: nextBackground } });
        } catch { /* keep the saved scene if config persistence is unavailable */ }
      }
      applyPreferences(cfg);
      applySidebarPreference();
      if (cfg?.mode === 'power_saving') document.body.classList.add('power-saving');
      applyQuality(cfg);
      if (cfg?.launchMode === 'console') enterConsoleMode();
    } catch { /* browser preview without preload */ }
    try { games = await window.nexora.listGames(); renderGames(); }
    catch { renderGames(); }
  })();
})();

