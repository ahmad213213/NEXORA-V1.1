import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createDefaultKeyMap,
  listBuiltinKeyMaps,
  mapGamepadEventToKeys,
  mapKeyEventToGamepad,
  normalizeControlName,
  validateKeyMapProfile
} from '../dist/index.js';

test('builtin profiles validate', () => {
  for (const p of listBuiltinKeyMaps()) {
    assert.equal(validateKeyMapProfile(p), true);
  }
});

test('aliases normalize to Xbox-style names', () => {
  assert.equal(normalizeControlName('Cross'), 'A');
  assert.equal(normalizeControlName('Circle'), 'B');
  assert.equal(normalizeControlName('LB'), 'L1');
  assert.equal(normalizeControlName('DPadUp'), 'DpadUp');
});

test('gamepad button maps to keyboard', () => {
  const profile = createDefaultKeyMap('universal');
  const out = mapGamepadEventToKeys(
    { kind: 'gamepad-button', action: 'down', code: 'A', sequence: 1, timestamp: 1 },
    profile
  );
  assert.equal(out.length, 1);
  assert.equal(out[0].kind, 'key');
  assert.equal(out[0].code, 'Space');
  assert.equal(out[0].action, 'down');
});

test('DualSense Cross maps like A', () => {
  const profile = createDefaultKeyMap('universal');
  const out = mapGamepadEventToKeys(
    { kind: 'gamepad-button', action: 'down', code: 'Cross', sequence: 2, timestamp: 2 },
    profile
  );
  assert.equal(out[0]?.code, 'Space');
});

test('mode off returns no mapped keys from helper when profile null', () => {
  const out = mapGamepadEventToKeys(
    { kind: 'gamepad-button', action: 'down', code: 'A', sequence: 3, timestamp: 3 },
    null
  );
  assert.equal(out.length, 0);
});

test('keyboard Space becomes gamepad A for controller mode', () => {
  const profile = createDefaultKeyMap('sports');
  const out = mapKeyEventToGamepad(
    { kind: 'key', action: 'down', code: 'Space', sequence: 10, timestamp: 10 },
    profile
  );
  assert.equal(out.length, 1);
  assert.equal(out[0].kind, 'gamepad-button');
  assert.equal(out[0].code, 'A');
  assert.equal(out[0].action, 'down');
});

test('keyboard WASD becomes left stick axes', () => {
  const profile = createDefaultKeyMap('sports');
  const out = mapKeyEventToGamepad(
    { kind: 'key', action: 'down', code: 'KeyW', sequence: 11, timestamp: 11 },
    profile
  );
  assert.ok(out.some(e => e.kind === 'gamepad-axis' && e.code === 'LeftStickY'));
});
