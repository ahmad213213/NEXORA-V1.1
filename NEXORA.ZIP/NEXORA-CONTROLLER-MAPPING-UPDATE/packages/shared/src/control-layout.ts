export type ControlType = 'button' | 'dpad' | 'stick' | 'trigger' | 'touchpad';
export type ControlAction = string;
export interface ControlLayoutItem {
  id: string; type: ControlType; action: ControlAction; label: string;
  x: number; y: number; width: number; height: number; opacity: number; z: number;
}
export interface ControlLayout {
  id: string; name: string; genre: 'custom' | 'action' | 'racing' | 'shooter' | 'sports' | 'rpg';
  version: 1; controls: ControlLayoutItem[];
}
const ID=/^[A-Za-z0-9_-]{1,32}$/;
const ACTION=/^[A-Za-z0-9_.:-]{1,48}$/;
export function validateControlLayout(v: unknown): v is ControlLayout {
  if (!v || typeof v !== 'object') return false;
  const x=v as any;
  if(!ID.test(String(x.id)) || typeof x.name!=='string' || x.name.length<1 || x.name.length>48) return false;
  if(!['custom','action','racing','shooter','sports','rpg'].includes(x.genre) || x.version!==1 || !Array.isArray(x.controls) || x.controls.length>24) return false;
  const ids=new Set<string>();
  for(const c of x.controls){
    if(!c || typeof c!=='object' || !ID.test(String(c.id)) || ids.has(c.id) || !['button','dpad','stick','trigger','touchpad'].includes(c.type) || !ACTION.test(String(c.action)) || typeof c.label!=='string' || c.label.length>12) return false;
    ids.add(c.id);
    for(const n of ['x','y','width','height','opacity']) if(typeof c[n]!=='number' || !Number.isFinite(c[n])) return false;
    if(c.x<0||c.x>1||c.y<0||c.y>1||c.width<=0||c.width>1||c.height<=0||c.height>1||c.x+c.width>1||c.y+c.height>1||c.opacity<0||c.opacity>1||!Number.isInteger(c.z)||c.z<0||c.z>99) return false;
  }
  return true;
}
export function normalizeControlLayout(layout: ControlLayout): ControlLayout {
  if(!validateControlLayout(layout)) throw new Error('Invalid control layout');
  return {...layout, name: layout.name.trim(), controls: layout.controls.map(c=>({...c, label:c.label.trim(), opacity:Math.round(c.opacity*100)/100}))};
}
export function createDefaultLayout(genre: ControlLayout['genre']='custom'): ControlLayout {
  const controls: ControlLayoutItem[]=[
    {id:'dpad',type:'dpad',action:'move',label:'D-PAD',x:.06,y:.62,width:.18,height:.30,opacity:.78,z:1},
    {id:'a',type:'button',action:'A',label:'A',x:.82,y:.66,width:.07,height:.10,opacity:.82,z:1},
    {id:'b',type:'button',action:'B',label:'B',x:.73,y:.76,width:.07,height:.10,opacity:.82,z:1},
    {id:'x',type:'button',action:'X',label:'X',x:.73,y:.56,width:.07,height:.10,opacity:.82,z:1},
    {id:'y',type:'button',action:'Y',label:'Y',x:.82,y:.46,width:.07,height:.10,opacity:.82,z:1},
    {id:'l1',type:'trigger',action:'L1',label:'L1',x:.06,y:.06,width:.16,height:.09,opacity:.70,z:1},
    {id:'r1',type:'trigger',action:'R1',label:'R1',x:.78,y:.06,width:.16,height:.09,opacity:.70,z:1}
  ];
  return {id:`layout_${genre}`,name:`${genre[0].toUpperCase()+genre.slice(1)} Default`,genre,version:1,controls};
}
