# Changelog — Phase 1 (with UI restoration correction)

## Current correction — original UI restored

The previous Phase 1 package had activated an alternate renderer layout and additional styling layer. That was not the user's preferred UI. The active `apps/host/src/ui/` tree has now been restored byte-for-byte from the exact uploaded `NEXORA V1.ZIP` renderer tree. The previous Phase 1 renderer is retained only under `recovery/phase1-ui-before-restore/`.

The older entries below document what was attempted in the superseded package; those styles and UI changes are **not active** in the current renderer.


## Added

- Frosted-glass integration stylesheet in the live Electron renderer.
- Four local no-game backgrounds and Settings controls for selection and launch-to-launch rotation.
- Config schema v4 fields for the empty-library background and rotation preference with validation and safe normalization.
- Separate Controls and Key Mapping navigation entries.
- Selectable PlayStation-style / Xbox-style controller illustrations with transparent backgrounds and explicit visual-only semantics.
- Focused Phase 1 tests and updated build/acceptance notes.

## Preserved

- Original source archive and Phase 1 UI-restored source archive as byte-identical immutable baselines.
- Existing live renderer DOM, click handlers, window buttons and protected settings IPC.
- Separate approved UI prototype/reference files.

## Known limitations

- No lockfile or dependency-backed build/typecheck due to unavailable npm registry.
- Full suite is blocked at imports of missing compiled `dist` modules.
- Windows Electron runtime, real restart persistence, installer and host-to-Android acceptance are not verified.
