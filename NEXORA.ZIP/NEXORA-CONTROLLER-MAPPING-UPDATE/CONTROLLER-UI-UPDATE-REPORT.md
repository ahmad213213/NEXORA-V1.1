# NEXORA — Controller artwork and button alignment update

## Scope
This patch is restricted to the Controls page controller stage and the two explicit image-host entries needed to display the sourced PNGs. The original NEXORA `main` page layout, other page content, sidebar, typography, glass styling, and application behavior were not redesigned. The exact upload `NEXORA V1.ZIP` is kept as a separate, untouched recovery baseline at `baseline/NEXORA-V1-UPLOADED-ARCHIVE-UNMODIFIED.zip`.

## Changes
- Replaced the generic controller SVG in the Controls stage with real web-sourced PlayStation DualSense and Xbox controller PNGs. The renderer prefers local cached images, then tries the direct remote image URL, then falls back to the pre-existing local SVG if both fail.
- Added a single square artwork canvas with transparent percentage-based hit zones so the clickable controller buttons share the image coordinate space. Xbox and PlayStation use separate mappings. The Xbox Y-button hotspot was corrected to the right/up face-button position.
- Removed the dashed SVG connector and line-update logic between the controller and mapping target. Removed the explanatory line text. Replaced the dashed mapping-target border with a subtle solid border. Hotspots are invisible at rest and only glow on hover/focus/selection/press.
- Added a PowerShell script to download both PNGs locally, verify the PNG signature before replacing assets, and write SHA-256 attribution records.
- Updated tests to lock the CSP to the exact two external image hosts and added controller-artwork checks.

## Files changed
- `apps/host/src/ui/index.html`
- `apps/host/src/ui/refinement.css`
- `apps/host/src/ui/app.js`
- `apps/host/test/audit-fixes.test.mjs`
- `apps/host/test/orbit-integration.test.mjs`
- `apps/host/test/controller-artwork.test.mjs` (new)
- `scripts/download-controller-artwork.ps1` (new)
- `DOWNLOAD-CONTROLLER-ARTWORK.bat` (new one-click Windows launcher)
- `CONTROLLER-ARTWORK-SOURCES.md` (new/updated)

## Validation run
- `node --check apps/host/src/ui/app.js`: passed.
- `node --check apps/host/test/controller-artwork.test.mjs`: passed.
- `node --test apps/host/test/controller-artwork.test.mjs`: 3 passed, 0 failed.
- Targeted CSP test in `audit-fixes.test.mjs`: 1 passed, 0 failed.
- Targeted CSP test in `orbit-integration.test.mjs`: 1 passed, 0 failed.
- HTML structure inspection: Controls artwork canvas found, 16 button hit zones found, SVG mapping connector and explanatory line text absent.
- CSS parser inspection: passed with no parse errors.
- Package ZIP integrity and SHA-256 checksum: verified after archive generation.

## Important limitation
The container could not resolve the remote image-host domains, so this archive does **not** contain the downloaded PNG binary files. With network access, the app tries the direct remote images when Controls opens. For offline/local images, run `powershell -ExecutionPolicy Bypass -File .\scripts\download-controller-artwork.ps1` from a Windows machine with internet access. CityPNG states its PlayStation image is for personal use only; the Xbox host page does not provide a clear standalone image license, so redistribution permission is not confirmed.

## Runtime status
The JavaScript/CSS/source tests above passed. A full Electron launch and pixel-by-pixel target calibration on Windows were not possible here; exact final physical target placement should be checked in the running app on the target display/controller image rendering.
