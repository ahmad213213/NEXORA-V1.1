# Changelog — Phase 0 Recheck

- Preserved the exact user-uploaded `NEXORA V1.ZIP` byte-for-byte under `baseline/`.
- Preserved the untouched cumulative `NEXORA-PHASE1-UI-RESTORED.zip` used as the source baseline.
- Corrected the root `test` script so it builds both workspace packages before executing tests that import generated `dist` modules.
- Strengthened Phase 0 preflight checks to validate the new audit docs/baseline files and test-script build prerequisite.
- Added source inventory, baseline identity, build/test instructions, and a fresh verification report.
- Updated Phase 0 status/check documentation to reflect lockfile and clean-build blockers rather than declaring unconditional completion.
- Did not change the application UI, host behavior, game library, Android code, capture, signaling or stream implementation.
