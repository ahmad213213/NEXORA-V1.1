NEXORA — ORIGINAL UPLOADED UI RESTORATION

START HERE
1. Extract the complete ZIP to a normal folder.
2. Open UI-RESTORATION-FROM-ORIGINAL-UPLOAD.md to see how the uploaded UI was restored.
3. Double-click PREVIEW.bat to preview the active original renderer in a browser. This is not a full Electron runtime and does not verify IPC/native behavior.
4. Read PHASE1-DELIVERY.md and docs/PHASE1-CHECKS.md for current status and verification limits.

ACTIVE UI
- Electron source: apps/host/src/
- Active original UI: apps/host/src/ui/
- The active UI folder matches Already_Unpacked_App/dist/ui/ from the user's exact uploaded NEXORA V1.ZIP byte-for-byte. See recovery/original-upload-ui-manifest.json.
- The renderer layout/styles/JS from the previous Phase 1 package are preserved only in recovery/phase1-ui-before-restore/ and are NOT active.
- The frosted-glass prototype remains separate in design-reference/current-frosted-glass-ui-prototype/. Do not copy it over the active UI.

VERIFICATION
- Restored-renderer checks: 12/12 passed.
- Final static recheck: 16/16 passed.
- Game-library static verifier: 13/13 passed.
- Full workspace build/typecheck/full test suite and Windows Electron runtime are still unverified due unavailable dependency installation/generated build output.
- See UI-RESTORATION-FROM-ORIGINAL-UPLOAD.md and docs/PHASE1-VERIFICATION.md.

BATCH FILES
PREVIEW.bat is the only root .bat. No installer is included or claimed built.

PROTECTED ORIGINAL
The exact uploaded archive is preserved unchanged at baseline/NEXORA-V1-UPLOADED-ARCHIVE-UNMODIFIED.zip. No GitHub files were changed by this restoration.
