# NEXORA Settings System

This package is a browser-run UI prototype. The settings system in this package is implemented and testable in the prototype itself; it is not the full Electron application source.

## Working now

- Six settings categories: Appearance, General, Network, Streaming, Updates, and Privacy & security.
- Versioned, validated settings state with defaults and safe fallback if browser storage is blocked.
- Autosave to browser `localStorage` when the browser permits it; if storage is blocked, the status changes to session-only and the UI shows a warning.
- Shared settings across Desktop and Console Mode. Changes made in either view use the same store.
- Live theme changes (`Midnight glass`, `Obsidian`, `Earth horizon`), six accent colors, reduced-motion handling, profile name, and startup-mode preference.
- Saved defaults for connection, pairing, video/audio, encoder, bitrate, adaptive quality, update channel, and privacy preferences.
- Quality tile presets update the same resolution/frame-rate preferences shown under Streaming settings.
- Export settings to a versioned JSON backup, validated JSON import, and reset-all-to-defaults with confirmation.
- Accessible switch semantics, keyboard-operable accent swatches, labelled controls, input validation, and visible storage status.

## Deliberately not claimed as active

The uploaded ZIP did not contain an Electron main process, preload script, package manifest, or application IPC layer. As a result, the following preferences are saved but do not perform OS or service actions from this package: Windows startup registration, tray/minimize behavior, device pairing, relay routing, encoder selection, live streaming, automatic update checks, and enforcing session security. The Update action does not send a network request. These are clearly indicated in the settings UI rather than being represented as already connected.

## Optional Electron persistence bridge

The folder `electron-settings-bridge/` contains a starter main-process store and a preload example. These are supplied for integration but are **not connected to the real NEXORA executable in this archive** because the provided UI ZIP contains no Electron main process or existing preload file.

To connect it in the full source tree:

1. After `app.whenReady()`, call `registerNexoraSettingsIpc({ app, ipcMain })` from `electron-settings-bridge/settings-main.cjs` in the main process. It stores validated settings atomically at `app.getPath('userData')/settings-v1.json` and quarantines malformed/unsupported files rather than blindly overwriting them.
2. Merge the `settings` API from `settings-preload.example.cjs` into the existing `contextBridge.exposeInMainWorld('nexora', ...)` call. Do not expose a second `nexora` global or replace existing APIs by copying the example wholesale.
3. Keep `contextIsolation: true` and `nodeIntegration: false` in `BrowserWindow.webPreferences`. The renderer receives only `getAll()` and `setAll()`; it never receives filesystem or generic IPC access.
4. Verify the actual packaged renderer URL is inside `app.getAppPath()`. If your renderer is loaded from a different trusted origin or path, supply a narrow `isTrustedSender(event)` callback when registering the handlers.

The UI settings store detects `window.nexora.settings.getAll/setAll` automatically. If that bridge is absent, the preview uses browser storage. Both the renderer and main process validate and whitelist setting values. OS startup registration, tray behavior, device pairing, live encoding, stream transport and updates remain separate services; these preferences do not activate those systems on their own.

## Storage format

The portable backup format is JSON with `app: "NEXORA"`, `schemaVersion: 1`, `exportedAt`, and a `settings` object. Imports larger than 1 MB, malformed JSON, other apps, and unsupported versions are rejected. Unknown values are discarded and all known keys are sanitized against the settings schema.

## Test and run

Open `index.html` in a modern browser, or use the root-level `PREVIEW.bat` on Windows. The settings code itself has no package dependency. From a Node.js installation, run `node --test tests/*.test.cjs` to execute the store and Electron bridge regression tests. The browser UI was also exercised with a Chromium test harness; because this environment blocked direct local-page navigation, that harness loaded the source directly and mocked `localStorage`. Electron persistence was tested through a mock IPC surface and real temporary files, not by launching the full NEXORA app.

No internet connection is required for the settings engine. The external web-font request is optional; local system fonts remain as fallbacks.
