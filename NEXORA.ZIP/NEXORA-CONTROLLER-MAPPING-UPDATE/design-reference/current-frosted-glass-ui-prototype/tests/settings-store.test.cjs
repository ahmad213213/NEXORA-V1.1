'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { createStore } = require('./settings-store-harness.cjs');

test('initializes versioned defaults and saves them', async () => {
  const { store, data } = createStore();
  await store.ready;
  assert.equal(store.get('theme'), 'midnight');
  assert.equal(store.get('bitrateMbps'), 25);
  const envelope = JSON.parse(data.get('nexora.settings.v1'));
  assert.equal(envelope.schemaVersion, 1);
  assert.equal(envelope.settings.profileName, 'NEXORA User');
});

test('validates enums, booleans, text and numeric ranges', async () => {
  const { store } = createStore();
  await store.ready;
  await store.set('theme', 'not-a-theme');
  await store.set('relayFallback', 'true');
  await store.set('profileName', '  A\u0000 profile with a valid name  ');
  await store.set('bitrateMbps', 999);
  assert.equal(store.get('theme'), 'midnight');
  assert.equal(store.get('relayFallback'), true);
  assert.equal(store.get('profileName'), 'A profile with a valid name');
  assert.equal(store.get('bitrateMbps'), 100);
});

test('serializes concurrent writes without losing either change', async () => {
  const { store, data } = createStore();
  await store.ready;
  await Promise.all([store.set('theme', 'earth'), store.set('accent', 'rose')]);
  const saved = JSON.parse(data.get('nexora.settings.v1')).settings;
  assert.equal(saved.theme, 'earth');
  assert.equal(saved.accent, 'rose');
});

test('replace sanitizes untrusted imported settings and export is versioned', async () => {
  const { store } = createStore();
  await store.ready;
  await store.replace({ theme: 'obsidian', profileName: ' imported ', bitrateMbps: -20, extraKey: 'ignore' });
  const exportPayload = store.exportPayload();
  assert.equal(exportPayload.app, 'NEXORA');
  assert.equal(exportPayload.schemaVersion, 1);
  assert.equal(exportPayload.settings.theme, 'obsidian');
  assert.equal(exportPayload.settings.profileName, 'imported');
  assert.equal(exportPayload.settings.bitrateMbps, 5);
  assert.equal(Object.hasOwn(exportPayload.settings, 'extraKey'), false);
  assert.equal(typeof exportPayload.exportedAt, 'string');
});

test('uses Electron bridge and does not trust the returned object without sanitizing', async () => {
  const calls = [];
  const bridge = {
    async getAll() { return { theme: 'bogus', accent: 'amber', profileName: 'Bridge User' }; },
    async setAll(settings) { calls.push(settings); return { ok: true }; },
  };
  const { store } = createStore({ bridge });
  await store.ready;
  assert.equal(store.backend, 'electron');
  assert.equal(store.get('theme'), 'midnight');
  assert.equal(store.get('accent'), 'amber');
  await store.set('profileName', 'Persisted User');
  assert.equal(calls.length, 1);
  assert.equal(calls[0].profileName, 'Persisted User');
});
