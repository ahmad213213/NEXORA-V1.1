'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'settings-store.js'), 'utf8');

function createStore({ seed, bridge } = {}) {
  const data = new Map();
  if (seed !== undefined) data.set('nexora.settings.v1', JSON.stringify(seed));
  const localStorage = {
    getItem: (key) => data.has(key) ? data.get(key) : null,
    setItem: (key, value) => data.set(key, String(value)),
    removeItem: (key) => data.delete(key),
    clear: () => data.clear(),
  };
  const window = { localStorage };
  if (bridge) window.nexora = { settings: bridge };
  vm.runInNewContext(source, { window, console, JSON, Promise, Object, Array, String, Number, Math, Date, Set, Error });
  return { store: window.NEXORASettingsStore, data, window };
}

module.exports = { createStore };
