'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { registerNexoraSettingsIpc, sanitiseSettings, DEFAULTS: MAIN_DEFAULTS } = require('../electron-settings-bridge/settings-main.cjs');

test('main process validates settings and atomically persists a versioned file', async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'nexora-settings-test-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const handlers = new Map();
  const ipcMain = { handle: (channel, handler) => handlers.set(channel, handler), removeHandler: (channel) => handlers.delete(channel) };
  const app = { getPath: () => root, getAppPath: () => root };
  const bridge = registerNexoraSettingsIpc({ app, ipcMain, isTrustedSender: () => true });
  t.after(() => bridge.dispose());
  const event = { senderFrame: { url: `file://${path.join(root, 'index.html')}` } };
  const getAll = handlers.get('nexora:settings:getAll');
  const setAll = handlers.get('nexora:settings:setAll');

  const initial = await getAll(event);
  assert.equal(initial.theme, 'midnight');
  assert.equal(initial.profileName, 'NEXORA User');

  await Promise.all([
    setAll(event, { ...initial, theme: 'earth', bitrateMbps: 40 }),
    setAll(event, { ...initial, theme: 'obsidian', profileName: 'Saved Profile' }),
  ]);
  const file = JSON.parse(await fs.readFile(path.join(root, 'settings-v1.json'), 'utf8'));
  assert.equal(file.schemaVersion, 1);
  assert.equal(file.settings.theme, 'obsidian');
  assert.equal(file.settings.profileName, 'Saved Profile');
  assert.equal((await getAll(event)).theme, 'obsidian');
});

test('main-process validator discards unknown fields and bounds imported values', () => {
  const result = sanitiseSettings({ theme: 'bad', accent: 'rose', bitrateMbps: 999, profileName: '  User\u0000 Name ', extra: true });
  assert.equal(result.theme, 'midnight');
  assert.equal(result.accent, 'rose');
  assert.equal(result.bitrateMbps, 100);
  assert.equal(result.profileName, 'User Name');
  assert.equal(Object.hasOwn(result, 'extra'), false);
});

test('IPC bridge rejects calls from a renderer that fails the trust check', async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'nexora-settings-reject-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const handlers = new Map();
  const ipcMain = { handle: (channel, handler) => handlers.set(channel, handler), removeHandler: (channel) => handlers.delete(channel) };
  const bridge = registerNexoraSettingsIpc({ app: { getPath: () => root, getAppPath: () => root }, ipcMain, isTrustedSender: () => false });
  t.after(() => bridge.dispose());
  await assert.rejects(handlers.get('nexora:settings:getAll')({ senderFrame: { url: 'https://untrusted.example/' } }), /Untrusted renderer/);
});


test('renderer store and Electron main-process whitelist stay in sync', async () => {
  const { store } = require('./settings-store-harness.cjs').createStore();
  await store.ready;
  assert.deepEqual(Object.keys(store.defaults).sort(), Object.keys(MAIN_DEFAULTS).sort());
});

test('default sender policy permits app-local UI files and rejects external web origins', async (t) => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'nexora-settings-origin-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const handlers = new Map();
  const ipcMain = { handle: (channel, handler) => handlers.set(channel, handler), removeHandler: (channel) => handlers.delete(channel) };
  const app = { getPath: () => root, getAppPath: () => root };
  const bridge = registerNexoraSettingsIpc({ app, ipcMain });
  t.after(() => bridge.dispose());
  const getAll = handlers.get('nexora:settings:getAll');
  const allowed = { senderFrame: { url: `file://${path.join(root, 'index.html')}` } };
  const denied = { senderFrame: { url: 'https://untrusted.example/' } };
  assert.equal((await getAll(allowed)).theme, 'midnight');
  await assert.rejects(getAll(denied), /Untrusted renderer/);
});
