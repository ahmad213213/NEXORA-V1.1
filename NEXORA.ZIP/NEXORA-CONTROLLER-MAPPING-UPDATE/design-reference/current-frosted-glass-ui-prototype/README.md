# NEXORA UI Prototype — Refined Desktop + Console

A browser-runnable, UI-only mockup. The desktop home and sidebar follow the supplied NEXORA concept: frosted navigation, cinematic featured banner, clean cover-art tiles, a compact CPU/RAM glance, separate pages for Remote Play, AI Patcher, Streaming, Networking, Controls, Performance and Settings, a connected-host card, quick actions, and gamepad-layout promotion. The console retains its full-screen game-first identity, adds a PlayStation-style controller icon for the desktop switch, polished mode-transition animation, selectable games, and navigable console panels.

## Run

- **Windows (full Phase 0 package):** double-click `PREVIEW.bat` in the project root.
- **Any modern browser:** open `index.html`.
- No installation, Node.js, internet access, or credentials required.

## Click through

- **Desktop sidebar:** Home, Library, Remote Play, AI Patcher, Streaming, Networking, Controls, Performance, and Settings.
- **Desktop quick actions:** Add Game, Gamepad Settings, Layout Editor, Network Settings.
- **Desktop Settings:** Appearance, General, Network, Streaming, Updates, and Privacy & security tabs, plus shortcuts to the other PC-focused screens.
- **Controller icon (desktop top-right):** switches to console mode; the icon has no visible text label.
- **Console game covers:** select a game; **View** opens its detail panel.
- **Console tiles:** Settings opens category tabs and preview controls; Updates opens an update panel; Quality arrows and the quality tile open selectable presets; Stream opens receiver/session details.
- **Return:** use the Desktop button in console mode or press Escape. Escape closes an open console panel first.

Settings now use a validated, versioned preference store with autosave to browser storage; theme, accent, reduced motion, startup mode, profile name, and quality defaults apply across Desktop and Console Mode. Settings can be exported/imported as JSON or reset to defaults. OS startup/tray behavior, pairing, real streaming, hardware access, and updating are still separate native integrations and are explicitly identified as not connected in this UI-only package.

## Files

- `index.html`, `styles.css`, `refinement.css`, `settings-system.css`, `settings-store.js`, `app.js` — complete browser preview source.
- `SETTINGS-SYSTEM.md` — feature behavior, backup format, storage adapter, and integration boundary.
- `electron-settings-bridge/` — main-process atomic settings storage and a preload integration example for the full Electron source.
- `tests/` — Node.js regression tests for the settings store and Electron bridge.
- `SETTINGS-VERIFICATION.txt` — checks run and their limitations.
- `PREVIEW.bat` (project root) — opens the UI preview on Windows.
- `assets/` — local artwork used by the preview.


### Console mode switch icon update

The top-right Desktop-to-Console button now uses a dedicated, transparent SVG controller illustration based on the supplied DualSense reference (light shell, dark center panel, trackpad, D-pad, face buttons, twin sticks, and restrained blue edge accents). The button remains icon-only and the existing mode-switch behavior is unchanged.


### Settings system build

The settings system is implemented as a reusable schema + store, including validation, serialized saves, import/export, reset-to-defaults, synchronized Desktop/Console preferences, and an optional main-process persistence bridge. See `SETTINGS-SYSTEM.md` and `SETTINGS-VERIFICATION.txt`. The bridge files are starter integration code, not connected to a full Electron app in this archive because the uploaded UI ZIP did not include its real main process, preload or package manifest.
