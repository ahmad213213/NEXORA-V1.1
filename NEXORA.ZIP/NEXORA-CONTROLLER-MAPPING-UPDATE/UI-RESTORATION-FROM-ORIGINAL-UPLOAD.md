# NEXORA UI Restoration — Exact Original Upload

## Correction

The previous Phase 1 package activated an alternate renderer layout and an added stylesheet layer. That did not preserve the user's preferred UI. This restoration reverses that renderer change.

The active Electron renderer folder, `apps/host/src/ui/`, now contains the exact files from the user's uploaded `NEXORA V1.ZIP`, internal path `Already_Unpacked_App/dist/ui/`. This includes the original `index.html`, `styles.css`, `refinement.css`, `settings-system.css`, `empty-library-backgrounds.css`, original renderer `app.js`, scripts, and original assets.

## Integrity

- Original archive preserved unchanged at `baseline/NEXORA-V1-UPLOADED-ARCHIVE-UNMODIFIED.zip`.
- Its SHA-256 is `217cff3f1edff82035fb8556298e23f5e89dba70e10c641ae41a5d4284acca7f`.
- The GitHub blob SHA-1 calculated using Git's blob-header format is `d94f734188f14d1277c076ebe8daaa37770b0df5`, matching the blob in the user's repository.
- `recovery/original-upload-ui-manifest.json` lists SHA-256 and sizes for every active renderer file. A focused test verifies that all active UI files match those hashes.
- The Phase 1 renderer that was active before this restoration is saved unmodified at `recovery/phase1-ui-before-restore/`.
- The prototype and design references remain separate under `design-reference/`; they do not replace the active renderer.

## Verification

The restored UI tests check the exact uploaded UI tree, its asset links, Desktop/Console DOM, Controls/mapping section, background rotation assets, and Settings resources. The UI files pass file-by-file checksum verification and JavaScript syntax checks.

Focused tests pass. A full dependency-backed build and real Windows Electron runtime/restart test have not been completed in this environment.

## Important limitation

This is a UI restoration, not a claim that Phase 1 has passed final acceptance. The current preload bridge does not expose every optional method referenced by the original renderer, and the uploaded settings UI can fall back to renderer storage where its optional settings bridge is unavailable. Any compatibility work must be backend-only and must not restyle or replace this UI again.
