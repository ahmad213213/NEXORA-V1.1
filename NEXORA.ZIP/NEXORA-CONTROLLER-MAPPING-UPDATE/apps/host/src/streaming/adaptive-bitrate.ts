export interface AdaptationSample {
  packetLossPct: number;
  rttMs: number;
  availableKbps?: number;
  jitterMs?: number;
}

export interface AdaptiveBitrateOptions {
  minKbps: number;
  maxKbps: number;
  initialKbps: number;
  stepKbps?: number;
  cooldownMs?: number;
  /** Faster drop reaction for weak links (ms). Default 1200. */
  dropCooldownMs?: number;
  now?: () => number;
}

/**
 * Aggressive-down / cautious-up ABR tuned for low-Mbps links.
 * Drops quickly on loss/RTT, climbs slowly when healthy.
 */
export class AdaptiveBitrateController {
  private readonly min: number;
  private readonly max: number;
  private readonly step: number;
  private readonly upCooldown: number;
  private readonly dropCooldown: number;
  private readonly now: () => number;
  private lastChange = -Infinity;
  private currentValue: number;
  private consecutiveBad = 0;

  constructor(options: AdaptiveBitrateOptions) {
    // Floor at 500 kbps so 1–3 Mbps links can still stream 480p/30
    this.min = Math.max(350, Math.round(options.minKbps));
    this.max = Math.max(this.min, Math.round(options.maxKbps));
    this.step = Math.max(200, Math.round(options.stepKbps ?? 400));
    this.upCooldown = Math.max(1500, Math.round(options.cooldownMs ?? 4000));
    this.dropCooldown = Math.max(600, Math.round(options.dropCooldownMs ?? 1200));
    this.now = options.now ?? Date.now;
    this.currentValue = Math.max(this.min, Math.min(this.max, Math.round(options.initialKbps)));
  }

  get bitrateKbps(): number { return this.currentValue; }

  update(sample: AdaptationSample): number {
    const loss = Number.isFinite(sample.packetLossPct) ? sample.packetLossPct : 0;
    const rtt = Number.isFinite(sample.rttMs) ? sample.rttMs : 0;
    const jitter = Number.isFinite(sample.jitterMs) ? sample.jitterMs! : 0;
    const available = Number.isFinite(sample.availableKbps) ? sample.availableKbps! : Infinity;

    // Strong drop conditions for weak / congested links
    const hardDrop = loss >= 8 || rtt >= 350 || jitter >= 80 || available < this.currentValue * 0.6;
    const softDrop = loss >= 3 || rtt >= 180 || available < this.currentValue * 0.85;
    const healthy = loss <= 0.5 && rtt > 0 && rtt <= 90 && jitter <= 30 && available >= this.currentValue * 1.35;

    if (hardDrop || softDrop) this.consecutiveBad++;
    else if (healthy) this.consecutiveBad = 0;

    const now = this.now();
    const since = now - this.lastChange;

    if (hardDrop && since >= this.dropCooldown) {
      // Big step down under severe congestion
      const next = Math.max(this.min, this.currentValue - this.step * 2);
      if (next !== this.currentValue) {
        this.currentValue = next;
        this.lastChange = now;
      }
      return this.currentValue;
    }

    if (softDrop && this.consecutiveBad >= 2 && since >= this.dropCooldown) {
      const next = Math.max(this.min, this.currentValue - this.step);
      if (next !== this.currentValue) {
        this.currentValue = next;
        this.lastChange = now;
      }
      return this.currentValue;
    }

    if (healthy && since >= this.upCooldown) {
      const next = Math.min(this.max, this.currentValue + this.step);
      if (next !== this.currentValue) {
        this.currentValue = next;
        this.lastChange = now;
      }
    }

    return this.currentValue;
  }

  reset(kbps: number): void {
    this.currentValue = Math.max(this.min, Math.min(this.max, Math.round(kbps)));
    this.lastChange = -Infinity;
    this.consecutiveBad = 0;
  }
}
