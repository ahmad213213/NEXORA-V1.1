import { CaptureEngine } from './capture-engine.js';
import type { MediaSink, StreamStats, StreamingConfig, VideoQuality } from './types.js';

export class StreamManager {
  private readonly capture: CaptureEngine;
  private activeGameId: string | null = null;
  private generation = 0;

  constructor(config: StreamingConfig, log: (event: string, fields?: object) => void = () => {}) {
    this.capture = new CaptureEngine(config, log);
  }

  async start(gameId: string, sink: MediaSink): Promise<StreamStats> {
    const generation = ++this.generation;
    this.capture.stop();
    this.activeGameId = gameId;
    await this.capture.start({
      video: packet => { if (generation === this.generation) sink.video(packet); },
      audio: packet => { if (generation === this.generation) sink.audio(packet); }
    });
    if (generation !== this.generation) { this.capture.stop(); throw new Error('Stream start superseded'); }
    return this.capture.stats();
  }

  stop(): void { this.generation++; this.activeGameId = null; this.capture.stop(); }
  setQuality(quality: Partial<VideoQuality>): void { this.capture.setQuality(quality); }
  setBitrate(kbps: number): void { this.capture.setBitrate(kbps); }
  setAudioDevice(device: string | null): void { this.capture.setAudioDevice(device); }
  get active(): boolean { return this.capture.active; }
  get gameId(): string | null { return this.activeGameId; }
  get quality(): VideoQuality { return this.capture.currentQuality; }
  get encoder() { return this.capture.currentEncoder; }
  stats(): StreamStats { return this.capture.stats(); }
}
