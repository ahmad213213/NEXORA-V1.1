import { spawn, type ChildProcess } from 'node:child_process';
import dgram from 'node:dgram';
import { buildAudioArgs, buildVideoArgs, clampQuality, hasFilter, pickEncoder } from './ffmpeg.js';
import type { MediaSink, StreamingConfig, StreamStats, VideoEncoder, VideoQuality } from './types.js';

interface Spawned { process: ChildProcess; kind: 'video' | 'audio'; }

/** Owns FFmpeg processes and localhost RTP sockets. No signaling/WebRTC logic belongs here. */
export class CaptureEngine {
  private running = false;
  private starting = false;
  private generation = 0;
  private encoder: VideoEncoder | null = null;
  private captureBackend: StreamingConfig['capture'];
  private quality: VideoQuality;
  private video?: Spawned;
  private audio?: Spawned;
  private videoSocket?: dgram.Socket;
  private audioSocket?: dgram.Socket;
  private sink?: MediaSink;
  private restarts = 0;
  private startedAt: number | null = null;
  private audioRestarts = 0;
  private videoFailures = 0;
  private stableTimer?: ReturnType<typeof setTimeout>;

  private readonly statsState = { videoPackets: 0, audioPackets: 0, videoBytes: 0, audioBytes: 0 };

  constructor(private config: StreamingConfig, private readonly log: (event: string, fields?: object) => void = () => {}, private readonly spawnFn: typeof spawn = spawn) {
    this.quality = { width: config.width, height: config.height, fps: config.fps, bitrateKbps: config.bitrateKbps };
    this.captureBackend = config.capture;
  }

  get active(): boolean { return this.running; }
  get currentQuality(): VideoQuality { return { ...this.quality }; }
  get currentEncoder(): VideoEncoder | null { return this.encoder; }

  async start(sink: MediaSink, overrides?: { videoInput?: string[]; audioInput?: string[] }): Promise<void> {
    if (this.running || this.starting) return;
    this.starting = true;
    const generation = ++this.generation;
    this.sink = sink;
    this.restarts = 0;
    this.audioRestarts = 0;
    this.statsState.videoPackets = 0;
    this.statsState.audioPackets = 0;
    this.statsState.videoBytes = 0;
    this.statsState.audioBytes = 0;
    this.videoFailures = 0;
    try {
      this.encoder = await pickEncoder(this.config.ffmpegPath, this.config.encoder, this.spawnFn);
      if (generation !== this.generation) return;
      if (!this.encoder) throw new Error('No usable H.264 encoder was found');
      if (this.captureBackend === 'ddagrab' && !(await hasFilter(this.config.ffmpegPath, 'ddagrab', this.spawnFn))) {
        this.captureBackend = 'gdigrab';
        this.log('capture_fallback', { from: 'ddagrab', to: 'gdigrab', reason: 'ffmpeg_filter_unavailable' });
      }
      if (generation !== this.generation) return;
      await this.bindSockets(generation);
      if (generation !== this.generation) { this.cleanup(generation); return; }
      this.running = true;
      this.startedAt = Date.now();
      this.spawnVideo(generation, overrides?.videoInput);
      this.spawnAudio(generation, overrides?.audioInput);
      this.log('stream_capture_started', { encoder: this.encoder, quality: this.quality, audio: Boolean(this.config.audioDevice || overrides?.audioInput) });
    } catch (error) {
      this.running = false;
      this.cleanup(generation);
      throw error;
    } finally {
      this.starting = false;
    }
  }

  private async bindSockets(generation: number): Promise<void> {
    this.videoSocket = await this.bindSocket(generation, packet => {
      if (!this.running || generation !== this.generation) return;
      this.statsState.videoPackets++; this.statsState.videoBytes += packet.byteLength; this.sink?.video(packet);
    });
    if (this.config.audioDevice) {
      this.audioSocket = await this.bindSocket(generation, packet => {
        if (!this.running || generation !== this.generation) return;
        this.statsState.audioPackets++; this.statsState.audioBytes += packet.byteLength; this.sink?.audio(packet);
      });
    }
  }

  private bindSocket(generation: number, onPacket: (packet: Buffer) => void): Promise<dgram.Socket> {
    return new Promise((resolve, reject) => {
      const socket = dgram.createSocket('udp4');
      let settled = false;
      const fail = (error: Error) => { if (settled) return; settled = true; try { socket.close(); } catch {} reject(error); };
      socket.once('error', fail);
      socket.on('message', packet => { if (generation === this.generation) onPacket(packet); });
      socket.bind(0, '127.0.0.1', () => { if (settled) return; settled = true; socket.removeListener('error', fail); resolve(socket); });
    });
  }

  private port(socket: dgram.Socket | undefined): number {
    const address = socket?.address();
    return address && typeof address === 'object' ? address.port : 0;
  }

  private spawnVideo(generation: number, inputArgs?: string[]): void {
    if (!this.encoder || !this.videoSocket) throw new Error('Video capture is not ready');
    const args = buildVideoArgs({ capture: this.captureBackend, encoder: this.encoder, quality: this.quality, port: this.port(this.videoSocket), inputArgs });
    let child: ChildProcess;
    try { child = this.spawnFn(this.config.ffmpegPath, args, { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true }); }
    catch (error) { this.handleVideoFailure(generation, undefined, error instanceof Error ? error.message : String(error)); return; }
    this.video = { process: child, kind: 'video' };
    this.watch(child, 'video', generation);
    clearTimeout(this.stableTimer);
    this.stableTimer = setTimeout(() => {
      if (generation === this.generation && this.video?.process === child && this.running) this.videoFailures = 0;
    }, 10000);
    (this.stableTimer as any).unref?.();
  }

  private spawnAudio(generation: number, inputArgs?: string[]): void {
    if (!this.audioSocket) return;
    const args = buildAudioArgs({ audioDevice: this.config.audioDevice, port: this.port(this.audioSocket), inputArgs });
    if (!args) return;
    let child: ChildProcess;
    try { child = this.spawnFn(this.config.ffmpegPath, args, { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true }); }
    catch (error) { this.handleAudioFailure(generation, undefined, error instanceof Error ? error.message : String(error)); return; }
    this.audio = { process: child, kind: 'audio' };
    this.watch(child, 'audio', generation);
  }

  private watch(child: ChildProcess, kind: 'video' | 'audio', generation: number): void {
    let stderr = '';
    let handled = false;
    child.stderr?.on('data', chunk => { stderr = (stderr + chunk.toString()).slice(-2000); });
    const gone = (code: number | null, reason?: string) => {
      if (handled) return; handled = true;
      const current = kind === 'video' ? this.video?.process : this.audio?.process;
      if (current !== child || generation !== this.generation) return;
      if (kind === 'video') this.video = undefined; else this.audio = undefined;
      if (!this.running) return;
      const detail = reason || stderr.trim().slice(-600) || `exit ${code}`;
      this.log('ffmpeg_exit', { kind, code, detail, encoder: this.encoder });
      if (kind === 'audio') this.handleAudioFailure(generation, child, detail);
      else this.handleVideoFailure(generation, child, detail);
    };
    child.once('error', error => gone(null, error.message));
    child.once('exit', code => gone(code));
  }

  private handleVideoFailure(generation: number, child: ChildProcess | undefined, detail: string): void {
    if (!this.running || generation !== this.generation) return;
    this.videoFailures++;
    if (this.encoder !== 'x264' && this.videoFailures <= 1) {
      const failed = this.encoder; this.encoder = 'x264';
      this.log('encoder_fallback', { from: failed, to: 'x264', detail });
      this.restarts++;
      try { this.spawnVideo(generation); } catch (error) { this.log('video_restart_failed', { error: String(error) }); this.stop(); }
      return;
    }
    if (this.videoFailures <= 3) {
      this.restarts++;
      try { this.spawnVideo(generation); } catch (error) { this.log('video_restart_failed', { error: String(error) }); this.stop(); }
      return;
    }
    this.log('video_capture_failed', { detail });
    this.stop();
  }

  private handleAudioFailure(generation: number, child: ChildProcess | undefined, detail: string): void {
    if (!this.running || generation !== this.generation) return;
    if (this.audioRestarts < 2) {
      this.audioRestarts++;
      this.restarts++;
      this.log('audio_capture_restart', { attempt: this.audioRestarts, detail });
      this.spawnAudio(generation);
      return;
    }
    this.audio = undefined;
    this.log('audio_disabled', { detail });
  }

  setQuality(next: Partial<VideoQuality>): void {
    const normalized = clampQuality(next, this.quality);
    const changed = normalized.width !== this.quality.width || normalized.height !== this.quality.height || normalized.fps !== this.quality.fps || normalized.bitrateKbps !== this.quality.bitrateKbps;
    if (!changed) return;
    this.quality = { ...this.quality, ...normalized };
    if (!this.running || !this.videoSocket || !this.encoder) return;
    const generation = this.generation;
    const old = this.video?.process;
    this.video = undefined;
    try { old?.kill(); } catch {}
    this.restarts++;
    this.spawnVideo(generation);
    this.log('video_quality_changed', { quality: this.quality });
  }

  setBitrate(kbps: number): void { this.setQuality({ bitrateKbps: kbps }); }

  setAudioDevice(device: string | null): void {
    this.config = { ...this.config, audioDevice: typeof device === 'string' && device.trim() ? device.trim() : null };
    if (!this.running) return;
    try { this.audio?.process.kill(); } catch {}
    try { this.audioSocket?.close(); } catch {}
    this.audio = undefined; this.audioSocket = undefined; this.audioRestarts = 0;
    if (!this.config.audioDevice) { this.log('audio_disabled', { reason: 'no_device' }); return; }
    const generation = this.generation;
    void this.bindSocket(generation, packet => {
      if (!this.running || generation !== this.generation) return;
      this.statsState.audioPackets++; this.statsState.audioBytes += packet.byteLength; this.sink?.audio(packet);
    }).then(socket => { if (!this.running || generation !== this.generation) { socket.close(); return; } this.audioSocket = socket; this.spawnAudio(generation); }).catch(error => this.log('audio_setup_failed', { error: String(error) }));
  }

  stats(): StreamStats {
    return { ...this.statsState, restarts: this.restarts, encoder: this.encoder ?? 'x264', quality: { ...this.quality }, running: this.running, startedAt: this.startedAt };
  }

  stop(): void {
    if (!this.running && !this.starting) return;
    this.running = false; this.starting = false; this.generation++;
    const generation = this.generation;
    this.cleanup(generation);
    this.log('stream_capture_stopped');
  }

  private cleanup(_generation: number): void {
    clearTimeout(this.stableTimer);
    this.stableTimer = undefined;
    for (const item of [this.video, this.audio]) { try { item?.process.kill(); } catch {} }
    this.video = undefined; this.audio = undefined;
    for (const socket of [this.videoSocket, this.audioSocket]) { try { socket?.close(); } catch {} }
    this.videoSocket = undefined; this.audioSocket = undefined;
    this.sink = undefined; this.startedAt = null;
  }
}
