import type { InputEvent } from '@nexora/shared';
import type { MediaSink, StreamStats, VideoQuality } from '../streaming/types.js';
import { InputManager, type InputSink } from '../input/input-manager.js';
import { InputDataChannelRouter, type InputDataChannel } from '../input/input-data-channel.js';
import type { CaptureEngine } from '../streaming/capture-engine.js';

export interface PeerMediaTransport {
  startSession(sessionId: string): Promise<void>;
  sendVideoRtp(packet: Buffer): void;
  sendAudioRtp(packet: Buffer): void;
  sendInput(event: InputEvent): Promise<void>;
  closeSession(sessionId: string): Promise<void>;
  stats?(): StreamStats;
}

/**
 * Integration boundary between Parts 4–6.
 * It deliberately does not implement WebRTC; a WebRTC adapter owns that transport.
 * Generation/session ownership prevents an old peer from receiving a new stream.
 */
export class SessionOrchestrator {
  private generation = 0;
  private activeSession: string | null = null;
  private readonly input: InputManager;
  private readonly inputChannel: InputDataChannelRouter;

  constructor(
    private readonly capture: CaptureEngine,
    private readonly transport: PeerMediaTransport,
    private readonly log: (event: string, fields?: object) => void = () => {}
  ) {
    const sink: InputSink = {
      send: event => this.transport.sendInput(event),
      releaseAll: async () => { /* receiver transport owns release-all semantics */ }
    };
    this.input = new InputManager(sink);
    this.inputChannel = new InputDataChannelRouter(this.input, this.log);
  }

  async start(sessionId: string): Promise<void> {
    if (!/^[A-Za-z0-9_-]{8,128}$/.test(sessionId)) throw new Error('Invalid session ID');
    const generation = ++this.generation;
    if (this.activeSession) await this.stop();
    this.activeSession = sessionId;
    await this.transport.startSession(sessionId);
    const sink: MediaSink = {
      video: packet => { if (generation === this.generation && this.activeSession === sessionId) this.transport.sendVideoRtp(packet); },
      audio: packet => { if (generation === this.generation && this.activeSession === sessionId) this.transport.sendAudioRtp(packet); }
    };
    try {
      await this.capture.start(sink);
      this.log('session_media_started', { sessionId });
    } catch (error) {
      if (this.activeSession === sessionId) this.activeSession = null;
      await this.transport.closeSession(sessionId);
      throw error;
    }
  }

  attachInputDataChannel(channel: InputDataChannel): void { this.inputChannel.attach(channel); }

  detachInputDataChannel(): void { this.inputChannel.detach(); }

  async handleInboundInput(event: InputEvent): Promise<boolean> {
    if (!this.activeSession) return false;
    return this.input.handle(event);
  }

  async setQuality(quality: Partial<VideoQuality>): Promise<void> {
    this.capture.setQuality(quality);
  }

  async stop(): Promise<void> {
    const session = this.activeSession;
    ++this.generation;
    this.activeSession = null;
    await this.capture.stop();
    if (session) await this.transport.closeSession(session);
    this.inputChannel.detach();
    await this.input.reset();
    this.log('session_media_stopped', { sessionId: session });
  }
}
