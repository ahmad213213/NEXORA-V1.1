import type { MediaSink } from '../streaming/types.js';

/**
 * Production-shaped bridge between the FFmpeg RTP stream and a WebRTC PeerConnection.
 *
 * Concrete WebRTC implementations (node-webrtc, electron custom, etc.) inject
 * the track publishers. Until a real publisher is provided the bridge records
 * packets and surfaces a clear readiness flag so callers never pretend media
 * is flowing when it is not.
 */
export interface TrackPublisher {
  publishVideo(packet: Buffer): void;
  publishAudio(packet: Buffer): void;
  close(): void;
}

export class WebRtcMediaBridge implements MediaSink {
  private publisher: TrackPublisher | null = null;
  private videoPackets = 0;
  private audioPackets = 0;
  private closed = false;

  /** Attach a real track publisher (from the concrete WebRTC stack). */
  attach(publisher: TrackPublisher): void {
    if (this.closed) throw new Error('WebRtcMediaBridge is closed');
    this.publisher = publisher;
  }

  detach(): void {
    try { this.publisher?.close(); } catch { /* ignore */ }
    this.publisher = null;
  }

  get ready(): boolean {
    return this.publisher !== null && !this.closed;
  }

  video(packet: Buffer): void {
    if (this.closed || !this.publisher) return;
    this.videoPackets++;
    this.publisher.publishVideo(packet);
  }

  audio(packet: Buffer): void {
    if (this.closed || !this.publisher) return;
    this.audioPackets++;
    this.publisher.publishAudio(packet);
  }

  stats() {
    return {
      videoPackets: this.videoPackets,
      audioPackets: this.audioPackets,
      ready: this.ready,
      closed: this.closed
    };
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    this.detach();
  }
}
