import type { InputDataChannelRouter, InputDataChannel } from '../input/input-data-channel.js';

/** Adapter contract for the concrete Host WebRTC implementation. */
export interface HostDataChannel {
  label: string;
  send(data: string): void;
  close(): void;
  onMessage(handler: (data: string) => void): void;
}

export function bindHostInputChannel(channel: HostDataChannel, router: InputDataChannelRouter): void {
  const adapted: InputDataChannel = {
    label: channel.label,
    send: data => channel.send(data),
    onMessage: handler => channel.onMessage(handler),
    close: () => channel.close()
  };
  router.attach(adapted);
}
