import { isValidSessionId, type MessageType, type SessionState, canTransitionSessionState } from '@nexora/shared';
import { sessionSignatureBytes, verifySignature } from './security.js';

export interface SecureMessage { protocol: 'NEXORA'; version: number; type: MessageType; sessionId: string; sequence: number; timestamp: number; from: string; to: string; payload: Record<string, unknown>; signature: string }

export class SessionSecurity {
  private state: SessionState = 'created';
  private lastInbound = -1;
  private readonly seen = new Set<number>();
  constructor(readonly sessionId: string, readonly localDeviceId: string, readonly peerDeviceId: string, private readonly protocolVersion: number, private readonly maxAgeMs = 120_000) {
    if (!isValidSessionId(sessionId)) throw new Error('Invalid session ID');
  }
  get lifecycle() { return this.state; }
  transition(next: SessionState) { if (!canTransitionSessionState(this.state, next)) throw new Error(`Invalid session transition: ${this.state} -> ${next}`); this.state = next; }
  validateInbound(message: SecureMessage, publicKey: string, now = Date.now()): boolean {
    if (message.protocol !== 'NEXORA' || message.version !== this.protocolVersion) return false;
    if (message.sessionId !== this.sessionId || message.to !== this.localDeviceId || message.from !== this.peerDeviceId) return false;
    if (!Number.isSafeInteger(message.sequence) || message.sequence < 0 || message.sequence <= this.lastInbound || this.seen.has(message.sequence)) return false;
    if (!Number.isSafeInteger(message.timestamp) || Math.abs(now - message.timestamp) > this.maxAgeMs) return false;
    const bytes = sessionSignatureBytes({ type: message.type, from: message.from, to: message.to, sessionId: message.sessionId, sequence: message.sequence, payload: message.payload, protocolVersion: message.version });
    if (!verifySignature(publicKey, bytes, message.signature)) return false;
    this.lastInbound = message.sequence; this.seen.add(message.sequence); if (this.seen.size > 256) this.seen.delete(Math.min(...this.seen)); return true;
  }
}
