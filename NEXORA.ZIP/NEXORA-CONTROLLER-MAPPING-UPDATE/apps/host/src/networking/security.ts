import { createHash, createPrivateKey, createPublicKey, generateKeyPairSync, sign, verify } from 'node:crypto';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

export interface DeviceIdentity {
  schema: 2;
  deviceId: string;
  publicKey: string;
  algorithm: 'Ed25519';
  createdAt: number;
  sign(bytes: Uint8Array): string;
}

const PUBLIC_KEY_BYTES = 32;
const SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');
const ID_RE = /^[a-f0-9]{32}$/;
const B64U_RE = /^[A-Za-z0-9_-]+$/;

type Stored = { schema: 2; publicKey: string; privateKey: string; createdAt: number };

function identityFile(userData: string) { return path.join(userData, 'identity-v2.json'); }
function decodePublic(value: string): Buffer {
  const bytes = Buffer.from(value, 'base64url');
  if (bytes.length !== PUBLIC_KEY_BYTES) throw new Error('Invalid Ed25519 public key');
  return bytes;
}
function deriveId(pub: Buffer) { return createHash('sha256').update(pub).digest('hex').slice(0, 32); }
function atomicWrite(file: string, value: unknown) {
  const tmp = `${file}.tmp`;
  return writeFile(tmp, JSON.stringify(value, null, 2), { encoding: 'utf8', mode: 0o600 }).then(() => rename(tmp, file));
}

export async function loadOrCreateIdentity(userData: string, now = Date.now()): Promise<DeviceIdentity> {
  await mkdir(userData, { recursive: true });
  const file = identityFile(userData);
  let stored: Stored;
  try {
    stored = JSON.parse(await readFile(file, 'utf8')) as Stored;
  } catch {
    const kp = generateKeyPairSync('ed25519');
    const privateKey = kp.privateKey.export({ format: 'der', type: 'pkcs8' }).toString('base64url');
    const publicKey = kp.publicKey.export({ format: 'der', type: 'spki' }).subarray(-PUBLIC_KEY_BYTES).toString('base64url');
    stored = { schema: 2, publicKey, privateKey, createdAt: now };
    await atomicWrite(file, stored);
  }
  if (stored.schema !== 2 || typeof stored.publicKey !== 'string' || typeof stored.privateKey !== 'string' || !B64U_RE.test(stored.publicKey) || !B64U_RE.test(stored.privateKey)) {
    throw new Error('NEXORA identity is invalid; refusing silent replacement');
  }
  const pub = decodePublic(stored.publicKey);
  let privateKey: ReturnType<typeof createPrivateKey>;
  try { privateKey = createPrivateKey({ key: Buffer.from(stored.privateKey, 'base64url'), format: 'der', type: 'pkcs8' }); }
  catch { throw new Error('NEXORA identity private key is invalid; refusing silent replacement'); }
  const derived = createPublicKey(privateKey).export({ format: 'der', type: 'spki' }).subarray(-PUBLIC_KEY_BYTES);
  if (!derived.equals(pub)) throw new Error('NEXORA identity public/private key mismatch');
  const deviceId = deriveId(pub);
  return { schema: 2, deviceId, publicKey: stored.publicKey, algorithm: 'Ed25519', createdAt: stored.createdAt, sign: (bytes) => sign(null, Buffer.from(bytes), privateKey).toString('base64url') };
}

export function verifySignature(publicKey: string, bytes: Uint8Array, signature: string): boolean {
  try {
    if (!B64U_RE.test(publicKey) || !B64U_RE.test(signature)) return false;
    const pub = decodePublic(publicKey);
    return verify(null, Buffer.from(bytes), createPublicKey({ key: Buffer.concat([SPKI_PREFIX, pub]), format: 'der', type: 'spki' }), Buffer.from(signature, 'base64url'));
  } catch { return false; }
}

export function deviceIdFromPublicKey(publicKey: string): string {
  return deriveId(decodePublic(publicKey));
}

export function authBytes(role: 'host' | 'receiver', deviceId: string, nonce: string, protocolVersion: number): Buffer {
  return Buffer.from(JSON.stringify(['NEXORA-auth', protocolVersion, role, deviceId, nonce]), 'utf8');
}

export function sessionSignatureBytes(input: { type: string; from: string; to: string; sessionId: string; sequence: number; payload: unknown; protocolVersion: number }): Buffer {
  return Buffer.from(JSON.stringify(['NEXORA-session', input.protocolVersion, input.type, input.from, input.to, input.sessionId, input.sequence, input.payload]), 'utf8');
}
