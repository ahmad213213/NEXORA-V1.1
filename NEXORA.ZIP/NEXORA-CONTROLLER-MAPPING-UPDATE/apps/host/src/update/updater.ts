import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { sha256, type UpdateManifest, validateManifest, compareVersions, verifyManifestSignature, isUpdateKeyConfigured } from './manifest.js';

export interface UpdateCheckResult { available: boolean; manifest: UpdateManifest | null; reason?: string; }

export async function checkUpdate(currentVersion: string, manifestUrl: string, publicKeyB64?: string): Promise<UpdateCheckResult> {
  if (publicKeyB64 !== undefined ? !isUpdateKeyConfigured(publicKeyB64) : !isUpdateKeyConfigured()) return { available: false, manifest: null, reason: 'Update service not configured' };
  if (!/^https:\/\//i.test(manifestUrl)) return { available: false, manifest: null, reason: 'Update URL must use HTTPS' };
  const response = await fetch(manifestUrl, { signal: AbortSignal.timeout(8000), headers: { accept: 'application/json' } });
  if (!response.ok) throw new Error(`Update manifest HTTP ${response.status}`);
  const manifest = validateManifest(await response.json());
  if (!(publicKeyB64 !== undefined ? verifyManifestSignature(manifest, publicKeyB64) : verifyManifestSignature(manifest))) return { available: false, manifest: null, reason: 'Invalid update signature' };
  return { available: compareVersions(manifest.version, currentVersion) > 0, manifest };
}

export async function downloadAndStage(manifest: UpdateManifest): Promise<string> {
  const response = await fetch(manifest.url, { signal: AbortSignal.timeout(120_000) });
  if (!response.ok) throw new Error(`Update package HTTP ${response.status}`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.byteLength !== manifest.size) throw new Error('Update package size mismatch');
  if (sha256(bytes) !== manifest.sha256) throw new Error('Update package hash mismatch');
  const dir = path.join(os.tmpdir(), 'NEXORA', 'updates', manifest.version);
  await mkdir(dir, { recursive: true });
  const packagePath = path.join(dir, 'NEXORA-Host-update.zip');
  await writeFile(packagePath, bytes, { flag: 'wx' }).catch(async (error: any) => { if (error?.code === 'EEXIST') await rm(packagePath, { force: true }).then(() => writeFile(packagePath, bytes)); else throw error; });
  return packagePath;
}

export function launchExternalUpdater(options: { packagePath: string; installDir: string; currentPid: number; expectedSha256: string; version: string; scriptPath: string }): void {
  const script = options.scriptPath;
  const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, '-Package', options.packagePath, '-InstallDir', options.installDir, '-ProcessId', String(options.currentPid), '-Sha256', options.expectedSha256, '-Version', options.version];
  const child = spawn('powershell.exe', args, { detached: true, stdio: 'ignore', windowsHide: true });
  child.unref();
}

/**
 * Copies an updater script out of the install folder (and out of any asar) into the temp folder, so the
 * script can replace the install folder without being locked by its own running file.
 */
export async function stageUpdaterScript(sourcePath: string): Promise<string> {
  const bytes = await readFile(sourcePath);
  const dir = path.join(os.tmpdir(), 'NEXORA', 'updater');
  await mkdir(dir, { recursive: true });
  const target = path.join(dir, `${randomUUID()}-${path.basename(sourcePath)}`);
  await writeFile(target, bytes);
  return target;
}

/** True when `child` is the same as or inside `parent` (Windows-style, case-insensitive). */
export function isInsideFolder(parent: string, child: string): boolean {
  const p = path.resolve(parent).toLowerCase().replace(/[\\/]+$/, '');
  const c = path.resolve(child).toLowerCase();
  return c === p || c.startsWith(p + path.sep) || c.startsWith(p + '/');
}

/** A picked file must be a real, non-empty zip (PK header). The full safety checks run in the updater script. */
export async function assertZipFile(file: string): Promise<void> {
  if (!/\.zip$/i.test(file)) throw new Error('Please choose a .zip file.');
  const info = await stat(file);
  if (!info.isFile() || info.size < 22) throw new Error('That file is empty or not a zip.');
  const handle = await (await import('node:fs/promises')).open(file, 'r');
  try {
    const head = Buffer.alloc(2);
    await handle.read(head, 0, 2, 0);
    if (head[0] !== 0x50 || head[1] !== 0x4b) throw new Error('That file is not a valid zip.');
  } finally { await handle.close(); }
}

export type LocalUpdateMode = 'patch' | 'restore';

export function launchLocalUpdater(options: { mode: LocalUpdateMode; packagePath: string; backupZip?: string; installDir: string; currentPid: number; scriptPath: string }): void {
  const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', options.scriptPath, '-Mode', options.mode, '-Package', options.packagePath, '-InstallDir', options.installDir, '-ProcessId', String(options.currentPid)];
  if (options.backupZip) args.push('-BackupZip', options.backupZip);
  const child = spawn('powershell.exe', args, { detached: true, stdio: 'ignore', windowsHide: true });
  child.unref();
}
