import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

export interface UpdateSettings {
  manifestUrl: string;
  publicKeyB64: string;
}

async function firstLine(file: string): Promise<string> {
  try {
    const text = (await readFile(file, 'utf8')).replace(/^\uFEFF/, '');
    return text.split(/\r?\n/).map(l => l.trim()).find(Boolean) ?? '';
  } catch {
    return '';
  }
}

/**
 * Where the online update service is configured. Environment variables win; otherwise two one-line
 * text files in <userData>/update/ are used: update-url.txt and update-public-key.txt.
 * Without both, online updates are simply "not set up" and the user can still use "Update from a file".
 */
export async function loadUpdateSettings(dir: string, env: Record<string, string | undefined> = process.env): Promise<UpdateSettings> {
  const manifestUrl = (env.NEXORA_UPDATE_MANIFEST_URL || await firstLine(path.join(dir, 'update-url.txt'))).trim();
  const publicKeyB64 = (env.NEXORA_UPDATE_PUBLIC_KEY_B64 || await firstLine(path.join(dir, 'update-public-key.txt'))).trim();
  return { manifestUrl, publicKeyB64 };
}

const HTTPS = /^https:\/\/.+/i;
const B64 = /^[A-Za-z0-9+/_-]+=*$/;

/** Persist update URL + public key into <dir> (does not override env vars at runtime). */
export async function saveUpdateSettings(
  dir: string,
  input: { manifestUrl?: string; publicKeyB64?: string }
): Promise<UpdateSettings> {
  await mkdir(dir, { recursive: true });
  const current = await loadUpdateSettings(dir, {});
  const manifestUrl = typeof input.manifestUrl === 'string' ? input.manifestUrl.trim() : current.manifestUrl;
  const publicKeyB64 = typeof input.publicKeyB64 === 'string' ? input.publicKeyB64.trim() : current.publicKeyB64;
  if (manifestUrl && !HTTPS.test(manifestUrl)) throw new Error('Update URL must be HTTPS');
  if (publicKeyB64 && (publicKeyB64.length < 32 || publicKeyB64.length > 128 || !B64.test(publicKeyB64))) {
    throw new Error('Public key must be base64 (or base64url), 32–128 characters');
  }
  await writeFile(path.join(dir, 'update-url.txt'), manifestUrl ? `${manifestUrl}\n` : '', { encoding: 'utf8', mode: 0o600 });
  await writeFile(path.join(dir, 'update-public-key.txt'), publicKeyB64 ? `${publicKeyB64}\n` : '', { encoding: 'utf8', mode: 0o600 });
  return { manifestUrl, publicKeyB64 };
}

export function isUpdateConfigured(settings: UpdateSettings): boolean {
  return Boolean(settings.manifestUrl && settings.publicKeyB64);
}
