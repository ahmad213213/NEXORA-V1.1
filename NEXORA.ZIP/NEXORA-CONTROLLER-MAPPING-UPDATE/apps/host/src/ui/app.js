(() => {
  "use strict";
  const app = document.getElementById("app");
  const desktop = document.getElementById("desktop-ui");
  const consoleUI = document.getElementById("console-ui");
  const toConsole = document.getElementById("to-console");
  const toDesktop = document.getElementById("console-return");
  const overlay = document.getElementById("console-overlay");
  const overlayTitle = document.getElementById("console-panel-title");
  const overlayContent = document.getElementById("console-panel-content");
  const crumb = document.getElementById("crumb-current");
  const toast = document.getElementById("preview-toast");
  const pageNames = {
    dashboard: "Home", library: "Library", remoteplay: "Remote Play", performance: "Performance",
    streaming: "Streaming", networking: "Networking", controls: "Controls",
    patcher: "AI Patcher", settings: "Settings"
  };
  const ACCENTS = {
    cyan:   { name: "Aurora cyan",  stops: ["#ed40eb", "#8b69ff", "#3aabff", "#27f4ff"], a: "#4ac8ff", a2: "#8b69ff", a3: "#27f4ff", glow: "rgba(74,200,255,.38)" },
    blue:   { name: "Electric blue", stops: ["#5b8cff", "#3a6bff", "#2d9bff", "#5ee7ff"], a: "#4b9dff", a2: "#547bff", a3: "#5ee7ff", glow: "rgba(75,157,255,.38)" },
    violet: { name: "Nebula violet", stops: ["#c84bff", "#9b5cff", "#6b7bff", "#4ad4ff"], a: "#ab8bff", a2: "#9b5cff", a3: "#c84bff", glow: "rgba(171,139,255,.4)" },
    amber:  { name: "Solar amber",  stops: ["#ff8a3d", "#ffb347", "#ffd06b", "#ffe9a0"], a: "#ffc067", a2: "#ff8a3d", a3: "#ffd06b", glow: "rgba(255,192,103,.4)" },
    emerald:{ name: "Jade emerald", stops: ["#2ee6a6", "#1ec8b0", "#3ab8ff", "#7ef0d0"], a: "#2ee6a6", a2: "#1ec8b0", a3: "#3ab8ff", glow: "rgba(46,230,166,.38)" },
    rose:   { name: "Rose neon",    stops: ["#ff4d8d", "#ff6bb5", "#c77dff", "#ff9ec8"], a: "#ff4d8d", a2: "#ff6bb5", a3: "#c77dff", glow: "rgba(255,77,141,.4)" }
  };

  const settingsSections = window.NEXORASettingsStore.schema;
  const qualityChoices = ["720p · 30 fps", "720p · 60 fps", "1080p · 60 fps", "1440p · 60 fps", "2160p · 60 fps"];
  let toastTimer = null;
  let switchTimer = null;
  let selectedQuality = 2;
  let selectedGame = null;
  let currentGames = [];
  let activeSettings = "Appearance";
  let activeDesktopSettings = "Appearance";
  const homeDefaults = {
    hero: document.querySelector("[data-view='dashboard'] .featured-game")?.innerHTML || "",
    library: document.querySelector("[data-view='dashboard'] .concept-library-row")?.innerHTML || "",
    recent: document.querySelector("[data-view='dashboard'] .game-row")?.innerHTML || ""
  };


  function showToast(message = "Done") {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function showPage(page) {
    if (!pageNames[page]) return;
    document.querySelectorAll(".nav-item[data-page]").forEach(button => {
      const active = button.dataset.page === page;
      button.classList.toggle("active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
    document.querySelectorAll(".page-view[data-view]").forEach(view => {
      view.classList.toggle("active", view.dataset.view === page);
    });
    crumb.textContent = pageNames[page];
    document.getElementById("desktop-content").scrollTop = 0;
  }


  function formatBytes(bytes) {
    const n = Number(bytes || 0);
    if (!Number.isFinite(n) || n <= 0) return "Unknown";
    const units = ["B", "KB", "MB", "GB"];
    let v = n, i = 0;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
    return `${v.toFixed(i ? 1 : 0)} ${units[i]}`;
  }

  function gameTitle(game) { return game?.metadata?.title || game?.executableInfo?.detectedGameName || game?.executableInfo?.productName || game?.name || "Game"; }
  function gameDeveloper(game) { return game?.metadata?.developers?.[0] || game?.metadata?.publishers?.[0] || game?.executableInfo?.detectedDeveloper || game?.executableInfo?.companyName || "Windows game"; }
  function gameHero(game) { return game?.metadata?.hero?.url || game?.metadata?.cover?.url || ""; }
  function gameCover(game) { return game?.metadata?.cover?.url || game?.metadata?.hero?.url || ""; }
  function executablePresentation(game) {
    const x = game?.executableInfo || {};
    const signature = String(x.signatureStatus || "").toLowerCase();
    const signed = signature === "valid" || signature.includes("valid");
    const version = x.productVersion || x.fileVersion || "";
    return {
      title: gameTitle(game),
      developer: gameDeveloper(game),
      version,
      signed,
      signatureLabel: x.signatureStatus ? (signed ? "Verified executable" : `Signature: ${x.signatureStatus}`) : "Executable inspected",
      originalFile: x.originalFilename || x.fileName || "",
      productName: x.productName || x.fileDescription || "",
      sha256: x.sha256 || ""
    };
  }
  function formatRelease(value) { if (!value) return "Release date unavailable"; const d = new Date(value); return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString(undefined,{year:"numeric",month:"long",day:"numeric"}); }
  function ratingHeadline(game) {
    const ratings = game?.metadata?.ratings || [];
    const preferred = ratings.find(r => r.kind === "players") || ratings.find(r => r.score != null) || ratings[0];
    return preferred ? preferred.display : "";
  }

  function ratingRatio(rating) {
    const score = Number(rating?.score);
    const outOf = Number(rating?.outOf);
    if (!Number.isFinite(score) || !Number.isFinite(outOf) || outOf <= 0) return null;
    return Math.max(0, Math.min(1, score / outOf));
  }
  function ratingTone(rating) {
    const ratio = ratingRatio(rating);
    if (ratio == null) return "neutral";
    return ratio >= .75 ? "good" : ratio >= .5 ? "mid" : "bad";
  }
  function ratingSourceKey(source = "") {
    const q = String(source).toLowerCase();
    if (q.includes("steam")) return "steam";
    if (q.includes("ign")) return "ign";
    if (q.includes("epic")) return "epic";
    if (q.includes("metacritic")) return "metacritic";
    if (q.includes("igdb")) return "igdb";
    if (q.includes("rawg")) return "rawg";
    if (q.includes("moby")) return "mobygames";
    return "rating";
  }
  function reviewLogo(rating) {
    const key = ratingSourceKey(rating?.source);
    return `<img class="nexora-review-source-logo" src="assets/review-sources/${key}.svg" alt="">`;
  }
  function requirementRows(value) {
    const raw = String(value || "").replace(/\s+/g, " ").trim();
    if (!raw) return [];
    const labels = ["OS","Processor","Memory","Graphics","DirectX","Network","Storage","Sound Card","Additional Notes"];
    const rx = new RegExp(`(?:^|\\s)(${labels.map(x=>x.replace(" ","\\s+")).join("|")})\\s*[:*]\\s*`, "ig");
    const matches = [...raw.matchAll(rx)];
    if (!matches.length) return [["Details", raw.replace(/^(Minimum|Recommended)\s*:\s*/i, "")]];
    const rows = [];
    const prefix = raw.slice(0, matches[0].index).replace(/^(Minimum|Recommended)\s*:\s*/i, "").trim();
    if (prefix) rows.push(["Details", prefix]);
    matches.forEach((m, i) => {
      const start = m.index + m[0].length;
      const end = i + 1 < matches.length ? matches[i+1].index : raw.length;
      const v = raw.slice(start, end).trim();
      if (v) rows.push([m[1].replace(/\s+/g," "), v]);
    });
    return rows;
  }
  function requirementCard(label, value) {
    const rows = requirementRows(value);
    return `<article class="panel glass nexora-req-card"><small>${label}</small>${rows.length ? `<dl>${rows.map(([k,v])=>`<div><dt>${escapeHTML(k)}</dt><dd>${escapeHTML(v)}</dd></div>`).join("")}</dl>` : `<p>Requirements are not available for this title.</p>`}</article>`;
  }
  function formatLastPlayed(value) {
    if (!value) return "";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleString(undefined,{year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"});
  }
  async function hydrateMissingGameFacts(game) {
    const api = window.nexora;
    if (!api?.enrichGameMetadata || !game) return;
    const needsRelease = !game.metadata?.releaseDate;
    const needsLogo = !game.metadata?.developerLogoUrl;
    if (!needsRelease && !needsLogo) return;
    try {
      const extra = await api.enrichGameMetadata(gameTitle(game), gameDeveloper(game));
      if (!extra) return;
      if (needsRelease && extra.releaseDate) {
        game.metadata ||= {}; game.metadata.releaseDate = extra.releaseDate;
        const el = document.querySelector("[data-detail-release]"); if (el) el.textContent = formatRelease(extra.releaseDate);
      }
      if (needsLogo && extra.developerLogoUrl) {
        game.metadata ||= {}; game.metadata.developerLogoUrl = extra.developerLogoUrl;
        const holder = document.querySelector("[data-detail-studio]");
        if (holder) holder.innerHTML = `<img class="nexora-studio-logo" src="${escapeHTML(extra.developerLogoUrl)}" alt=""><div><small>DEVELOPER / PUBLISHER</small><b>${escapeHTML(gameDeveloper(game))}</b></div>`;
      }
    } catch {}
  }

  function ensureGameDetailsPage() {
    let page = document.getElementById("page-game-details");
    if (page) return page;
    page = document.createElement("section");
    page.id = "page-game-details";
    page.className = "page-view nexora-game-details-page";
    page.dataset.view = "game-details";
    document.getElementById("desktop-content")?.appendChild(page);
    return page;
  }

  function openGameDetails(gameId) {
    const game = currentGames.find(g => g.id === gameId);
    if (!game) return;
    selectedGame = game;
    const page = ensureGameDetailsPage();
    const meta = game.metadata || {};
    const hero = gameHero(game);
    const gameLogo = meta.logo?.url || "";
    const studioLogo = meta.developerLogoUrl || "";
    const screenshots = Array.isArray(meta.screenshots) ? meta.screenshots : [];
    const ratings = Array.isArray(meta.ratings) ? meta.ratings.filter(r => {
      const display = String(r?.display || "").trim();
      const score = Number(r?.score);
      const outOf = Number(r?.outOf);
      if (/^0(?:\.0+)?%?$/.test(display)) return false;
      if (Number.isFinite(score) && Number.isFinite(outOf) && outOf > 0 && score <= 0) return false;
      return Boolean(display || (Number.isFinite(score) && Number.isFinite(outOf) && outOf > 0));
    }) : [];
    const req = meta.requirements || {};
    const genres = Array.isArray(meta.genres) ? meta.genres : [];
    const developer = gameDeveloper(game);
    const genreText = genres.length ? genres.slice(0, 4).join(" · ") : "Genre unavailable";
    const preferredRating = ratings.find(r => r.kind === "players") || ratings.find(r => r.score != null) || ratings[0];
    const reviewTone = ratingTone(preferredRating);
    const reviewRows = ratings.length ? ratings.slice(0,5).map(r=>`<div class="nexora-review-row ${ratingTone(r)}">${reviewLogo(r)}<span><b>${escapeHTML(r.source || "Rating")}</b><small>${escapeHTML(r.display)}</small></span><i aria-hidden="true"></i></div>`).join("") : "";
    const reviewPanel = ratings.length ? `<aside class="nexora-review-card ${reviewTone}"><div class="nexora-review-card-head"><span><i></i> REVIEWS</span><strong>${escapeHTML(ratingHeadline(game))}</strong></div><div class="nexora-review-list">${reviewRows}</div></aside>` : "";
    page.innerHTML = `
      <button class="nexora-detail-back" type="button" data-goto="library">← Back to Library</button>
      <article class="nexora-detail-hero glass"${hero ? ` style="--detail-hero:url('${escapeHTML(hero)}')"` : ""}>
        <div class="nexora-detail-hero-bg"></div><div class="nexora-detail-shade"></div>
        <div class="nexora-detail-hero-content">
          ${gameLogo ? `<img class="nexora-detail-logo" src="${escapeHTML(gameLogo)}" alt="${escapeHTML(gameTitle(game))} logo">` : ""}
          <span class="eyebrow-small">YOUR LIBRARY · WINDOWS PC</span>
          <h1>${escapeHTML(gameTitle(game))}</h1>
          <div class="nexora-detail-studio" data-detail-studio>${studioLogo ? `<img class="nexora-studio-logo" src="${escapeHTML(studioLogo)}" alt="">` : `<span class="nexora-studio-mark">${escapeHTML(developer.slice(0,1).toUpperCase())}</span>`}<div><small>DEVELOPER / PUBLISHER</small><b>${escapeHTML(developer)}</b></div></div>
          <div class="nexora-detail-facts">
            <div><small>RELEASE DATE</small><strong data-detail-release>${escapeHTML(formatRelease(meta.releaseDate))}</strong></div>
            <div><small>GENRE</small><strong>${escapeHTML(genreText)}</strong></div>
          </div>
          <div class="nexora-detail-actions"><button class="nexora-play-large" type="button" data-game-launch="${escapeHTML(game.id)}"><svg><use href="#i-play"/></svg> Play</button><button class="nexora-remove-game" type="button" data-remove-game="${escapeHTML(game.id)}">Remove Game</button></div>
        </div>
      </article>
      <section class="nexora-detail-copy nexora-about-review"><div class="nexora-about-copy"><span class="eyebrow-small">ABOUT THIS GAME</span><h2>${escapeHTML(gameTitle(game))}</h2><p>${escapeHTML(meta.description || meta.shortDescription || "No description is available for this game yet.")}</p></div>${reviewPanel}</section>
      ${screenshots.length ? `<section class="nexora-detail-section"><div class="section-heading"><div><span class="eyebrow-small">SCREENSHOTS</span><h2>In-game gallery</h2></div><span>${screenshots.length} images</span></div><div class="nexora-shot-grid">${screenshots.map((src,i)=>`<img src="${escapeHTML(src)}" alt="${escapeHTML(gameTitle(game))} screenshot ${i+1}" loading="lazy">`).join("")}</div></section>` : ""}
      <section class="nexora-detail-section nexora-requirements"><div class="section-heading"><div><span class="eyebrow-small">PC REQUIREMENTS</span><h2>System requirements</h2></div></div><div class="nexora-req-grid">${requirementCard("MINIMUM",req.minimum)}${requirementCard("RECOMMENDED",req.recommended)}</div></section>`;
    document.querySelectorAll(".nav-item[data-page]").forEach(b=>b.classList.remove("active"));
    document.querySelectorAll(".page-view[data-view]").forEach(v=>v.classList.toggle("active", v === page));
    crumb.textContent = "Game Details";
    document.getElementById("desktop-content").scrollTop = 0;
    const studioImage = page.querySelector(".nexora-studio-logo");
    if (studioImage) studioImage.addEventListener("error", () => { if (game.metadata) game.metadata.developerLogoUrl = ""; void hydrateMissingGameFacts(game); }, { once: true });
    void hydrateMissingGameFacts(game);
  }

  function renderHomeLibrary(games) {
    const heroCard = document.querySelector("[data-view='dashboard'] .featured-game");
    const homeRow = document.querySelector("[data-view='dashboard'] .concept-library-row");
    const recentRow = document.querySelector("[data-view='dashboard'] .game-row");
    const gameCount = document.querySelector("[data-view='dashboard'] .concept-library .sort-pill");
    if (gameCount) gameCount.textContent = `${games.length} GAME${games.length===1?"":"S"}  ⌄`;
    if (heroCard) { heroCard.classList.remove("nexora-live-hero"); if (heroCard.innerHTML !== homeDefaults.hero) heroCard.innerHTML = homeDefaults.hero; }
    if (!games.length) {
      if (homeRow) { homeRow.classList.add("empty-game-row"); homeRow.innerHTML = homeDefaults.library; }
      if (recentRow) { recentRow.classList.add("empty-game-row"); recentRow.innerHTML = homeDefaults.recent; }
      return;
    }
    const card = g => `<button class="nexora-home-game glass" type="button" data-game-open="${escapeHTML(g.id)}">${gameCover(g)?`<img src="${escapeHTML(gameCover(g))}" alt="">`:"<span class='nexora-game-placeholder'>N</span>"}<span><b>${escapeHTML(gameTitle(g))}</b><small>${escapeHTML(gameDeveloper(g))}</small></span></button>`;
    if (homeRow) { homeRow.classList.remove("empty-game-row"); homeRow.innerHTML = games.slice(0,6).map(card).join(""); }
    if (recentRow) {
      const recent=[...games].filter(g=>Boolean(g.lastPlayedAt)).sort((a,b)=>new Date(b.lastPlayedAt)-new Date(a.lastPlayedAt));
      if (!recent.length) { recentRow.classList.add("empty-game-row"); recentRow.innerHTML = `<div class="nexora-no-recent panel glass"><b>No recently played games</b><small>Games appear here after you launch them from NEXORA.</small></div>`; }
      else { recentRow.classList.remove("empty-game-row"); recentRow.innerHTML=recent.slice(0,5).map(g=>`<button class="nexora-home-game glass" type="button" data-game-open="${escapeHTML(g.id)}">${gameCover(g)?`<img src="${escapeHTML(gameCover(g))}" alt="">`:`<span class='nexora-game-placeholder'>N</span>`}<span><b>${escapeHTML(gameTitle(g))}</b><small>${escapeHTML(gameDeveloper(g))}</small><em>Last played ${escapeHTML(formatLastPlayed(g.lastPlayedAt))}</em></span></button>`).join(""); }
    }
  }

  function normalizedGameIdentity(game) {
    const title = String(gameTitle(game) || "").toLowerCase().replace(/[™®©]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
    const exe = String(game?.exePath || "").replace(/\\/g, "/").toLowerCase().trim();
    const hash = String(game?.executableInfo?.sha256 || "").toLowerCase().trim();
    return { title, exe, hash };
  }

  function uniqueUiGames(games) {
    const out = [];
    const exe = new Set(), hash = new Set(), title = new Set();
    for (const game of Array.isArray(games) ? games : []) {
      const id = normalizedGameIdentity(game);
      if ((id.exe && exe.has(id.exe)) || (id.hash && hash.has(id.hash)) || (id.title && title.has(id.title))) continue;
      if (id.exe) exe.add(id.exe); if (id.hash) hash.add(id.hash); if (id.title) title.add(id.title);
      out.push(game);
    }
    return out;
  }

  function renderConsoleLibrary(games) {
    const stage = document.querySelector(".console-game-stage");
    const bottom = document.querySelector(".console-bottom-line span:first-child");
    if (!stage) return;
    const clean = uniqueUiGames(games);
    stage.classList.toggle("nexora-console-has-games", Boolean(clean.length));
    stage.classList.toggle("nexora-console-multiple", clean.length > 1);
    stage.classList.toggle("nexora-console-single", clean.length === 1);
    if (!clean.length) {
      selectedGame = null;
      stage.innerHTML = `<article class="console-feature console-empty-feature nexora-console-empty" aria-label="No game added"><div class="console-feature-bg"></div><div class="console-feature-shade"></div><div class="console-feature-content"><div class="console-feature-top"><span class="console-selected-badge"><i></i> LIBRARY</span></div><div class="console-feature-title"><div class="console-empty-pad"><svg><use href="#i-dualsense"/></svg></div><h1 id="console-game-title">NO GAME ADDED</h1><div class="console-game-tagline">ADD A WINDOWS GAME TO SEE IT HERE</div></div><div class="console-feature-actions"><button class="console-play" type="button" data-preview-empty-add><span class="button-icon"><svg><use href="#i-plus"/></svg></span>Add a Game</button></div></div></article>`;
      if (bottom) bottom.innerHTML = `<i></i> LIBRARY EMPTY <b>·</b> READY`;
      return;
    }
    const selectedId = selectedGame?.id;
    const g = clean.find(x => x.id === selectedId) || clean[0];
    selectedGame = g;
    const hero = gameHero(g);
    const identity = executablePresentation(g);
    const meta = g.metadata || {};
    const genres = Array.isArray(meta.genres) ? meta.genres.slice(0,2).join(" · ") : "";
    const release = meta.releaseDate ? formatRelease(meta.releaseDate) : "";
    const facts = [identity.developer, release, genres, identity.version].filter(Boolean);
    const currentKey = normalizedGameIdentity(g);
    const railGames = clean.filter(x => {
      if (x.id === g.id) return false;
      const k = normalizedGameIdentity(x);
      return !((k.exe && currentKey.exe && k.exe === currentKey.exe) || (k.hash && currentKey.hash && k.hash === currentKey.hash) || (k.title && currentKey.title && k.title === currentKey.title));
    });
    const rail = railGames.length > 0 ? `<div class="console-game-rail" aria-label="Other games in your library">${railGames.map(x=>`<button type="button" class="console-cover" data-game="${escapeHTML(x.id)}" aria-label="Select ${escapeHTML(gameTitle(x))}">${gameCover(x)?`<img src="${escapeHTML(gameCover(x))}" alt="" loading="eager">`:"<span class='nexora-game-placeholder'>N</span>"}<small>${escapeHTML(gameTitle(x))}</small></button>`).join("")}</div>` : "";
    stage.innerHTML = `<article class="console-feature nexora-console-live" data-console-feature-id="${escapeHTML(g.id)}"><div class="console-feature-bg"></div><div class="console-feature-shade"></div><div class="console-feature-content"><div class="console-feature-top"><span class="console-selected-badge"><i></i> YOUR LIBRARY</span></div><div class="console-feature-title"><h1 id="console-game-title">${escapeHTML(identity.title)}</h1><div class="console-game-info">${facts.map((fact,i)=>`<span class="console-info-${i}">${escapeHTML(fact)}</span>`).join("")}</div></div><div class="console-feature-actions"><button class="console-play" type="button" data-game-launch="${escapeHTML(g.id)}"><span class="button-icon"><svg><use href="#i-play"/></svg></span>Play</button><button class="console-view" type="button" data-console-game-details="${escapeHTML(g.id)}"><span class="button-icon"><svg><use href="#i-library"/></svg></span>View Game</button></div></div></article>${rail}`;
    const bg = stage.querySelector('.console-feature-bg');
    if (bg) {
      if (hero) {
        const heroUrl = `url("${String(hero).replace(/"/g,'%22')}")`;
        bg.style.setProperty('--console-hero', heroUrl);
        bg.style.backgroundImage = heroUrl;
      } else {
        bg.style.removeProperty('--console-hero');
        bg.style.backgroundImage = '';
      }
    }
    if (bottom) bottom.innerHTML = `<i></i> LIBRARY READY`;
  }

  async function refreshLibraryScreen() {
    const api = window.nexora;
    if (!api?.listGames) return;
    try {
      const games = await api.listGames();
      const rawGames = Array.isArray(games) ? games : [];
      currentGames = uniqueUiGames(rawGames);
      const grid = document.querySelector("#page-library .library-grid");
      const count = document.querySelector("#page-library .tab-strip button:first-child span");
      if (count) count.textContent = String(currentGames.length);
      if (grid) {
        if (currentGames.length) {
          grid.classList.remove("empty-library-grid");
          grid.innerHTML = currentGames.map(game => `<button type="button" class="nexora-library-card panel glass" data-game-open="${escapeHTML(game.id)}">${gameCover(game)?`<img src="${escapeHTML(gameCover(game))}" alt="">`:`<div class="nexora-game-placeholder">N</div>`}<div class="nexora-library-card-copy"><b>${escapeHTML(gameTitle(game))}</b><small>${escapeHTML(gameDeveloper(game))}</small><span>${escapeHTML(game.metadata?.releaseDate || "Windows PC")}</span></div></button>`).join("");
        } else {
          grid.classList.add("empty-library-grid");
          grid.innerHTML = `<article class="library-empty-state panel glass" role="status"><span class="empty-games-icon"><svg><use href="#i-library"/></svg></span><h2>No games added yet</h2><p>Your game collection will appear here. Click Add a Game to choose a Windows .exe on this PC.</p><button class="primary-action" type="button" data-preview-empty-add><svg><use href="#i-plus"/></svg> Add a Game</button></article>`;
        }
      }
      renderHomeLibrary(currentGames);
      renderConsoleLibrary(currentGames);
    } catch { /* keep existing shell if storage is unavailable */ }
  }

  function buildExecutableDetails(info = {}) {
    const rows = [
      ["Product", info.productName || info.fileDescription],
      ["Detected game", info.detectedGameName || info.productName || info.fileDescription],
      ["Developer / publisher", info.detectedDeveloper || info.companyName],
      ["Product version", info.productVersion],
      ["File version", info.fileVersion],
      ["Original file", info.originalFilename || info.fileName],
      ["Internal name", info.internalName],
      ["Language", info.language],
      ["File size", formatBytes(info.fileSize)],
      ["Digital signature", info.signatureStatus],
      ["Signer", info.signerSubject],
      ["Certificate issuer", info.signerIssuer],
      ["SHA-256", info.sha256]
    ].filter(([, value]) => value);
    return rows.map(([label, value]) => `<div class="nexora-exe-row"><span>${escapeHTML(label)}</span><b title="${escapeHTML(value)}">${escapeHTML(value)}</b></div>`).join("");
  }

  let addGameFlowOpen = false;

  async function handleAddGame() {
    if (addGameFlowOpen) return;
    addGameFlowOpen = true;
    const api = window.nexora;
    if (!api || typeof api.beginAddGame !== "function" || typeof api.orbitSearch !== "function" || typeof api.orbitChoose !== "function") {
      showToast("Add Game is only available in the NEXORA desktop app.");
      addGameFlowOpen = false;
      return;
    }

    let pendingId = null;
    let requestId = 0;
    let latestRequestId = -1;
    let allOptions = [];
    let removeProgress = null;
    let closed = false;

    const closeDialog = async (cancel = true) => {
      if (closed) return;
      closed = true;
      removeProgress?.();
      document.querySelector(".nexora-add-overlay")?.remove();
      addGameFlowOpen = false;
      if (cancel && pendingId && api.orbitCancel) {
        try { await api.orbitCancel(pendingId); } catch { /* ignore cleanup errors */ }
      }
    };

    try {
      showToast("Select the game executable…");
      const begun = await api.beginAddGame();
      if (!begun || begun.status === "cancelled") { addGameFlowOpen = false; return; }
      if (begun.status === "exists") {
        showToast(begun?.game?.name ? `Already in library: ${begun.game.name}` : "That executable is already in your library.");
        addGameFlowOpen = false;
        return;
      }
      if (begun.status !== "ready" || !begun.pendingId) throw new Error("Could not start Add Game.");
      pendingId = begun.pendingId;

      const overlayEl = document.createElement("div");
      overlayEl.className = "nexora-add-overlay";
      overlayEl.innerHTML = `
        <section class="nexora-add-dialog glass" role="dialog" aria-modal="true" aria-label="Add Game">
          <header><div><span class="eyebrow-small">ADD TO LIBRARY</span><h2>Add Game</h2></div><button class="nexora-add-close" type="button" aria-label="Close">×</button></header>
          <div class="nexora-exe-summary">
            <div class="nexora-exe-heading"><span>Selected game file</span><b>${escapeHTML(begun.exeFile || "game.exe")}</b></div>
          </div>
          <div class="nexora-search-row">
            <input class="nexora-game-name" type="text" maxlength="120" value="${escapeHTML(begun.suggestedName || "")}" placeholder="Game name" autocomplete="off" spellcheck="false">
            <button class="nexora-search-button" type="button">Search</button>
          </div>
          <div class="nexora-search-status">Game name suggested automatically. Edit it if needed, then Search.</div>
          <div class="nexora-result-tabs" hidden><button class="active" type="button" data-tab="best">Best matches</button><button type="button" data-tab="all">All results</button></div>
          <div class="nexora-results"></div>
          <button class="nexora-view-all" type="button" hidden>View All</button>
          <div class="nexora-add-progress" hidden><div><b>Adding game…</b><span class="nexora-progress-detail">Preparing details</span></div><div class="nexora-progress-track"><i></i></div></div>
        </section>`;
      document.body.appendChild(overlayEl);

      const dialog = overlayEl.querySelector(".nexora-add-dialog");
      const input = overlayEl.querySelector(".nexora-game-name");
      const searchButton = overlayEl.querySelector(".nexora-search-button");
      const status = overlayEl.querySelector(".nexora-search-status");
      const results = overlayEl.querySelector(".nexora-results");
      const viewAll = overlayEl.querySelector(".nexora-view-all");
      const tabs = overlayEl.querySelector(".nexora-result-tabs");
      const progress = overlayEl.querySelector(".nexora-add-progress");
      const progressDetail = overlayEl.querySelector(".nexora-progress-detail");
      const progressBar = overlayEl.querySelector(".nexora-progress-track i");

      const renderOptions = (showAll = false) => {
        const shown = showAll ? allOptions : allOptions.slice(0, 3);
        results.innerHTML = shown.map(option => `
          <button type="button" class="nexora-game-result" data-option-index="${Number(option.index)}">
            ${option.thumbnail ? `<img src="${escapeHTML(option.thumbnail)}" alt="">` : `<span class="nexora-result-placeholder">N</span>`}
            <span class="nexora-result-copy"><b>${escapeHTML(option.title)}</b><small>${escapeHTML([option.provider, `${option.matchPercent}% match`].filter(Boolean).join(" · "))}</small></span>
            <span class="nexora-result-select">Select</span>
          </button>`).join("");
        viewAll.hidden = showAll || allOptions.length <= 3;
        tabs.hidden = !showAll;
        if (showAll) tabs.querySelectorAll("button").forEach(btn => btn.classList.toggle("active", btn.dataset.tab === "all"));
      };

      const search = async () => {
        const query = input.value.trim();
        if (query.length < 2) { status.textContent = "Enter at least 2 characters."; input.focus(); return; }
        const current = ++requestId;
        searchButton.disabled = true;
        status.textContent = "Searching…";
        results.innerHTML = "";
        viewAll.hidden = true;
        tabs.hidden = true;
        const outcome = await api.orbitSearch(pendingId, query, current);
        if (current !== requestId || outcome?.status === "superseded") return;
        searchButton.disabled = false;
        if (outcome?.status !== "done") {
          status.textContent = outcome?.message || "Search failed. Try another name.";
          return;
        }
        latestRequestId = outcome.requestId;
        allOptions = Array.isArray(outcome.options) ? outcome.options : [];
        status.textContent = outcome.message || (allOptions.length ? `${allOptions.length} result${allOptions.length === 1 ? "" : "s"} found. Select the correct game.` : "No matching game found.");
        renderOptions(false);
      };

      searchButton.addEventListener("click", () => void search());
      input.addEventListener("keydown", event => { if (event.key === "Enter") { event.preventDefault(); void search(); } });
      overlayEl.querySelector(".nexora-add-close").addEventListener("click", () => void closeDialog(true));
      overlayEl.addEventListener("click", event => { if (event.target === overlayEl) void closeDialog(true); });
      viewAll.addEventListener("click", () => renderOptions(true));
      tabs.addEventListener("click", event => {
        const tab = event.target.closest("button[data-tab]");
        if (!tab) return;
        if (tab.dataset.tab === "best") { tabs.hidden = true; renderOptions(false); }
        else renderOptions(true);
      });

      removeProgress = api.onOrbitProgress?.(update => {
        if (!update || update.pendingId !== pendingId) return;
        const stageText = { details: "Downloading game details", cover: "Downloading artwork", screenshots: "Downloading screenshots", saving: "Saving to Library" }[update.stage] || "Adding game";
        progressDetail.textContent = update.detail || stageText;
        const pct = { details: 25, cover: 50, screenshots: 72, saving: 90 }[update.stage] || 12;
        progressBar.style.width = `${pct}%`;
      });

      results.addEventListener("click", async event => {
        const row = event.target.closest(".nexora-game-result[data-option-index]");
        if (!row || latestRequestId < 0) return;
        const index = Number(row.dataset.optionIndex);
        dialog.classList.add("is-loading");
        input.disabled = true; searchButton.disabled = true; results.style.display = "none"; viewAll.hidden = true; tabs.hidden = true;
        progress.hidden = false; progressBar.style.width = "10%"; status.textContent = "";
        try {
          const selected = await api.orbitChoose(pendingId, latestRequestId, index);
          if (selected?.status !== "accepted") throw new Error(selected?.reasons?.[0] || "Could not add the selected game.");
          progressBar.style.width = "100%";
          progressDetail.textContent = "Added to Library";
          pendingId = null;
          await refreshLibraryScreen();
          showToast(`Added: ${selected.game?.metadata?.title || selected.game?.name || "game"}`);
          setTimeout(() => void closeDialog(false), 450);
        } catch (error) {
          dialog.classList.remove("is-loading"); input.disabled = false; searchButton.disabled = false; results.style.display = "grid"; progress.hidden = true;
          status.textContent = error?.message || "Could not add the game.";
          renderOptions(false);
        }
      });

      input.focus();
      input.select();
    } catch (err) {
      await closeDialog(true);
      showToast(err?.message || "Add Game failed.");
    }
  }

  function enterConsole() {
    clearTimeout(switchTimer);
    closeConsolePanel();
    desktop.style.display = "flex";
    desktop.classList.remove("mode-return");
    desktop.classList.add("mode-leave");
    consoleUI.classList.remove("mode-exit");
    consoleUI.classList.add("active");
    consoleUI.setAttribute("aria-hidden", "false");
    app.classList.remove("desktop-mode");
    app.classList.add("console-mode");
    toConsole?.setAttribute("aria-pressed", "true");
    toast.classList.remove("show");
    switchTimer = setTimeout(() => {
      desktop.style.display = "none";
      desktop.classList.remove("mode-leave");
    }, 180);
  }

  function enterDesktop() {
    clearTimeout(switchTimer);
    closeConsolePanel();
    consoleUI.classList.remove("mode-exit");
    consoleUI.classList.remove("active");
    consoleUI.setAttribute("aria-hidden", "true");
    desktop.style.display = "flex";
    desktop.classList.remove("mode-leave");
    desktop.classList.add("mode-return");
    app.classList.remove("console-mode");
    app.classList.add("desktop-mode");
    toConsole?.setAttribute("aria-pressed", "false");
    toast.classList.remove("show");
    switchTimer = setTimeout(() => desktop.classList.remove("mode-return"), 220);
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }

  function accentSwatchHTML(prefix = "desktop") {
    const current = window.NEXORASettingsStore.get("accent") || "cyan";
    return `<div class="accent-choices" role="group" aria-label="Accent color">${["cyan","blue","violet","amber","emerald","rose"].map(key =>
      `<button type="button" class="accent-${key}${key === current ? " selected-accent" : ""}" data-setting-accent="${key}" aria-label="${ACCENTS[key].name}" aria-pressed="${key === current}" title="${ACCENTS[key].name}"><span class="sr-only">${ACCENTS[key].name}</span></button>`
    ).join("")}</div>`;
  }

  function settingControlMarkup(field, prefix) {
    const store = window.NEXORASettingsStore;
    const value = store.get(field.key);
    const key = escapeHTML(field.key);
    const label = escapeHTML(field.label);
    const id = `setting-${prefix}-${key.replace(/[^a-z0-9_-]/gi, "-")}`;
    if (field.type === "accent") return accentSwatchHTML(prefix);
    if (field.type === "toggle") {
      const enabled = value === true;
      return `<button type="button" class="mock-toggle setting-toggle${prefix === "console" ? " console-setting-toggle" : ""}${enabled ? " enabled" : ""}" data-setting-key="${key}" role="switch" aria-checked="${enabled}" aria-label="${label}" title="${label}"></button>`;
    }
    if (field.type === "select") {
      const choices = field.options.map(option => `<option value="${escapeHTML(option.value)}"${String(option.value) === String(value) ? " selected" : ""}>${escapeHTML(option.label)}</option>`).join("");
      return `<select id="${id}" class="setting-select${prefix === "console" ? " console-setting-select" : ""}" data-setting-key="${key}" aria-label="${label}">${choices}</select>`;
    }
    if (field.type === "text") {
      return `<input id="${id}" class="setting-input" type="text" maxlength="${field.maxLength || 40}" data-setting-key="${key}" value="${escapeHTML(value)}" aria-label="${label}" autocomplete="off" spellcheck="false">`;
    }
    if (field.type === "range") {
      return `<div class="setting-range"><input id="${id}" type="range" min="${field.min}" max="${field.max}" step="${field.step}" value="${Number(value)}" data-setting-key="${key}" aria-label="${label}"><output for="${id}" data-range-output="${key}">${Number(value)} ${escapeHTML(field.unit || "")}</output></div>`;
    }
    if (field.type === "action") {
      return `<button type="button" class="setting-action-button" data-setting-action="${escapeHTML(field.action)}">${escapeHTML(field.actionLabel || "Open")}</button>`;
    }
    if (field.type === "info") {
      return `<span class="setting-value-badge">${escapeHTML(field.value || "Not available")}</span>`;
    }
    return "";
  }

  function rowMarkup(field, prefix = "console") {
    const key = escapeHTML(field.key || "info");
    const label = escapeHTML(field.label);
    const description = escapeHTML(field.description || "");
    const control = settingControlMarkup(field, prefix);
    const typeClass = field.type ? ` setting-type-${field.type}` : "";
    const nativeNote = field.native ? `<small class="setting-integration-note">Windows integration pending</small>` : "";
    return `<div class="console-setting-row setting-line settings-field${typeClass}" data-setting-row="${key}"><span class="setting-copy"><b>${label}</b><small>${description}</small>${nativeNote}</span><span class="setting-control">${control}</span></div>`;
  }

  function settingsToolsMarkup(prefix) {
    return `<div class="settings-tools" role="group" aria-label="Settings file and reset actions"><div class="settings-save-status" data-settings-status><span class="status-dot"></span><span>${escapeHTML(window.NEXORASettingsStore.statusLabel())}</span></div><div class="settings-tool-actions"><button type="button" data-setting-action="export">Export JSON</button><button type="button" data-setting-action="import">Import JSON</button><button type="button" class="settings-reset-action" data-setting-action="reset">Reset defaults</button></div><input class="settings-import-file" type="file" accept="application/json,.json" aria-label="Import NEXORA settings file" hidden></div>`;
  }

  function settingsRuntimeNote() {
    return `<p class="settings-runtime-note">Preferences autosave as you change them. Theme, accent, reduced motion and startup mode apply in this UI. Windows tray/startup, networking, updater and live-stream options are saved for their native services to consume when those systems are connected.</p>`;
  }

  function renderSettingsSection(section) {
    activeSettings = settingsSections[section] ? section : "Appearance";
    const data = settingsSections[activeSettings];
    overlayTitle.textContent = "Settings";
    const rows = data.rows.map(field => rowMarkup(field, "console")).join("");
    const statusCard = activeSettings === "Appearance" ? `<article class="settings-info-card"><div><span class="eyebrow-small">SETTINGS ENGINE</span><h4>Preferences are saved automatically</h4><p>Changes persist on this device and are shared by Desktop and Console Mode. Native Windows and streaming actions remain separate integrations.</p></div><div class="settings-info-meta"><span>STORAGE</span><b data-settings-storage>${escapeHTML(window.NEXORASettingsStore.statusLabel())}</b><span>CONFIG VERSION</span><b>1 · Migratable</b></div></article>` : "";
    overlayContent.innerHTML = `<div class="console-settings-layout"><nav class="console-settings-nav" aria-label="Console settings">${Object.keys(settingsSections).map(name => `<button type="button" data-settings-tab="${escapeHTML(name)}" class="${name === activeSettings ? "active" : ""}" aria-current="${name === activeSettings ? "page" : "false"}"><svg aria-hidden="true"><use href="#${name === "Network" ? "i-network" : name === "Streaming" ? "i-stream" : name === "Updates" ? "i-download" : name === "Privacy & security" ? "i-shield" : name === "General" ? "i-sliders" : "i-monitor"}"/></svg>${escapeHTML(name)}</button>`).join("")}</nav><div class="console-settings-content"><span class="eyebrow-small">${escapeHTML(data.kicker)}</span><h3>${escapeHTML(data.title)}</h3><p>${escapeHTML(data.desc)}</p><div class="settings-fields">${rows}</div>${settingsRuntimeNote()}${settingsToolsMarkup("console")}${statusCard}</div></div>`;
  }

  function renderDesktopSettings(section) {
    activeDesktopSettings = settingsSections[section] ? section : "Appearance";
    const data = settingsSections[activeDesktopSettings];
    document.querySelectorAll(".settings-nav button").forEach(button => {
      button.classList.toggle("active", button.dataset.desktopSetting === activeDesktopSettings);
      if (button.dataset.desktopSetting === activeDesktopSettings) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
    const target = document.querySelector(".settings-content");
    if (!target) return;
    const rows = data.rows.map(field => rowMarkup(field, "desktop")).join("");
    const statusCard = activeDesktopSettings === "Appearance" ? `<article class="panel glass setting-card settings-info-card"><div class="settings-info-main"><div class="panel-head"><div><span class="eyebrow-small">SETTINGS ENGINE</span><h3>Preferences & storage</h3></div><span class="tiny-tag">AUTOSAVE</span></div><p>Settings are validated, versioned, and saved as you change them. Import/export makes your profile portable. Desktop-specific actions will activate when the native Windows services are wired in.</p><div class="connection-stats settings-system-stats"><div><span>APP PACKAGE</span><b>1.2.0 · NEXORA Host</b></div><div><span>STORAGE</span><b data-settings-storage>${escapeHTML(window.NEXORASettingsStore.statusLabel())}</b></div><div><span>NATIVE SERVICES</span><b>Host services</b></div></div></div></article>` : "";
    target.innerHTML = `<article class="panel glass setting-card"><div class="panel-head"><div><span class="eyebrow-small">${escapeHTML(data.kicker)}</span><h3>${escapeHTML(data.title)}</h3></div><span class="tiny-tag">${activeDesktopSettings === "Appearance" ? "PREFERENCES" : "AUTOSAVE"}</span></div><div class="settings-fields">${rows}</div>${settingsRuntimeNote()}</article>${statusCard}${settingsToolsMarkup("desktop")}`;
    refreshSettingsStatus();
  }

  function refreshSettingsStatus() {
    const store = window.NEXORASettingsStore;
    document.querySelectorAll("[data-settings-status]").forEach(node => {
      const span = node.querySelector("span:last-child");
      if (span) span.textContent = store.statusLabel();
      node.classList.toggle("storage-warning", store.backend === "memory");
      node.title = store.lastError || "NEXORA preferences save automatically.";
    });
    document.querySelectorAll("[data-settings-storage]").forEach(node => node.textContent = store.statusLabel());
  }

  function updateProfileName() {
    const name = window.NEXORASettingsStore.get("profileName") || "NEXORA User";
    const topName = document.querySelector(".top-user b");
    const avatar = document.querySelector(".top-avatar");
    if (topName) topName.textContent = name;
    if (avatar) avatar.textContent = (Array.from(name.trim())[0] || "N").toLocaleUpperCase();
  }

  function qualityIndexFromSettings() {
    const resolution = window.NEXORASettingsStore.get("resolution");
    const frameRate = window.NEXORASettingsStore.get("frameRate");
    const label = `${resolution} · ${frameRate} fps`;
    const exact = qualityChoices.indexOf(label);
    if (exact >= 0) return exact;
    const fallback = qualityChoices.findIndex(item => item.startsWith(`${resolution} ·`));
    return fallback >= 0 ? fallback : 2;
  }

  function updateQualityLabel() {
    selectedQuality = qualityIndexFromSettings();
    const label = document.getElementById("console-quality-label");
    if (label) label.textContent = qualityChoices[selectedQuality];
    document.querySelectorAll(".quality-option").forEach(option => {
      const title = option.querySelector("b")?.textContent.trim() || "";
      const resolution = title === "4K" ? "2160p" : title;
      const frameText = option.querySelector("small")?.textContent || "";
      const matchesFps = frameText.includes("30–60") ? window.NEXORASettingsStore.get("frameRate") === "60" : frameText.includes(`${window.NEXORASettingsStore.get("frameRate")} frames/sec`);
      option.classList.toggle("selected", resolution === window.NEXORASettingsStore.get("resolution") && matchesFps);
    });
  }

  function applyTheme(theme) {
    document.documentElement.dataset.theme = ["midnight", "obsidian", "earth"].includes(theme) ? theme : "midnight";
  }

  function applyReducedMotion(enabled) {
    document.documentElement.classList.toggle("reduced-motion", enabled === true);
  }

  function applyStoredSettings() {
    const store = window.NEXORASettingsStore;
    applyTheme(store.get("theme"));
    applyAccent(store.get("accent"), false);
    applyReducedMotion(store.get("reducedMotion"));
    updateProfileName();
    updateQualityLabel();
    refreshSettingsStatus();
  }

  async function commitSetting(key, value, options = {}) {
    const store = window.NEXORASettingsStore;
    const result = await store.set(key, value);
    applyStoredSettings();
    if (key === "profileName") {
      document.querySelectorAll('[data-setting-key="profileName"]').forEach(input => {
        if (document.activeElement !== input) input.value = store.get("profileName");
      });
    }
    if (options.render) {
      renderDesktopSettings(activeDesktopSettings);
      if (overlay && !overlay.hasAttribute("hidden")) renderSettingsSection(activeSettings);
    }
    if (options.silent) return result;
    if (!result.ok && result.backup) {
      showToast("App storage unavailable — a browser backup was saved");
    } else if (!result.ok || store.backend === "memory") {
      showToast("Storage unavailable — changes apply for this session only");
    } else if (key === "desktopModeOnStartup") {
      showToast(`Startup mode saved: ${store.get(key) ? "Desktop" : "Console"}`);
    } else if (key === "startWithWindows" || key === "minimizeToTray") {
      showToast("Preference saved; Windows shell integration is not connected yet");
    } else if (["connectionMode", "relayFallback", "pairingCodeLifetime", "resolution", "frameRate", "bitrateMbps", "encoder", "audioCapture", "adaptiveQuality", "requireDeviceApproval", "encryptSessions", "diagnosticLogging", "shareCrashReports", "updateChannel", "automaticUpdateChecks"].includes(key)) {
      showToast("Preference saved locally; its native service is not connected in this package");
    } else {
      showToast("Preference saved on this device");
    }
    return result;
  }

  function downloadSettings() {
    const payload = window.NEXORASettingsStore.exportPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `nexora-settings-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.style.display = "none";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast("Settings exported as a JSON backup");
  }

  async function handleSettingsImport(input) {
    const file = input.files && input.files[0];
    if (!file) return;
    try {
      if (file.size > 1024 * 1024) throw new Error("Settings file must be smaller than 1 MB.");
      const payload = JSON.parse(await file.text());
      if (!payload || payload.app !== "NEXORA" || payload.schemaVersion !== 1 || !payload.settings || typeof payload.settings !== "object" || Array.isArray(payload.settings)) {
        throw new Error("This is not a supported NEXORA settings backup.");
      }
      if (!confirm("Import these NEXORA settings? Your current preferences will be replaced.")) return;
      const result = await window.NEXORASettingsStore.replace(payload.settings);
      if (!result.ok && !result.backup && window.NEXORASettingsStore.backend === "memory") throw new Error("Settings were loaded for this session but could not be saved.");
      applyStoredSettings();
      renderDesktopSettings(activeDesktopSettings);
      if (overlay && !overlay.hasAttribute("hidden")) renderSettingsSection(activeSettings);
      showToast(!result.ok && result.backup ? "Imported; browser backup saved because app storage failed" : "Settings imported and validated");
    } catch (error) {
      showToast(error && error.message ? error.message : "Could not import the settings file");
    } finally {
      input.value = "";
    }
  }

  async function handleSettingsAction(button) {
    const action = button.dataset.settingAction;
    if (action === "export") {
      downloadSettings();
    } else if (action === "import") {
      const input = button.closest(".settings-tools")?.querySelector(".settings-import-file");
      input?.click();
    } else if (action === "reset") {
      if (!confirm("Reset every NEXORA preference to its default? This cannot be undone unless you exported a backup.")) return;
      const result = await window.NEXORASettingsStore.reset();
      applyStoredSettings();
      renderDesktopSettings(activeDesktopSettings);
      if (overlay && !overlay.hasAttribute("hidden")) renderSettingsSection(activeSettings);
      showToast(result.ok ? "All settings reset to defaults" : result.backup ? "Defaults saved to browser backup; app storage unavailable" : "Defaults restored for this session; storage is unavailable");
    } else if (action === "check-updates") {
      showToast("Updater is not connected in this UI package; no network request was made");
    }
  }

  function usableGameRatings(game) {
    return (Array.isArray(game?.metadata?.ratings) ? game.metadata.ratings : []).filter(r => {
      const display = String(r?.display || "").trim();
      const score = Number(r?.score), outOf = Number(r?.outOf);
      if (/^0(?:\.0+)?%?$/.test(display)) return false;
      if (Number.isFinite(score) && Number.isFinite(outOf) && outOf > 0 && score <= 0) return false;
      return Boolean(display || (Number.isFinite(score) && Number.isFinite(outOf) && outOf > 0));
    });
  }

  function openConsoleGameDetails(gameId) {
    const game = currentGames.find(g => g.id === gameId) || selectedGame;
    if (!game || !overlay || !overlayContent || !overlayTitle) return;
    selectedGame = game;
    const meta = game.metadata || {};
    const hero = gameHero(game), cover = gameCover(game);
    const screenshots = Array.isArray(meta.screenshots) ? meta.screenshots.slice(0,6) : [];
    const genres = Array.isArray(meta.genres) ? meta.genres.slice(0,4) : [];
    const req = meta.requirements || {};
    const ratings = usableGameRatings(game);
    const ratingRows = ratings.length ? `<section class="console-detail-section"><span class="eyebrow-small">REVIEWS</span><div class="console-detail-reviews">${ratings.slice(0,4).map(r=>`<div class="nexora-review-row ${ratingTone(r)}">${reviewLogo(r)}<span><b>${escapeHTML(r.source||"Rating")}</b><small>${escapeHTML(r.display||"")}</small></span><i></i></div>`).join("")}</div></section>` : "";
    const reqMarkup = (req.minimum || req.recommended) ? `<section class="console-detail-section"><span class="eyebrow-small">PC REQUIREMENTS</span><div class="console-detail-req-grid">${req.minimum ? requirementCard("MINIMUM", req.minimum) : ""}${req.recommended ? requirementCard("RECOMMENDED", req.recommended) : ""}</div></section>` : "";
    overlay.removeAttribute("hidden"); overlay.setAttribute("aria-hidden","false"); requestAnimationFrame(()=>overlay.classList.add("open"));
    overlayTitle.textContent = "Game details";
    overlayContent.innerHTML = `<article class="console-full-game-detail">
      <div class="console-detail-hero"${hero ? ` style="--console-detail-hero:url('${escapeHTML(hero)}')"` : ""}><div class="console-detail-hero-image"></div><div class="console-detail-hero-shade"></div><div class="console-detail-hero-copy"><span class="eyebrow-small">YOUR LIBRARY · WINDOWS PC</span><h2>${escapeHTML(gameTitle(game))}</h2><div class="console-detail-meta"><span>${escapeHTML(gameDeveloper(game))}</span>${meta.releaseDate?`<span>${escapeHTML(formatRelease(meta.releaseDate))}</span>`:""}${genres.length?`<span>${escapeHTML(genres.join(" · "))}</span>`:""}</div><div class="console-detail-actions"><button class="console-action-button primary" type="button" data-game-launch="${escapeHTML(game.id)}"><svg><use href="#i-play"/></svg> Play</button><button class="console-action-button" type="button" data-console-close>Back</button></div></div>${cover?`<img class="console-detail-cover" src="${escapeHTML(cover)}" alt="">`:""}</div>
      <section class="console-detail-section console-detail-about"><span class="eyebrow-small">ABOUT THIS GAME</span><p>${escapeHTML(meta.description || meta.shortDescription || "Game information is not available yet.")}</p></section>
      ${ratingRows}
      ${screenshots.length?`<section class="console-detail-section"><span class="eyebrow-small">SCREENSHOTS</span><div class="console-detail-shots">${screenshots.map((src,i)=>`<img src="${escapeHTML(src)}" alt="${escapeHTML(gameTitle(game))} screenshot ${i+1}" loading="lazy">`).join("")}</div></section>`:""}
      ${reqMarkup}
    </article>`;
  }

  function openConsolePanel(kind) {
    if (!overlay) return;
    overlay.removeAttribute("hidden");
    overlay.setAttribute("aria-hidden", "false");
    requestAnimationFrame(() => overlay.classList.add("open"));
    if (kind === "settings") {
      renderSettingsSection(activeSettings);
      return;
    }
    if (kind === "updates") {
      overlayTitle.textContent = "Updates";
      overlayContent.innerHTML = `<div class="console-update-card"><span class="update-symbol"><svg><use href="#i-download"/></svg></span><div class="console-update-copy"><b>NEXORA is up to date</b><small>Prototype build 1.3.0 · update checks are not connected.</small></div><button class="console-action-button primary" type="button" data-demo-action="update">Check again</button></div><p class="preview-note">No update manifest is contacted and no files are downloaded or changed.</p>`;
      return;
    }
    if (kind === "quality") {
      overlayTitle.textContent = "Stream quality";
      overlayContent.innerHTML = `<div class="console-settings-content"><h3>Choose a picture profile</h3><p>Pick a quality preset for the visual preview. This does not change a real encoder.</p><div class="console-quality-options">${qualityChoices.map((label,index) => `<button type="button" class="${index === selectedQuality ? "active" : ""}" data-quality-choice="${index}"><b>${label.split(" · ")[0]}</b><small>${label.split(" · ")[1]} · preview</small></button>`).join("")}</div><p class="preview-note">Your choice is saved as the default stream profile. Saved as your default stream profile for when capture is connected.</p></div>`;
      return;
    }
    if (kind === "stream") {
      overlayTitle.textContent = "Remote play";
      overlayContent.innerHTML = `<div class="console-stream-card"><div class="console-stream-head"><i class="status-dot"></i><div><b>Host ready · no active stream</b><p>Connect a receiver to start a session. Pair a receiver when networking is enabled.</p></div></div><div class="console-stream-details"><div><small>HOST COMPUTER</small><b>ORION-DESKTOP</b></div><div><small>RECEIVER</small><b>Not connected</b></div><div><small>PAIRING PIN</small><b>482 731 · sample</b></div></div><button class="console-action-button primary" type="button" data-demo-action="pair">Pair a receiver</button><p class="preview-note">Pairing and session transport activate when networking is enabled.</p></div>`;
      return;
    }
    if (kind === "details") {
      if (!selectedGame) {
        overlayTitle.textContent = "Game details";
        overlayContent.innerHTML = `<div class="console-empty-panel"><h3>No game selected</h3><p>Your library is empty. Use Add a Game to choose a Windows executable.</p></div>`;
        return;
      }
      openConsoleGameDetails(selectedGame.id);
      return;
    }
    renderSettingsSection("Appearance");
  }

  function closeConsolePanel() {
    if (!overlay) return;
    overlay.classList.remove("open");
    overlay.setAttribute("aria-hidden", "true");
    overlay.setAttribute("hidden", "");
  }

  function selectConsoleGame(button) {
    const id = button.dataset.game;
    const game = currentGames.find(g => g.id === id);
    if (!game) return;
    selectedGame = game;
    renderConsoleLibrary(currentGames);
    requestAnimationFrame(() => document.querySelector('.console-feature .console-view')?.focus({preventScroll:true}));
  }

  function moveConsoleSelection(delta) {
    if (!currentGames.length) return;
    const index = Math.max(0, currentGames.findIndex(g=>g.id===selectedGame?.id));
    const next = currentGames[(index + delta + currentGames.length) % currentGames.length];
    selectedGame = next;
    renderConsoleLibrary(currentGames);
    requestAnimationFrame(() => document.querySelector('.console-feature .console-view')?.focus({preventScroll:true}));
  }

  async function launchGame(gameId) {
    const game = currentGames.find(g=>g.id===gameId);
    if (!game || !window.nexora?.launchGame) { showToast("Game launch is unavailable."); return; }
    try {
      const updated = await window.nexora.launchGame(gameId);
      if (updated) {
        const i=currentGames.findIndex(g=>g.id===gameId); if(i>=0) currentGames[i]=updated;
        selectedGame = updated;
        renderHomeLibrary(currentGames); renderConsoleLibrary(currentGames);
      }
      showToast(`${gameTitle(game)} launched`);
    } catch (e) { showToast(e?.message || "Could not launch this game."); }
  }

  function updateQuality(step) {
    selectedQuality = (selectedQuality + step + qualityChoices.length) % qualityChoices.length;
    const [resolution, fps] = qualityChoices[selectedQuality].split(" · ");
    const frameRate = String(parseInt(fps, 10) || 60);
    Promise.all([commitSetting("resolution", resolution, { silent: true }), commitSetting("frameRate", frameRate, { silent: true })]).then(() => {
      const label = document.getElementById("console-quality-label");
      if (label) label.textContent = qualityChoices[selectedQuality];
      showToast(`Default quality saved: ${qualityChoices[selectedQuality]}`);
    });
  }

  toConsole?.addEventListener("click", enterConsole);
  toDesktop?.addEventListener("click", enterDesktop);
  document.addEventListener("click", event => {
    const emptyAddAction = event.target.closest("[data-preview-empty-add]");
    if (emptyAddAction) {
      void handleAddGame();
      return;
    }
    const launchButton = event.target.closest("[data-game-launch]");
    if (launchButton) {
      void launchGame(launchButton.dataset.gameLaunch);
      return;
    }
    const removeGame = event.target.closest("[data-remove-game]");
    if (removeGame) {
      const id = removeGame.dataset.removeGame;
      const game = currentGames.find(g => g.id === id);
      if (!game) return;
      if (!confirm(`Remove ${gameTitle(game)} from your NEXORA library? The game files on disk will not be deleted.`)) return;
      const previousGames = currentGames.slice();
      currentGames = currentGames.filter(g => g.id !== id);
      selectedGame = null;
      renderHomeLibrary(currentGames);
      renderConsoleLibrary(currentGames);
      const grid = document.querySelector("#page-library .library-grid");
      const count = document.querySelector("#page-library .tab-strip button:first-child span");
      if (count) count.textContent = String(currentGames.length);
      if (grid) {
        if (currentGames.length) {
          grid.classList.remove("empty-library-grid");
          grid.innerHTML = currentGames.map(item => `<button type="button" class="nexora-library-card panel glass" data-game-open="${escapeHTML(item.id)}">${gameCover(item)?`<img src="${escapeHTML(gameCover(item))}" alt="">`:`<div class="nexora-game-placeholder">N</div>`}<div class="nexora-library-card-copy"><b>${escapeHTML(gameTitle(item))}</b><small>${escapeHTML(gameDeveloper(item))}</small><span>${escapeHTML(item.metadata?.releaseDate || "Windows PC")}</span></div></button>`).join("");
        } else {
          grid.classList.add("empty-library-grid");
          grid.innerHTML = `<article class="library-empty-state panel glass" role="status"><span class="empty-games-icon"><svg><use href="#i-library"/></svg></span><h2>No games added yet</h2><p>Your game collection will appear here. Click Add a Game to choose a Windows .exe on this PC.</p><button class="primary-action" type="button" data-preview-empty-add><svg><use href="#i-plus"/></svg> Add a Game</button></article>`;
        }
      }
      showPage("library");
      showToast("Game removed from library");
      Promise.resolve(window.nexora?.removeGame?.(id)).then(async ok => {
        if (ok === false) throw new Error("Could not remove the game.");
        await refreshLibraryScreen();
      }).catch(error => {
        currentGames = previousGames;
        renderHomeLibrary(currentGames);
        renderConsoleLibrary(currentGames);
        void refreshLibraryScreen();
        showToast(error?.message || "Could not remove the game.");
      });
      return;
    }
    const consoleGameDetails = event.target.closest("[data-console-game-details]");
    if (consoleGameDetails) {
      event.preventDefault(); event.stopPropagation();
      const id = consoleGameDetails.dataset.consoleGameDetails || selectedGame?.id;
      if (id) openConsoleGameDetails(id);
      return;
    }
    const gameOpen = event.target.closest("[data-game-open]");
    if (gameOpen) {
      event.preventDefault();
      event.stopPropagation();
      const targetGameId = gameOpen.dataset.gameOpen;
      if (targetGameId) {
        if (consoleUI.classList.contains("active")) enterDesktop();
        setTimeout(() => openGameDetails(targetGameId), 0);
      }
      return;
    }
    const pageButton = event.target.closest(".nav-item[data-page], [data-goto], .settings-shortcuts [data-page]");
    if (pageButton) {
      showPage(pageButton.dataset.page || pageButton.dataset.goto);
      if (pageButton.classList.contains("sidebar-anywhere")) showToast("Your games are ready to browse");
      return;
    }
    const pageAction = event.target.closest("[data-page]");
    if (pageAction && pageNames[pageAction.dataset.page]) {
      showPage(pageAction.dataset.page);
      return;
    }
    const consoleAction = event.target.closest("[data-console-panel]");
    if (consoleAction) {
      openConsolePanel(consoleAction.dataset.consolePanel);
      return;
    }
    const qualityStep = event.target.closest("[data-quality-step]");
    if (qualityStep) {
      updateQuality(Number(qualityStep.dataset.qualityStep));
      return;
    }
    const cover = event.target.closest(".console-cover[data-game]");
    if (cover) {
      selectConsoleGame(cover);
      return;
    }
    const closeButton = event.target.closest("[data-console-close]");
    if (closeButton) {
      closeConsolePanel();
      return;
    }
    const settingsAction = event.target.closest("[data-setting-action]");
    if (settingsAction) {
      handleSettingsAction(settingsAction);
      return;
    }
    const settingSwitch = event.target.closest('button[data-setting-key][role="switch"]');
    if (settingSwitch) {
      const key = settingSwitch.dataset.settingKey;
      const enabled = settingSwitch.getAttribute("aria-checked") !== "true";
      settingSwitch.classList.toggle("enabled", enabled);
      settingSwitch.setAttribute("aria-checked", String(enabled));
      document.querySelectorAll(`[data-setting-key="${key}"][role="switch"]`).forEach(peer => {
        peer.classList.toggle("enabled", enabled);
        peer.setAttribute("aria-checked", String(enabled));
      });
      commitSetting(key, enabled);
      return;
    }
    const settingAccent = event.target.closest("[data-setting-accent]");
    if (settingAccent) {
      commitSetting("accent", settingAccent.dataset.settingAccent);
      return;
    }
    const settingsTab = event.target.closest("[data-settings-tab]");
    if (settingsTab) {
      renderSettingsSection(settingsTab.dataset.settingsTab);
      return;
    }
    const qualityChoice = event.target.closest("[data-quality-choice]");
    if (qualityChoice) {
      selectedQuality = Number(qualityChoice.dataset.qualityChoice);
      document.querySelectorAll("[data-quality-choice]").forEach(button => button.classList.toggle("active", button === qualityChoice));
      const [resolution, fps] = qualityChoices[selectedQuality].split(" · ");
      const frameRate = String(parseInt(fps, 10) || 60);
      Promise.all([commitSetting("resolution", resolution, { silent: true }), commitSetting("frameRate", frameRate, { silent: true })]).then(() => {
        const label = document.getElementById("console-quality-label");
        if (label) label.textContent = qualityChoices[selectedQuality];
        showToast(`Default quality saved: ${qualityChoices[selectedQuality]}`);
      });
      return;
    }
    const desktopSetting = event.target.closest("[data-desktop-setting]");
    if (desktopSetting) {
      renderDesktopSettings(desktopSetting.dataset.desktopSetting);
      return;
    }
    const demoAction = event.target.closest("[data-demo-action]");
    if (demoAction) {
      const messages = {update:"Update check is not configured yet.",pair:"Pairing will be available when Remote Play networking is enabled.",launch:"Game launch is not enabled yet (Phase 3)."};
      showToast(messages[demoAction.dataset.demoAction] || "Preview only");
      return;
    }
    const collapse = event.target.closest(".collapse-quick");
    if (collapse) {
      const quickCard = collapse.closest(".quick-card");
      const actions = quickCard?.querySelectorAll(".quick-action");
      const collapsed = quickCard?.classList.toggle("is-collapsed");
      actions?.forEach(action => action.hidden = Boolean(collapsed));
      collapse.textContent = collapsed ? "⌄" : "⌃";
      return;
    }
    const consolePlay = event.target.closest(".console-play");
    if (consolePlay && selectedGame) {
      void launchGame(selectedGame.id);
      return;
    }
    const consoleView = event.target.closest(".console-view");
    if (consoleView) {
      const id = consoleView.dataset.consoleGameDetails || selectedGame?.id;
      if (id) openConsoleGameDetails(id);
      return;
    }
    const qualityOption = event.target.closest(".quality-option");
    if (qualityOption) {
      qualityOption.parentElement.querySelectorAll(".quality-option").forEach(item => item.classList.toggle("selected", item === qualityOption));
      const resolutionText = qualityOption.querySelector("b")?.textContent.trim() || "1080p";
      const resolution = resolutionText === "4K" ? "2160p" : resolutionText;
      const frameText = qualityOption.querySelector("small")?.textContent || "60 frames/sec";
      const fpsMatch = frameText.includes("30–60") ? [null, "60"] : frameText.match(/(30|60|120)/);
      Promise.all([commitSetting("resolution", resolution, { silent: true }), commitSetting("frameRate", fpsMatch ? fpsMatch[1] : "60", { silent: true })]).then(() => showToast(`Default stream profile saved: ${resolution}`));
      return;
    }
    const layout = event.target.closest(".layout-choice");
    if (layout) {
      layout.parentElement.querySelectorAll(".layout-choice").forEach(item => item.classList.toggle("active", item === layout));
      showToast(`${layout.querySelector("b")?.textContent || "Layout"} selected`);
      return;
    }
    const settingTab = event.target.closest(".settings-nav button");
    if (settingTab) {
      renderDesktopSettings(settingTab.dataset.desktopSetting || settingTab.textContent.trim());
      return;
    }
    const goto = event.target.closest("[data-goto]");
    if (goto) {
      showPage(goto.dataset.goto);
      return;
    }
    const toastAction = event.target.closest("[data-toast]");
    if (toastAction) {
      showToast(toastAction.dataset.toast);
      return;
    }
    const previewAction = event.target.closest(".primary-action,.secondary-action,.outline-button,.tab-strip button,.filter-pill,.sort-pill,.library-card-info button,.range-tabs button,.mock-toggle,.accent-choices i,.window-controls button,.icon-button");
    if (previewAction) {
      if (previewAction.classList.contains("mock-toggle")) previewAction.classList.toggle("enabled");
      if (previewAction.matches(".accent-choices i")) {
        previewAction.parentElement.querySelectorAll("i").forEach(item => item.classList.toggle("selected-accent", item === previewAction));
      }
      if (previewAction.matches(".tab-strip button,.range-tabs button")) {
        previewAction.parentElement.querySelectorAll("button").forEach(item => item.classList.toggle("active", item === previewAction));
      }
      showToast("Preview control changed locally; nothing is saved.");
      event.preventDefault();
    }
  });

  overlay?.addEventListener("click", event => {
    if (event.target === overlay) closeConsolePanel();
  });
  document.addEventListener("wheel", event => {
    const rail = event.target.closest?.(".console-game-rail");
    if (!rail || Math.abs(event.deltaY) <= Math.abs(event.deltaX)) return;
    event.preventDefault();
    rail.scrollBy({ left: event.deltaY * 1.15, behavior: "auto" });
  }, { passive: false });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      if (overlay && !overlay.hasAttribute("hidden")) closeConsolePanel();
      else if (consoleUI.classList.contains("active")) enterDesktop();
    }
    if (consoleUI.classList.contains("active") && (!overlay || overlay.hasAttribute("hidden"))) {
      const key = event.key.toLowerCase();
      if (key === "arrowright" || key === "d") { event.preventDefault(); moveConsoleSelection(1); return; }
      if (key === "arrowleft" || key === "a") { event.preventDefault(); moveConsoleSelection(-1); return; }
      if ((key === "enter" || key === " ") && selectedGame) { event.preventDefault(); void launchGame(selectedGame.id); return; }
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      showToast("Quick find will search your library");
    }
  });

  document.querySelectorAll(".settings-nav button").forEach((button, index) => {
    button.dataset.desktopSetting = Object.keys(settingsSections)[index] || "Appearance";
  });
  document.querySelectorAll(".console-cover").forEach((button,index) => button.setAttribute("aria-pressed",String(index===0)));

  /* ——— Accent color system: updates logo gradients + CSS variables ——— */
  function applyAccent(key, notify = true) {
    const p = ACCENTS[key] || ACCENTS.cyan;
    const root = document.documentElement;
    root.style.setProperty("--accent", p.a);
    root.style.setProperty("--accent-2", p.a2);
    root.style.setProperty("--accent-3", p.a3);
    root.style.setProperty("--accent-glow", p.glow);
    root.style.setProperty("--cyan", p.a);
    root.style.setProperty("--blue", p.a2);
    root.style.setProperty("--violet", p.a3);
    root.dataset.accent = key;

    ["logoGradientDesktop", "logoGradientConsole"].forEach(id => {
      const grad = document.getElementById(id);
      if (!grad) return;
      const stops = grad.querySelectorAll("stop");
      p.stops.forEach((c, i) => { if (stops[i]) stops[i].setAttribute("stop-color", c); });
    });

    const areaStops = document.querySelectorAll("#areaBlue stop");
    if (areaStops[0]) areaStops[0].setAttribute("stop-color", p.a);
    if (areaStops[1]) areaStops[1].setAttribute("stop-color", p.a);
    document.querySelectorAll(".line-chart path[stroke]").forEach(path => {
      path.setAttribute("stroke", p.a);
    });

    document.querySelectorAll(".accent-choices [data-setting-accent]").forEach(el => {
      const selected = el.dataset.settingAccent === key;
      el.classList.toggle("selected-accent", selected);
      el.setAttribute("aria-pressed", String(selected));
    });
    if (notify) showToast(`Accent → ${p.name}`);
  }

  document.addEventListener("change", event => {
    const input = event.target.closest("[data-setting-key]");
    if (input) {
      const field = Object.values(settingsSections).flatMap(section => section.rows).find(row => row.key === input.dataset.settingKey);
      if (!field) return;
      const value = field.type === "range" ? Number(input.value) : input.value;
      commitSetting(field.key, value);
      return;
    }
    const importInput = event.target.closest(".settings-import-file");
    if (importInput) handleSettingsImport(importInput);
  });

  document.addEventListener("input", event => {
    const range = event.target.closest('input[type="range"][data-setting-key]');
    if (range) {
      const output = document.querySelector(`[data-range-output="${range.dataset.settingKey}"]`);
      if (output) output.textContent = `${range.value} Mbps`;
    }
  });

  document.addEventListener("keydown", event => {
    const swatch = event.target.closest("[data-setting-accent]");
    if (swatch && (event.key === "Enter" || event.key === " ")) {
      event.preventDefault();
      commitSetting("accent", swatch.dataset.settingAccent);
    }
  });


  const AI_MODELS = {
    groq: [
      ["openai/gpt-oss-120b", "GPT-OSS 120B"],
      ["openai/gpt-oss-20b", "GPT-OSS 20B"],
      ["qwen/qwen3.8-27b", "Qwen 3.8 27B"],
      ["minimaxai/minimax-m2.7", "MiniMax M2.7"]
    ],
    gemini: [["gemini-2.5-pro", "Gemini 2.5 Pro"], ["gemini-2.5-flash", "Gemini 2.5 Flash"]],
    openrouter: [["openai/gpt-oss-120b", "GPT-OSS 120B"], ["qwen/qwen3.8-27b", "Qwen 3.8 27B"]]
  };
  let aiSettings = null;
  let aiProposal = null;
  let aiSelectedElement = null;
  let aiPickMode = false;
  let aiPickOutline = null;
  let aiPickBanner = null;
  const aiHistory = [];
  function aiEl(id) { return document.getElementById(id); }

  function aiScopeValue() { return aiEl('ai-scope-select')?.value || 'auto'; }
  function aiElementSelector(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let node = el;
    while (node && node !== document.body && parts.length < 5) {
      let part = node.tagName.toLowerCase();
      const classes = [...node.classList].filter(c => !/^active$|^show$|^selected$/.test(c)).slice(0,3);
      if (classes.length) part += '.' + classes.map(c => CSS.escape(c)).join('.');
      if (node.parentElement) {
        const same = [...node.parentElement.children].filter(x => x.tagName === node.tagName);
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(node)+1})`;
      }
      parts.unshift(part);
      node = node.parentElement;
    }
    return parts.join(' > ');
  }
  function renderAiElementTarget() {
    const box = aiEl('ai-element-target');
    const clear = aiEl('ai-element-clear');
    if (!box) return;
    if (!aiSelectedElement) {
      box.hidden = true; box.innerHTML = ''; if (clear) clear.hidden = true; return;
    }
    box.hidden = false; if (clear) clear.hidden = false;
    box.innerHTML = `<span class="eyebrow-small">SELECTED UI TARGET</span><b>${escapeHTML(aiSelectedElement.selector || aiSelectedElement.tag || 'Element')}</b><small>${escapeHTML((aiSelectedElement.text || '').slice(0,140) || 'No visible text')}</small>`;
  }
  function stopAiElementPicker() {
    aiPickMode = false;
    document.body.classList.remove('ai-element-pick-active');
    aiPickOutline?.remove(); aiPickBanner?.remove(); aiPickOutline = null; aiPickBanner = null;
  }
  function startAiElementPicker() {
    stopAiElementPicker();
    const scope = aiScopeValue();
    if (scope === 'home') showPage('dashboard');
    else if (scope === 'library') showPage('library');
    else if (scope === 'details' && selectedGame) openGameDetails(selectedGame.id);
    else if (scope === 'console') enterConsole();
    else if (scope === 'controls') showPage('controls');
    else if (scope === 'settings') showPage('settings');
    aiPickMode = true;
    document.body.classList.add('ai-element-pick-active');
    aiPickOutline = document.createElement('div'); aiPickOutline.className='ai-pick-outline'; document.body.appendChild(aiPickOutline);
    aiPickBanner = document.createElement('div'); aiPickBanner.className='ai-pick-banner'; aiPickBanner.innerHTML='<b>Select the part of NEXORA you want changed</b><span>Move over an element and click it · Esc cancels</span>'; document.body.appendChild(aiPickBanner);
  }
  function captureAiElement(el) {
    const rect = el.getBoundingClientRect();
    aiSelectedElement = {
      page: consoleUI.classList.contains('active') ? 'console' : (document.querySelector('.page-view.active')?.dataset.view || 'unknown'),
      tag: el.tagName.toLowerCase(),
      id: el.id || '',
      classes: [...el.classList].slice(0,10),
      selector: aiElementSelector(el),
      text: (el.innerText || el.textContent || '').trim().replace(/\s+/g,' ').slice(0,500),
      html: el.outerHTML.slice(0,5000),
      rect: {x:Math.round(rect.x),y:Math.round(rect.y),width:Math.round(rect.width),height:Math.round(rect.height)}
    };
    stopAiElementPicker();
    renderAiElementTarget();
    showPage('patcher');
    requestAnimationFrame(()=>{ aiEl('ai-chat-input')?.focus(); aiEl('ai-element-target')?.scrollIntoView({block:'nearest'}); });
    showToast('Selected context attached to NEXORA Engineer');
  }
  function fillAiModels(provider, selected) {
    const select = aiEl('ai-model-select'); if (!select) return;
    const models = AI_MODELS[provider] || [];
    select.innerHTML = models.map(([id,label])=>`<option value="${escapeHTML(id)}">${escapeHTML(label)} · ${escapeHTML(id)}</option>`).join('');
    if (selected && !models.some(([id])=>id===selected)) select.insertAdjacentHTML('beforeend', `<option value="${escapeHTML(selected)}">${escapeHTML(selected)}</option>`);
    if (selected) select.value = selected;
  }
  async function refreshAiPatcherUi() {
    if (!window.nexora?.getAiPatcherSettings) return;
    try {
      aiSettings = await window.nexora.getAiPatcherSettings();
      const status = aiEl('ai-provider-status');
      if (status) status.textContent = aiSettings.keyConfigured ? `${String(aiSettings.provider||'groq').toUpperCase()} · READY` : 'API KEY NEEDED';
    } catch (e) { showToast(e?.message || 'NEXORA Engineer settings unavailable'); }
  }
  function openAiModelDialog() {
    const dialog = aiEl('ai-model-dialog'); if (!dialog) return;
    const provider = aiEl('ai-provider-select'); provider.value = aiSettings?.provider || 'groq';
    fillAiModels(provider.value, aiSettings?.model || 'openai/gpt-oss-120b');
    aiEl('ai-api-key').value = '';
    dialog.showModal();
  }
  async function saveAiProvider() {
    const provider = aiEl('ai-provider-select')?.value || 'groq';
    const model = aiEl('ai-model-select')?.value || 'openai/gpt-oss-120b';
    const key = aiEl('ai-api-key')?.value || '';
    try {
      aiSettings = await window.nexora.setAiPatcherSettings({provider, model, ...(key.trim() ? {apiKey:key.trim()} : {})});
      aiEl('ai-model-dialog')?.close(); await refreshAiPatcherUi(); showToast('NEXORA Engineer settings saved');
    } catch (e) { showToast(e?.message || 'Could not save AI settings'); }
  }
  function addAiMessage(role, content, extra='') {
    const box=aiEl('ai-chat-messages'); if(!box) return null;
    const wrap=document.createElement('div'); wrap.className=`ai-msg ${role}`;
    wrap.innerHTML=`<div class="ai-avatar">${role==='assistant'?'N':'Y'}</div><div class="ai-bubble"><p>${escapeHTML(content).replace(/\n/g,'<br>')}</p>${extra}</div>`;
    box.appendChild(wrap); box.scrollTop=box.scrollHeight; return wrap;
  }
  function renderAiProposal(p) {
    const box=aiEl('ai-proposal'); if(!box) return;
    if(!p?.files?.length){ box.hidden=true; box.innerHTML=''; return; }
    box.hidden=false;
    box.innerHTML=`<div class="ai-chat-proposal-head"><div><span class="eyebrow-small">PATCH READY TO BUILD</span><b>${escapeHTML(p.summary||'NEXORA changes')}</b></div><span class="tiny-tag">${p.files.length} FILE${p.files.length===1?'':'S'}</span></div><div class="ai-proposal-files">${p.files.map(f=>`<details><summary>${escapeHTML(f.path)}<small>${escapeHTML(f.summary||'')}</small></summary><pre>${escapeHTML(f.diff||'')}</pre></details>`).join('')}</div><div class="ai-proposal-actions"><button type="button" class="outline-button" data-ai-discard>Discard</button><button type="button" class="primary-action" data-ai-apply>Build patch</button></div>`;
    box.scrollIntoView({block:'nearest'});
  }
  async function sendAiChat() {
    const input=aiEl('ai-chat-input'); const message=input?.value?.trim()||'';
    if(message.length<2) return;
    if(!aiSettings?.keyConfigured){ openAiModelDialog(); showToast('Add an API key first'); return; }
    addAiMessage('user',message); aiHistory.push({role:'user',content:message}); if(aiHistory.length>12) aiHistory.splice(0,aiHistory.length-12);
    input.value=''; const btn=aiEl('ai-chat-send'); if(btn){btn.disabled=true;btn.textContent='Thinking…';}
    const typing=addAiMessage('assistant','Inspecting NEXORA…'); typing?.classList.add('thinking');
    try {
      const result=await window.nexora.chatWithNexoraEngineer({message,history:aiHistory.slice(0,-1),scope:{area:aiScopeValue(),element:aiSelectedElement}});
      typing?.remove(); const reply=result?.message||'I inspected NEXORA.'; addAiMessage('assistant',reply); aiHistory.push({role:'assistant',content:reply}); if(aiHistory.length>12) aiHistory.splice(0,aiHistory.length-12);
      aiProposal=result?.proposal||null; renderAiProposal(aiProposal);
    } catch(e){ typing?.remove(); addAiMessage('assistant',e?.message||'I could not inspect NEXORA right now.'); }
    finally { if(btn){btn.disabled=false;btn.innerHTML='<svg><use href="#i-spark"/></svg> Send';} input?.focus(); }
  }
  document.addEventListener('click', async event => {
    const target=event.target;
    if(target.closest?.('#ai-element-picker')){startAiElementPicker();return;}
    if(target.closest?.('#ai-element-clear')){aiSelectedElement=null;renderAiElementTarget();return;}
    if(target.closest?.('[data-ai-models]')){openAiModelDialog();return;}
    if(target.closest?.('[data-ai-model-cancel]')){aiEl('ai-model-dialog')?.close();return;}
    if(target.closest?.('[data-ai-model-save]')){await saveAiProvider();return;}
    if(target.closest?.('#ai-chat-send')){await sendAiChat();return;}
    if(target.closest?.('[data-ai-discard]')){await window.nexora.discardAiPatch();aiProposal=null;renderAiProposal(null);addAiMessage('assistant','Okay — I discarded those proposed changes.');return;}
    if(target.closest?.('[data-ai-apply]')){if(!aiProposal?.id)return;try{const r=await window.nexora.applyAiPatch(aiProposal.id);addAiMessage('assistant',`Patch package built for ${r?.changed?.length||0} NEXORA file${(r?.changed?.length||0)===1?'':'s'}. Review complete. Apply it now?${r?.zipPath?` A ZIP copy was also written to ${r.zipPath}.`:''}`,'<button type="button" class="primary-action ai-inline-restart" data-ai-install-built>Apply patch</button>');}catch(e){addAiMessage('assistant',e?.message||'The patch package could not be built.');}return;}
    if(target.closest?.('[data-ai-install-built]')){try{addAiMessage('assistant','Starting the NEXORA patch installer. NEXORA will close, apply the staged patch, and reopen.');await window.nexora.installBuiltAiPatch();}catch(e){addAiMessage('assistant',e?.message||'The patch installer could not start.');}return;}
    if(target.closest?.('[data-ai-rollback]')){try{const r=await window.nexora.rollbackAiPatch();addAiMessage('assistant',`Rolled back ${r?.restored?.length||0} file${(r?.restored?.length||0)===1?'':'s'}. Restart NEXORA to reload the restored code.`);}catch(e){addAiMessage('assistant',e?.message||'There is no edit available to roll back.');}return;}
    if(target.closest?.('[data-ai-restart]')){await window.nexora.restartAfterAiPatch();return;}
  });
  document.addEventListener('mousemove', event => {
    if(!aiPickMode || !aiPickOutline) return;
    const el=event.target;
    if(!(el instanceof Element) || el.closest('[data-ai-selector-control],.ai-pick-banner,.ai-pick-outline')) return;
    const r=el.getBoundingClientRect();
    Object.assign(aiPickOutline.style,{left:`${r.left}px`,top:`${r.top}px`,width:`${r.width}px`,height:`${r.height}px`});
  }, true);
  document.addEventListener('click', event => {
    if(!aiPickMode) return;
    const el=event.target;
    if(!(el instanceof Element) || el.closest('[data-ai-selector-control],.ai-pick-banner,.ai-pick-outline')) return;
    const navigation=el.closest('.nav-item[data-page],[data-goto],#to-console,#console-return');
    if(navigation) return;
    event.preventDefault(); event.stopImmediatePropagation(); captureAiElement(el);
  }, true);
  document.addEventListener('keydown', event => {
    if(aiPickMode && event.key==='Escape'){event.preventDefault();stopAiElementPicker();showToast('Element selection cancelled');return;}
  }, true);
  document.addEventListener('keydown', event => {
    if(event.target?.id==='ai-chat-input' && event.key==='Enter' && !event.shiftKey){event.preventDefault();void sendAiChat();}
  });
  document.addEventListener('change', event => {
    if(event.target?.id==='ai-provider-select') fillAiModels(event.target.value,null);
    if(event.target?.id==='ai-scope-select') { aiSelectedElement=null; renderAiElementTarget(); }
  });
  void refreshAiPatcherUi();



  /* v20 — single live controller preview + selective key mapper */
  const controllerPreviewState = {
    fallbackFamily: sessionStorage.getItem("nexora-controller-fallback") || (Math.random() < 0.5 ? "xbox" : "playstation"),
    family: null,
    padIndex: null,
    selectedControl: null,
    mappingState: null,
    captureKey: false,
    pressedControls: new Set(),
    raf: 0
  };
  sessionStorage.setItem("nexora-controller-fallback", controllerPreviewState.fallbackFamily);

  const GAMEPAD_BUTTON_TO_CONTROL = ["A","B","X","Y","L1","R1","L2","R2","Select","Start","L3","R3","DpadUp","DpadDown","DpadLeft","DpadRight"];

  function classifyNexoraController(id = "") {
    const value = String(id).toLowerCase();
    if (/054c|sony|dualsense|dualshock|playstation|wireless controller/.test(value)) return "playstation";
    if (/045e|xbox|xinput|x-box|microsoft/.test(value)) return "xbox";
    return "other";
  }

  function currentGamepads() {
    return typeof navigator.getGamepads === "function" ? Array.from(navigator.getGamepads() || []).filter(Boolean) : [];
  }

  const CONTROLLER_ARTWORK = {
    playstation: {
      local: "assets/controllers/playstation-dualsense.png",
      remote: "https://www.citypng.com/public/uploads/preview/sony-playstation5-ps5-white-controller-design-701751695142717blpzualcqv.png?v=2026010405",
      fallback: "assets/dualsense-mode.svg",
      alt: "PlayStation DualSense wireless controller"
    },
    xbox: {
      local: "assets/controllers/xbox-wireless.png",
      remote: "https://img.itch.zone/aW1nLzI0NzM5OTIyLnBuZw%3D%3D/original/qbTOf3.png",
      fallback: "assets/xbox-controller.svg",
      alt: "Xbox wireless controller"
    }
  };

  function setControllerArtwork(img, family) {
    if (!img || img.dataset.controllerArtworkFamily === family) return;
    const artwork = CONTROLLER_ARTWORK[family] || CONTROLLER_ARTWORK.xbox;
    const candidates = [artwork.local, artwork.remote, artwork.fallback];
    let sourceIndex = 0;
    img.dataset.controllerArtworkFamily = family;
    img.alt = artwork.alt;
    img.onerror = () => {
      sourceIndex += 1;
      if (sourceIndex < candidates.length) {
        img.src = candidates[sourceIndex];
        return;
      }
      img.onerror = null;
      img.alt = `${artwork.alt} preview unavailable`;
    };
    img.src = candidates[sourceIndex];
  }

  function chooseDisplayedController() {
    const pads = currentGamepads();
    const recognized = pads.find(p => ["xbox","playstation"].includes(classifyNexoraController(p?.id || "")));
    const pad = recognized || pads[0] || null;
    const detectedFamily = pad ? classifyNexoraController(pad.id || "") : null;
    const family = detectedFamily === "xbox" || detectedFamily === "playstation" ? detectedFamily : controllerPreviewState.fallbackFamily;
    controllerPreviewState.family = family;
    controllerPreviewState.padIndex = pad?.index ?? null;
    const stage = document.getElementById("single-controller-stage");
    const img = document.getElementById("active-controller-image");
    const title = document.getElementById("active-controller-title");
    const status = document.getElementById("active-controller-status");
    const liveName = document.getElementById("controller-live-name");
    const dot = document.getElementById("controller-live-dot");
    if (stage) stage.dataset.family = family;
    if (img) setControllerArtwork(img, family);
    if (title) title.textContent = family === "playstation" ? "PlayStation Controller" : "Xbox Controller";
    if (status) status.textContent = pad ? "CONNECTED" : "PREVIEW";
    if (liveName) liveName.textContent = pad ? (pad.id || `${family} controller`) : `No controller connected — showing ${family === "playstation" ? "PlayStation" : "Xbox"} preview`;
    if (dot) dot.classList.toggle("controller-connected", Boolean(pad));
    document.querySelectorAll(".controller-hotspot").forEach(button => {
      button.dataset.label = family === "playstation" ? button.dataset.labelPlaystation : button.dataset.labelXbox;
    });
    return pad;
  }

  function setHotspotPressed(control, pressed) {
    document.querySelectorAll(`.controller-hotspot[data-control="${CSS.escape(control)}"]`).forEach(button => button.classList.toggle("is-pressed", pressed));
  }

  function pollControllerPreview() {
    const controlsVisible = document.querySelector('[data-view="controls"]')?.classList.contains('active');
    if (controlsVisible) {
      const pads = currentGamepads();
      let pad = controllerPreviewState.padIndex == null ? null : pads.find(p => p.index === controllerPreviewState.padIndex);
      if (!pad) pad = chooseDisplayedController();
      const nextPressed = new Set();
      if (pad?.buttons) {
        pad.buttons.forEach((button, index) => {
          if (button?.pressed || Number(button?.value || 0) > 0.45) {
            const control = GAMEPAD_BUTTON_TO_CONTROL[index];
            if (control) nextPressed.add(control);
          }
        });
      }
      for (const control of controllerPreviewState.pressedControls) if (!nextPressed.has(control)) setHotspotPressed(control, false);
      for (const control of nextPressed) if (!controllerPreviewState.pressedControls.has(control)) setHotspotPressed(control, true);
      controllerPreviewState.pressedControls = nextPressed;
    }
    controllerPreviewState.raf = requestAnimationFrame(pollControllerPreview);
  }

  function prettyKey(code = "") {
    return String(code).replace(/^Key/, "").replace(/^Digit/, "").replace("Arrow", "Arrow ").replace("Control", "Ctrl ").replace("Shift", "Shift ");
  }

  async function loadControllerMappings() {
    if (!window.nexora?.getKeyMap) return;
    try {
      controllerPreviewState.mappingState = await window.nexora.getKeyMap();
      renderControllerMappings();
    } catch (error) {
      const status = document.getElementById("mapping-save-status");
      if (status) status.textContent = "Could not load mappings.";
    }
  }

  function currentMappingProfile() {
    const state = controllerPreviewState.mappingState;
    if (!state?.profiles?.length) return null;
    return state.profiles.find(p => p.id === "keymap_nexora_custom") || state.profiles.find(p => p.id === state.activeProfileId) || state.profiles[0] || null;
  }

  function renderControllerMappings() {
    const list = document.getElementById("mapping-list");
    if (!list) return;
    const profile = currentMappingProfile();
    const rows = (profile?.bindings || []).filter(b => !b.axisDir);
    const important = ["A","B","X","Y","L1","R1","L2","R2","L3","R3","Start","Select","DpadUp","DpadDown","DpadLeft","DpadRight"];
    const map = new Map(rows.map(b => [b.control, b.key]));
    list.innerHTML = important.map(control => `<button type="button" class="mapping-chip" data-map-control="${escapeHtml(control)}"><span>${escapeHtml(control)}</span><kbd>${escapeHtml(prettyKey(map.get(control) || "—"))}</kbd></button>`).join("");
    document.querySelectorAll(".controller-hotspot").forEach(button => {
      const key = map.get(button.dataset.control || "");
      button.classList.toggle("is-mapped", Boolean(key));
      button.title = key ? `${button.ariaLabel || button.dataset.control} → ${prettyKey(key)}` : (button.ariaLabel || button.dataset.control || "");
    });
  }

  function selectControllerControl(control) {
    controllerPreviewState.selectedControl = control;
    controllerPreviewState.captureKey = false;
    document.querySelectorAll(".controller-hotspot").forEach(button => button.classList.toggle("is-selected", button.dataset.control === control));
    const box = document.getElementById("mapping-target-box");
    const clear = document.getElementById("mapping-clear-button");
    const profile = currentMappingProfile();
    const existing = profile?.bindings?.find(b => b.control === control && !b.axisDir)?.key;
    if (box) {
      box.disabled = false;
      box.querySelector(".mapping-target-control").textContent = control;
      box.querySelector("strong").textContent = existing ? prettyKey(existing) : "Click here, then press a keyboard key";
      box.querySelector("small").textContent = existing ? `Currently mapped to ${prettyKey(existing)}. Click to change it.` : "The next keyboard key you press will be assigned.";
    }
    if (clear) clear.disabled = !existing;
  }

  async function saveControllerBinding(control, key) {
    if (!window.nexora?.saveKeyMapProfile) return;
    const state = controllerPreviewState.mappingState || await window.nexora.getKeyMap();
    const base = state.profiles.find(p => p.id === "keymap_nexora_custom") || state.profiles.find(p => p.id === state.activeProfileId) || state.profiles[0];
    const bindings = (base?.bindings || []).filter(b => !(b.control === control && !b.axisDir));
    if (key) bindings.push({ control, key });
    const profile = {
      id: "keymap_nexora_custom",
      name: "NEXORA Custom",
      description: "Controller bindings created from the NEXORA Controls screen",
      genre: "custom",
      version: 1,
      bindings
    };
    let next = await window.nexora.saveKeyMapProfile(profile);
    next = await window.nexora.setKeyMapActive(profile.id);
    next = await window.nexora.setKeyMapMode("controller");
    controllerPreviewState.mappingState = next;
    renderControllerMappings();
    selectControllerControl(control);
    const status = document.getElementById("mapping-save-status");
    if (status) status.textContent = key ? `${control} mapped to ${prettyKey(key)}.` : `${control} binding cleared.`;
  }

  document.addEventListener("click", event => {
    const hotspot = event.target.closest?.(".controller-hotspot");
    if (hotspot) {
      event.preventDefault();
      selectControllerControl(hotspot.dataset.control || "");
      return;
    }
    const mappingChip = event.target.closest?.(".mapping-chip[data-map-control]");
    if (mappingChip) {
      event.preventDefault();
      selectControllerControl(mappingChip.dataset.mapControl || "");
      return;
    }
    if (event.target.closest?.("#mapping-target-box")) {
      if (!controllerPreviewState.selectedControl) return;
      controllerPreviewState.captureKey = true;
      const box = document.getElementById("mapping-target-box");
      box?.classList.add("is-listening");
      const strong = box?.querySelector("strong");
      if (strong) strong.textContent = "Press a keyboard key…";
      event.preventDefault();
      return;
    }
    if (event.target.closest?.("#mapping-clear-button")) {
      if (controllerPreviewState.selectedControl) void saveControllerBinding(controllerPreviewState.selectedControl, null);
      event.preventDefault();
    }
  });

  document.addEventListener("keydown", event => {
    if (controllerPreviewState.captureKey && controllerPreviewState.selectedControl) {
      if (["Shift","Control","Alt","Meta"].includes(event.key)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      controllerPreviewState.captureKey = false;
      document.getElementById("mapping-target-box")?.classList.remove("is-listening");
      if (event.key === "Escape") {
        selectControllerControl(controllerPreviewState.selectedControl);
        return;
      }
      void saveControllerBinding(controllerPreviewState.selectedControl, event.code || event.key);
      return;
    }
    const controlsVisible = document.querySelector('[data-view="controls"]')?.classList.contains('active');
    if (!controlsVisible || event.repeat) return;
    const profile = currentMappingProfile();
    const hit = profile?.bindings?.find(b => !b.axisDir && b.key === (event.code || event.key));
    if (hit) {
      setHotspotPressed(hit.control, true);
      if (window.nexora?.sendPreviewMappedKey) {
        void window.nexora.sendPreviewMappedKey(event.code || event.key, "down").then(result => {
          if (result && !result.ok) {
            const status = document.getElementById("mapping-save-status");
            if (status) status.textContent = result.reason || "Virtual controller output unavailable.";
          }
        }).catch(() => {});
      }
    }
  }, true);
  document.addEventListener("keyup", event => {
    const controlsVisible = document.querySelector('[data-view="controls"]')?.classList.contains('active');
    if (!controlsVisible) return;
    const profile = currentMappingProfile();
    const hit = profile?.bindings?.find(b => !b.axisDir && b.key === (event.code || event.key));
    if (hit) {
      if (!controllerPreviewState.pressedControls.has(hit.control)) setHotspotPressed(hit.control, false);
      if (window.nexora?.sendPreviewMappedKey) void window.nexora.sendPreviewMappedKey(event.code || event.key, "up").catch(() => {});
    }
  }, true);

  window.addEventListener("gamepadconnected", () => { chooseDisplayedController(); });
  window.addEventListener("gamepaddisconnected", () => { chooseDisplayedController(); });
  chooseDisplayedController();
  void loadControllerMappings();
  if (!controllerPreviewState.raf) controllerPreviewState.raf = requestAnimationFrame(pollControllerPreview);


  /* Initialize settings UI, then apply any settings loaded from durable storage. */

  document.querySelectorAll(".settings-nav button").forEach((button, index) => {
    button.dataset.desktopSetting = Object.keys(settingsSections)[index] || "Appearance";
  });
  renderDesktopSettings("Appearance");
  applyStoredSettings();
  window.NEXORASettingsStore.subscribe(() => refreshSettingsStatus());
  window.NEXORASettingsStore.ready.then(() => {
    applyStoredSettings();
    renderDesktopSettings(activeDesktopSettings);
    if (!window.NEXORASettingsStore.get("desktopModeOnStartup")) enterConsole();
  }).catch(() => {
    applyStoredSettings();
    showToast("Settings loaded with defaults; storage may be unavailable");
  });
  document.querySelectorAll(".console-cover").forEach((button,index) => button.setAttribute("aria-pressed",String(index===0)));
  void refreshLibraryScreen();
})();
