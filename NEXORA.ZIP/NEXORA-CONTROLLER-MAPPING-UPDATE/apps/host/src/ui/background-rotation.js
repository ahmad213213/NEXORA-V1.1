(() => {
  "use strict";
  const BACKGROUNDS = [
    { id: "space-horizon", name: "Space Horizon", src: "assets/backgrounds/space-horizon.jpg" },
    { id: "nebula", name: "Nebula", src: "assets/backgrounds/nebula.jpg" },
    { id: "forest-vista", name: "Forest Vista", src: "assets/backgrounds/forest-vista.jpg" },
    { id: "earth-orbit", name: "Earth Orbit", src: "assets/backgrounds/earth-orbit.jpg" }
  ];
  if (!BACKGROUNDS.length) return;
  const STORAGE_KEY = "nexora.ui-preview.emptyBackgroundIndex.v2";
  let previous = -1;
  try { previous = Number.parseInt(window.localStorage.getItem(STORAGE_KEY) || "-1", 10); } catch {}
  let selectedIndex = 0;
  if (BACKGROUNDS.length > 1) {
    const randomInt = max => {
      try {
        const a = new Uint32Array(1);
        window.crypto.getRandomValues(a);
        return a[0] % max;
      } catch {
        return Math.floor(Math.random() * max);
      }
    };
    selectedIndex = randomInt(BACKGROUNDS.length);
    if (selectedIndex === previous) selectedIndex = (selectedIndex + 1 + randomInt(BACKGROUNDS.length - 1)) % BACKGROUNDS.length;
  }
  try { window.localStorage.setItem(STORAGE_KEY, String(selectedIndex)); } catch {}
  const selected = BACKGROUNDS[selectedIndex];
  const root = document.documentElement;
  root.style.setProperty("--nexora-empty-wallpaper", `url("${selected.src}")`);
  root.dataset.nexoraEmptyBackground = selected.id;
  root.dataset.nexoraEmptyBackgroundName = selected.name;
  window.NEXORAEmptyBackground = Object.freeze({ ...selected, index: selectedIndex, total: BACKGROUNDS.length });
})();
