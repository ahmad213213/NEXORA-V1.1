/* NEXORA settings core
 * Browser preview: versioned localStorage with a safe in-memory fallback.
 * Installed Electron app: optionally uses window.nexora.settings.getAll/setAll
 * from a context-isolated preload bridge; see SETTINGS-SYSTEM.md.
 */
(() => {
  "use strict";

  const options = (items) => items.map(([value, label = value]) => ({ value, label }));
  const schema = {
    Appearance: {
      kicker: "INTERFACE", title: "Appearance",
      desc: "Personalize the glass desktop and controller-first console.",
      rows: [
        { key: "theme", label: "Interface theme", description: "Choose the overall tone without changing your library", type: "select", default: "midnight", options: options([["midnight", "Midnight glass"], ["obsidian", "Obsidian"], ["earth", "Earth horizon"]]) },
        { key: "accent", label: "Accent color", description: "Apply highlights across both interface modes", type: "accent", default: "cyan" },
        { key: "reducedMotion", label: "Reduced motion", description: "Reduce decorative movement and transitions", type: "toggle", default: false },
        { key: "desktopModeOnStartup", label: "Launch in desktop mode", description: "Start on the full workspace instead of Console Mode", type: "toggle", default: true }
      ]
    },
    General: {
      kicker: "APP BEHAVIOR", title: "General",
      desc: "Configure startup preferences, profile details, and everyday behavior.",
      rows: [
        { key: "startWithWindows", label: "Start with Windows", description: "Saved preference; login registration requires the installed Windows app", type: "toggle", default: false, native: true },
        { key: "minimizeToTray", label: "Minimize to tray", description: "Saved preference; tray behavior requires the installed Windows app", type: "toggle", default: false, native: true },
        { key: "language", label: "Interface language", description: "Saved preference; this preview interface is currently English", type: "select", default: "English", options: options([["English", "English"], ["Spanish", "Español"], ["French", "Français"]]) },
        { key: "profileName", label: "Profile name", description: "Name shown in the desktop header", type: "text", default: "NEXORA User", maxLength: 40 }
      ]
    },
    Network: {
      kicker: "CONNECTIVITY", title: "Network",
      desc: "Save connection preferences for the host and future receiver pairing flow.",
      rows: [
        { key: "connectionMode", label: "Connection mode", description: "Preferred route when a receiver is connected", type: "select", default: "automatic", options: options([["automatic", "Automatic"], ["direct", "Direct preferred"], ["relay", "Relay only"]]) },
        { key: "relayFallback", label: "Relay fallback", description: "Allow relay routing if a direct connection cannot be made", type: "toggle", default: true },
        { key: "pairingCodeLifetime", label: "Pairing code lifetime", description: "Preferred expiry for temporary pairing codes", type: "select", default: "5", options: options([["2", "2 minutes"], ["5", "5 minutes"], ["10", "10 minutes"]]) },
        { key: "trustedDevicesInfo", label: "Trusted devices", description: "Device management becomes available when pairing is wired", type: "info", value: "Not connected yet" }
      ]
    },
    Streaming: {
      kicker: "VIDEO & AUDIO", title: "Streaming",
      desc: "Set defaults for the stream pipeline. These profiles are stored now and will be consumed when capture is connected.",
      rows: [
        { key: "resolution", label: "Resolution", description: "Preferred output size", type: "select", default: "1080p", options: options([["720p", "1280 × 720"], ["1080p", "1920 × 1080"], ["1440p", "2560 × 1440"], ["2160p", "3840 × 2160 (4K)"]]) },
        { key: "frameRate", label: "Frame rate", description: "Preferred stream frame rate", type: "select", default: "60", options: options([["30", "30 FPS"], ["60", "60 FPS"], ["120", "120 FPS"]]) },
        { key: "bitrateMbps", label: "Target bitrate", description: "Target video bitrate for the future stream pipeline", type: "range", default: 25, min: 5, max: 100, step: 5, unit: "Mbps" },
        { key: "encoder", label: "Video encoder", description: "Preferred encoder; availability will be checked at stream startup", type: "select", default: "auto", options: options([["auto", "Hardware · Auto"], ["nvenc", "NVIDIA NVENC"], ["amf", "AMD AMF"], ["qsv", "Intel Quick Sync"], ["software", "Software · x264"]]) },
        { key: "audioCapture", label: "Audio capture", description: "Audio source to use for the stream", type: "select", default: "system", options: options([["system", "System default"], ["application", "Game/application audio"], ["muted", "No audio"]]) },
        { key: "adaptiveQuality", label: "Adaptive quality", description: "Allow quality to adapt to changing network conditions", type: "toggle", default: true }
      ]
    },
    Updates: {
      kicker: "VERSIONS & RECOVERY", title: "Updates",
      desc: "Manage release preferences. The update service is not included in this UI-only package.",
      rows: [
        { key: "updateChannel", label: "Update channel", description: "Choose which release track the installed app should follow", type: "select", default: "stable", options: options([["stable", "Stable"], ["beta", "Beta · prerelease"]]) },
        { key: "automaticUpdateChecks", label: "Check automatically", description: "Saved preference for the future updater; no background checks run in this preview", type: "toggle", default: true },
        { key: "currentVersionInfo", label: "Current build", description: "This delivered package is a browser-run UI prototype", type: "info", value: "1.3.0 · UI preview" },
        { key: "checkUpdates", label: "Check for updates", description: "Requires an update manifest and updater service", type: "action", action: "check-updates", actionLabel: "Check now" }
      ]
    },
    "Privacy & security": {
      kicker: "LOCAL PROTECTION", title: "Privacy & security",
      desc: "Set security preferences for future host and session services. They are saved here but are not enforced by a networking service in this preview.",
      rows: [
        { key: "requireDeviceApproval", label: "Require device approval", description: "Only approved receivers should be allowed to pair", type: "toggle", default: true },
        { key: "encryptSessions", label: "Require secure sessions", description: "Prefer encrypted media and authenticated session setup", type: "toggle", default: true },
        { key: "diagnosticLogging", label: "Diagnostic logging", description: "Allow structured local diagnostics when logging is connected", type: "toggle", default: false },
        { key: "shareCrashReports", label: "Share crash reports", description: "Preference only; no report is uploaded by this preview", type: "toggle", default: false },
        { key: "storageInfo", label: "Settings storage", description: "This prototype saves a versioned settings file in browser storage", type: "info", value: "Local device" }
      ]
    }
  };

  const allFields = Object.values(schema).flatMap(section => section.rows).filter(row => row.key && row.type !== "info" && row.type !== "action");
  const defaults = Object.fromEntries(allFields.map(field => [field.key, field.default]));
  const enumValues = Object.fromEntries(allFields.filter(field => field.type === "select").map(field => [field.key, field.options.map(option => option.value)]));
  const accents = ["cyan", "blue", "violet", "amber", "emerald", "rose"];
  const STORAGE_KEY = "nexora.settings.v1";
  let state = { ...defaults };
  let backend = "memory";
  let lastError = "";
  const listeners = new Set();
  let persistenceQueue = Promise.resolve();

  const copy = (value) => JSON.parse(JSON.stringify(value));
  function sanitise(source) {
    const next = { ...defaults };
    if (!source || typeof source !== "object" || Array.isArray(source)) return next;
    for (const field of allFields) {
      if (!Object.prototype.hasOwnProperty.call(source, field.key)) continue;
      const value = source[field.key];
      if (field.type === "toggle") {
        if (typeof value === "boolean") next[field.key] = value;
      } else if (field.type === "select") {
        if (enumValues[field.key].includes(String(value))) next[field.key] = String(value);
      } else if (field.type === "accent") {
        if (accents.includes(value)) next[field.key] = value;
      } else if (field.type === "text") {
        if (typeof value === "string") next[field.key] = value.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, field.maxLength || 40) || field.default;
      } else if (field.type === "range") {
        const numeric = Number(value);
        if (Number.isFinite(numeric)) {
          const bounded = Math.max(field.min, Math.min(field.max, numeric));
          next[field.key] = Math.max(field.min, Math.min(field.max, Math.round((bounded - field.min) / field.step) * field.step + field.min));
        }
      }
    }
    return next;
  }

  function emit() {
    const snapshot = copy(state);
    for (const listener of listeners) {
      try { listener(snapshot, { backend, lastError }); } catch (error) { console.error("NEXORA settings listener failed", error); }
    }
  }

  function saveLocal() {
    try {
      if (!window.localStorage) throw new Error("Browser storage is unavailable.");
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, settings: state }));
      backend = "localStorage";
      lastError = "";
      return { ok: true, backend };
    } catch (error) {
      backend = "memory";
      lastError = error && error.message ? error.message : "Browser storage is blocked.";
      return { ok: false, backend, error: lastError };
    }
  }

  function readLocal() {
    try {
      const raw = window.localStorage && window.localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, settings: defaults }));
          backend = "localStorage";
        } catch (error) {
          backend = "memory";
          lastError = error && error.message ? error.message : "Browser storage is blocked.";
        }
        return { ...defaults };
      }
      const parsed = JSON.parse(raw);
      const values = parsed && parsed.settings && typeof parsed.settings === "object" ? parsed.settings : parsed;
      backend = "localStorage";
      return sanitise(values);
    } catch (error) {
      backend = "memory";
      lastError = error && error.message ? error.message : "Saved settings could not be read.";
      return { ...defaults };
    }
  }

  function getBridge() {
    const candidate = window.nexora && window.nexora.settings;
    return candidate && typeof candidate.getAll === "function" && typeof candidate.setAll === "function" ? candidate : null;
  }

  async function initialise() {
    const bridge = getBridge();
    if (bridge) {
      try {
        const loaded = await bridge.getAll();
        if (loaded && typeof loaded === "object") state = sanitise(loaded.settings || loaded);
        backend = "electron";
        lastError = "";
      } catch (error) {
        state = readLocal();
        lastError = "App settings bridge was unavailable; using browser storage.";
      }
    } else {
      state = readLocal();
    }
    emit();
    return copy(state);
  }

  function persist() {
    // Serialize writes so rapid edits cannot finish out of order and overwrite
    // a newer profile with an older snapshot in the Electron backend.
    const snapshot = copy(state);
    const operation = async () => {
      const bridge = getBridge();
      if (bridge) {
        try {
          const response = await bridge.setAll(snapshot);
          if (response && response.ok === false) throw new Error(response.error || "App settings write was rejected.");
          backend = "electron";
          lastError = "";
          return { ok: true, backend };
        } catch (error) {
          const backupResult = saveLocal();
          lastError = "The app settings bridge failed; a browser-storage backup was attempted.";
          return { ok: false, backend, error: lastError, backup: backupResult.ok };
        }
      }
      return saveLocal();
    };
    const next = persistenceQueue.then(operation, operation);
    persistenceQueue = next.catch(() => {});
    return next;
  }

  const ready = initialise();
  const api = {
    schema,
    defaults: copy(defaults),
    ready,
    get(key) { return state[key]; },
    getAll() { return copy(state); },
    get backend() { return backend; },
    get lastError() { return lastError; },
    subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); },
    async set(key, value) {
      const field = allFields.find(item => item.key === key);
      if (!field) return { ok: false, error: "Unknown settings key." };
      const merged = sanitise({ ...state, [key]: value });
      if (JSON.stringify(merged[key]) === JSON.stringify(state[key])) return { ok: true, unchanged: true, backend };
      state = merged;
      emit();
      const result = await persist();
      emit();
      return result;
    },
    async reset() {
      state = { ...defaults };
      emit();
      const result = await persist();
      emit();
      return result;
    },
    async replace(incoming) {
      state = sanitise(incoming);
      emit();
      const result = await persist();
      emit();
      return result;
    },
    exportPayload() {
      return { app: "NEXORA", schemaVersion: 1, exportedAt: new Date().toISOString(), settings: copy(state) };
    },
    statusLabel() {
      if (backend === "electron") return "Saved in app settings";
      if (backend === "localStorage" && lastError) return "Browser backup active · app storage unavailable";
      if (backend === "localStorage") return "Saved on this device";
      return "Session only · storage unavailable";
    }
  };

  window.NEXORASettingsStore = api;
})();
