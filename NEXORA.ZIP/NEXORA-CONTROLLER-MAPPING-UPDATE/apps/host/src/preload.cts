import { contextBridge, ipcRenderer } from 'electron';

const api = Object.freeze({
  getConfig: () => ipcRenderer.invoke('config:get'),
  setConfig: (value: unknown) => ipcRenderer.invoke('config:set', value),
  getSettingsCapabilities: () => ipcRenderer.invoke('settings:capabilities'),
  exportSettings: () => ipcRenderer.invoke('settings:export'),
  importSettings: () => ipcRenderer.invoke('settings:import'),
  resetSettings: () => ipcRenderer.invoke('settings:reset'),
  getVersion: () => ipcRenderer.invoke('app:version'),
  checkForUpdate: () => ipcRenderer.invoke('update:check'),
  stageUpdate: (manifest: unknown) => ipcRenderer.invoke('update:stage', manifest),
  updateFromFile: (mode: 'patch' | 'restore') => ipcRenderer.invoke('update:from-file', mode),
  getUpdateSettings: () => ipcRenderer.invoke('update:get-settings'),
  setUpdateSettings: (value: { manifestUrl?: string; publicKeyB64?: string }) =>
    ipcRenderer.invoke('update:set-settings', value),
  getSystemStats: () => ipcRenderer.invoke('system:stats'),
  listGames: () => ipcRenderer.invoke('library:list'),
  addGame: () => ipcRenderer.invoke('library:add-dialog'),
  beginAddGame: () => ipcRenderer.invoke('library:begin-add'),
  orbitSearch: (pendingId: string, query: string, requestId: number) =>
    ipcRenderer.invoke('orbit:search', pendingId, query, requestId),
  orbitChoose: (pendingId: string, requestId: number, index: number) =>
    ipcRenderer.invoke('orbit:choose', pendingId, requestId, index),
  orbitCancel: (pendingId: string) => ipcRenderer.invoke('orbit:cancel', pendingId),
  onOrbitProgress: (callback: (progress: { pendingId: string; stage: string; detail: string | null }) => void) => {
    const handler = (_event: unknown, progress: { pendingId: string; stage: string; detail: string | null }) =>
      callback(progress);
    ipcRenderer.on('orbit:progress', handler);
    return () => {
      ipcRenderer.removeListener('orbit:progress', handler);
    };
  },
  selectMetadataCandidate: (pendingId: string, index: number) =>
    ipcRenderer.invoke('library:select-candidate', pendingId, index),
  removeGame: (id: string) => ipcRenderer.invoke('library:remove', id),
  togglePin: (id: string) => ipcRenderer.invoke('library:pin', id),
  markPlayed: (id: string, deltaSeconds?: number) => ipcRenderer.invoke('library:mark-played', id, deltaSeconds ?? 0),
  listDevices: () => ipcRenderer.invoke('devices:list'),
  revokeDevice: (deviceId: string) => ipcRenderer.invoke('devices:revoke', deviceId),
  openPairing: () => ipcRenderer.invoke('pairing:open'),
  pairingStatus: () => ipcRenderer.invoke('pairing:status'),
  listLayouts: () => ipcRenderer.invoke('layout:list'),
  saveLayout: (layout: unknown) => ipcRenderer.invoke('layout:save', layout),
  removeLayout: (id: string) => ipcRenderer.invoke('layout:remove', id),
  windowMinimize: () => ipcRenderer.invoke('window:minimize'),
  windowMaximize: () => ipcRenderer.invoke('window:maximize'),
  windowClose: () => ipcRenderer.invoke('window:close'),
  windowIsMaximized: () => ipcRenderer.invoke('window:is-maximized'),
  getKeyMap: () => ipcRenderer.invoke('keymap:get'),
  setKeyMapMode: (mode: 'off' | 'keyboard' | 'controller') => ipcRenderer.invoke('keymap:set-mode', mode),
  setKeyMapActive: (id: string) => ipcRenderer.invoke('keymap:set-active', id),
  saveKeyMapProfile: (profile: unknown) => ipcRenderer.invoke('keymap:save-profile', profile),
  resetKeyMapProfile: (id: string) => ipcRenderer.invoke('keymap:reset-profile', id),
  getAiPatcherSettings: () => ipcRenderer.invoke('ai-patcher:get-settings'),
  setAiPatcherSettings: (value: unknown) => ipcRenderer.invoke('ai-patcher:set-settings', value),
  chooseAiPatcherWorkspace: () => ipcRenderer.invoke('ai-patcher:choose-workspace'),
  proposeAiPatch: (request: string) => ipcRenderer.invoke('ai-patcher:propose', request),
  applyAiPatch: (id: string) => ipcRenderer.invoke('ai-patcher:apply', id),
  discardAiPatch: () => ipcRenderer.invoke('ai-patcher:discard'),
  rollbackAiPatch: () => ipcRenderer.invoke('ai-patcher:rollback'),
  runAiPatchCheck: (check: 'typecheck' | 'build' | 'test') => ipcRenderer.invoke('ai-patcher:check', check)
});

contextBridge.exposeInMainWorld('nexora', api);
