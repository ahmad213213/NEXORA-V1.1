import path from 'node:path';
import { access } from 'node:fs/promises';

export const HOST_RUNTIME_VERSION = '0.1.0';
export const REQUIRED_FFMPEG_BINARY = 'ffmpeg.exe';

export async function assertFfmpegAvailable(vendorDir: string): Promise<string> {
  const binary = path.join(vendorDir, REQUIRED_FFMPEG_BINARY);
  await access(binary);
  return binary;
}
