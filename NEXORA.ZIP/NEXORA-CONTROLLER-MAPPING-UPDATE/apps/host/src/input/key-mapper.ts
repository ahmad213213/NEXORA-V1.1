import {
  mapGamepadEventToKeys,
  mapKeyEventToGamepad,
  normalizeControlName,
  type InputEvent,
  type KeyMapProfile
} from '@nexora/shared';

export type MapperDirection = 'off' | 'to-keyboard' | 'to-controller';

/**
 * Bidirectional input mapper.
 *
 * to-controller: keyboard/mouse keys become Xbox-style gamepad events
 *                (for Cricket 22 and other pad-required games)
 * to-keyboard:   gamepad events become keyboard keys
 * off:           pass through unchanged
 */
export class KeyMapper {
  private direction: MapperDirection = 'to-controller';
  private profile: KeyMapProfile | null = null;
  private axisKeyDown = new Set<string>();
  /** Track opposing axis keys so W+S doesn't fight */
  private axisHeld = new Map<string, { neg: boolean; pos: boolean }>();

  setProfile(profile: KeyMapProfile | null): void {
    this.profile = profile;
    this.axisKeyDown.clear();
    this.axisHeld.clear();
  }

  setDirection(direction: MapperDirection): void {
    this.direction = direction;
    this.axisKeyDown.clear();
    this.axisHeld.clear();
  }

  translate(event: InputEvent): InputEvent[] {
    if (this.direction === 'off' || !this.profile) {
      return [event];
    }

    if (this.direction === 'to-controller') {
      return this.toController(event);
    }

    return this.toKeyboard(event);
  }

  /** Keyboard keys -> virtual controller (Cricket 22 style). */
  private toController(event: InputEvent): InputEvent[] {
    if (event.kind === 'gamepad-button' || event.kind === 'gamepad-axis') {
      // Already a controller event (phone touch pad / real pad) — pass through
      return [{ ...event, code: normalizeControlName(event.code) }];
    }

    if (event.kind !== 'key' && event.kind !== 'mouse-button') {
      return [event];
    }

    const mapped = mapKeyEventToGamepad(event, this.profile);
    if (!mapped.length) return [];

    const out: InputEvent[] = [];
    for (const m of mapped) {
      if (m.kind === 'gamepad-axis') {
        out.push(...this.mergeAxisFromKey(m, event));
      } else {
        out.push({
          kind: 'gamepad-button',
          action: m.action === 'move' ? 'down' : m.action,
          code: m.code,
          value: m.value,
          sequence: m.sequence,
          timestamp: m.timestamp
        });
      }
    }
    return out;
  }

  private mergeAxisFromKey(
    m: { code: string; value?: number; sequence: number; timestamp: number },
    event: InputEvent
  ): InputEvent[] {
    const control = m.code;
    let state = this.axisHeld.get(control);
    if (!state) {
      state = { neg: false, pos: false };
      this.axisHeld.set(control, state);
    }
    const v = typeof m.value === 'number' ? m.value : 0;
    if (event.action === 'down') {
      if (v < 0) state.neg = true;
      if (v > 0) state.pos = true;
    } else if (event.action === 'up') {
      if (v < 0 || v === 0) {
        // mapKey sends 0 on up — infer from previous: clear both if zero-only
      }
      // On key up we get value 0 from mapKeyEventToGamepad — need bind direction
      // Re-scan profile for this key
      const bind = this.profile?.bindings.find(b => b.key === event.code && b.control === control);
      if (bind?.axisDir === 'neg') state.neg = false;
      if (bind?.axisDir === 'pos') state.pos = false;
    }

    let value = 0;
    if (state.pos && !state.neg) value = 1;
    else if (state.neg && !state.pos) value = -1;

    return [{
      kind: 'gamepad-axis',
      action: 'move',
      code: control,
      value,
      sequence: event.sequence,
      timestamp: event.timestamp
    }];
  }

  private toKeyboard(event: InputEvent): InputEvent[] {
    if (event.kind === 'key' || event.kind === 'mouse-button' || event.kind === 'mouse-move' || event.kind === 'touch') {
      return [event];
    }

    const control = normalizeControlName(event.code);
    const normalized = { ...event, code: control };

    if (normalized.kind === 'gamepad-button') {
      const mapped = mapGamepadEventToKeys(normalized, this.profile);
      return mapped.map(m => ({
        kind: m.kind,
        action: m.action,
        code: m.code,
        sequence: m.sequence,
        timestamp: m.timestamp
      }));
    }

    if (normalized.kind === 'gamepad-axis') {
      return this.translateAxisToKeys(normalized);
    }

    return [];
  }

  private translateAxisToKeys(event: InputEvent): InputEvent[] {
    if (!this.profile) return [];
    const threshold = 0.45;
    const value = typeof event.value === 'number' ? event.value : 0;
    const control = normalizeControlName(event.code);
    const out: InputEvent[] = [];
    const pos = this.profile.bindings.find(b => b.control === control && b.axisDir === 'pos');
    const neg = this.profile.bindings.find(b => b.control === control && b.axisDir === 'neg');

    const apply = (key: string | undefined, active: boolean) => {
      if (!key) return;
      const id = `${control}:${key}`;
      const down = this.axisKeyDown.has(id);
      if (active && !down) {
        this.axisKeyDown.add(id);
        out.push({
          kind: key.startsWith('Mouse') ? 'mouse-button' : 'key',
          action: 'down',
          code: key,
          sequence: event.sequence,
          timestamp: event.timestamp
        });
      } else if (!active && down) {
        this.axisKeyDown.delete(id);
        out.push({
          kind: key.startsWith('Mouse') ? 'mouse-button' : 'key',
          action: 'up',
          code: key,
          sequence: event.sequence,
          timestamp: event.timestamp
        });
      }
    };

    apply(pos?.key, value >= threshold);
    apply(neg?.key, value <= -threshold);
    return out;
  }

  reset(): void {
    this.axisKeyDown.clear();
    this.axisHeld.clear();
  }
}
