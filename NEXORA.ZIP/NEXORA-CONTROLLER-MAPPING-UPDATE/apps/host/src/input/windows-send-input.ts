import { createRequire } from 'node:module';
import type { InputEvent } from '@nexora/shared';
import type { InputSink } from './input-manager.js';

/**
 * Production Windows SendInput boundary.
 *
 * Looks for an optional native addon (`nexora-sendinput`) that exports:
 *   send(event: InputEvent): Promise<void>
 *   releaseAll(): Promise<void>
 *
 * If the native module is missing or fails to load, the sink throws a clear
 * error instead of silently dropping input. This keeps the boundary honest.
 */
type NativeProvider = {
  send(event: InputEvent): Promise<void> | void;
  releaseAll(): Promise<void> | void;
};

let cachedProvider: NativeProvider | null | undefined;

function loadNativeProvider(): NativeProvider | null {
  if (cachedProvider !== undefined) return cachedProvider;
  if (process.platform !== 'win32') {
    cachedProvider = null;
    return null;
  }
  try {
    const require = createRequire(import.meta.url);
    // Optional dependency – not present in the pure-TS build.
    const mod = require('nexora-sendinput') as { default?: NativeProvider } & NativeProvider;
    const provider = (mod.default ?? mod) as NativeProvider;
    if (typeof provider.send !== 'function' || typeof provider.releaseAll !== 'function') {
      cachedProvider = null;
      return null;
    }
    cachedProvider = provider;
    return provider;
  } catch {
    cachedProvider = null;
    return null;
  }
}

export class WindowsInputSink implements InputSink {
  private provider: NativeProvider | null = null;

  constructor() {
    this.provider = loadNativeProvider();
  }

  async send(event: InputEvent): Promise<void> {
    if (process.platform !== 'win32') {
      throw new Error('WindowsInputSink requires Windows');
    }
    if (!this.provider) {
      throw new Error('Native Windows SendInput provider is not installed in this build');
    }
    await this.provider.send(event);
  }

  async releaseAll(): Promise<void> {
    if (process.platform !== 'win32') return;
    if (!this.provider) {
      throw new Error('Native Windows SendInput provider is not installed in this build');
    }
    await this.provider.releaseAll();
  }

  /** True when a native provider was successfully loaded. */
  get available(): boolean {
    return this.provider !== null;
  }
}
