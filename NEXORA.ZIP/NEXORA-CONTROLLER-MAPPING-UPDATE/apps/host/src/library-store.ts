import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { app } from 'electron';
import type { GameRecord } from './library.js';

export function storePath(): string { return path.join(app.getPath('userData'), 'library.json'); }
export function coversPath(): string { return path.join(app.getPath('userData'), 'covers'); }
export function shotsPath(): string { return path.join(app.getPath('userData'), 'shots'); }
function tempPath(): string { return `${storePath()}.tmp`; }

export async function loadLibrary(): Promise<GameRecord[]> {
  try {
    const value = JSON.parse(await readFile(storePath(), 'utf8'));
    if (!Array.isArray(value)) throw new Error('Invalid library');
    return value.filter(x => x && typeof x === 'object' && typeof x.id === 'string' && typeof x.exePath === 'string');
  } catch {
    return [];
  }
}

export async function saveLibrary(games: GameRecord[]): Promise<GameRecord[]> {
  const dir = app.getPath('userData');
  await mkdir(dir, { recursive: true });
  await writeFile(tempPath(), JSON.stringify(games, null, 2), { encoding: 'utf8', mode: 0o600 });
  await rename(tempPath(), storePath());
  return games;
}

export async function saveCover(gameId: string, bytes: Uint8Array, extension = 'jpg', maxBytes = 5 * 1024 * 1024): Promise<string> {
  if (!/^game_[a-f0-9]{24}$/.test(gameId)) throw new Error('Invalid game ID');
  if (bytes.byteLength > maxBytes) throw new Error('Cover too large');
  const dir = coversPath();
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, `${gameId}.${extension}`);
  const tmp = `${file}.tmp`;
  await writeFile(tmp, bytes);
  await rename(tmp, file);
  // A cover saved earlier with another file type must not shadow the new one (the loader tries jpg, png, webp in that order).
  const fs = await import('node:fs/promises');
  for (const ext of ['jpg', 'png', 'webp']) {
    if (ext !== extension) { try { await fs.unlink(path.join(dir, `${gameId}.${ext}`)); } catch { /* absent */ } }
  }
  return file;
}

export async function removeCover(gameId: string): Promise<void> {
  const fs = await import('node:fs/promises');
  for (const ext of ['jpg', 'png', 'webp']) {
    try { await fs.unlink(path.join(coversPath(), `${gameId}.${ext}`)); } catch { /* absent */ }
  }
}

/** Saves screenshots as shots/<gameId>/01.jpg ... and returns the file names (not full paths). */
export async function saveScreenshots(gameId: string, shots: Array<{ bytes: Uint8Array; ext: string }>): Promise<Array<{ file: string; mime: string }>> {
  if (!/^game_[a-f0-9]{24}$/.test(gameId)) throw new Error('Invalid game ID');
  const dir = path.join(shotsPath(), gameId);
  await rm(dir, { recursive: true, force: true });
  await mkdir(dir, { recursive: true });
  const saved: Array<{ file: string; mime: string }> = [];
  for (const [i, shot] of shots.entries()) {
    if (!['jpg', 'png', 'webp'].includes(shot.ext) || shot.bytes.byteLength > 8 * 1024 * 1024) continue;
    const file = `${String(i + 1).padStart(2, '0')}.${shot.ext}`;
    const target = path.join(dir, file);
    await writeFile(`${target}.tmp`, shot.bytes);
    await rename(`${target}.tmp`, target);
    saved.push({ file, mime: shot.ext === 'png' ? 'image/png' : shot.ext === 'webp' ? 'image/webp' : 'image/jpeg' });
  }
  return saved;
}

export async function removeScreenshots(gameId: string): Promise<void> {
  if (!/^game_[a-f0-9]{24}$/.test(gameId)) return;
  const fs = await import('node:fs/promises');
  try { await fs.rm(path.join(shotsPath(), gameId), { recursive: true, force: true }); } catch { /* absent */ }
}
