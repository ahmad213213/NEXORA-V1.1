export interface CoverData {
  bytes: Uint8Array;
  mime: string;
}

export interface MetadataCandidate {
  provider: string;
  title: string;
  aliases?: string[];
  description: string;
  genres: string[];
  gameType: string;
  platform: 'windows' | 'linux' | 'mac' | 'unknown';
  sourceUrl: string;
  cover: CoverData;
  releaseDate?: string;
  sourceConfidence: number;
}

export interface RankedCandidate extends MetadataCandidate {
  normalizedTitle: string;
  score: number;
  reasons: string[];
}

export interface MetadataProvider {
  readonly id: string;
  search(title: string, signal?: AbortSignal): Promise<MetadataCandidate[]>;
}

const IMAGE_SIGNATURES: Array<{mime: string; bytes: number[]}> = [
  { mime: 'image/png', bytes: [0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a] },
  { mime: 'image/jpeg', bytes: [0xff,0xd8,0xff] },
  { mime: 'image/webp', bytes: [0x52,0x49,0x46,0x46] }
];

export function normalizeTitle(input: string): string {
  return input.toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, ' ').replace(/\b(the)\b/g, ' ').replace(/\s+/g, ' ').trim();
}

export function stripHtml(input: string): string {
  return input.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/\s+/g, ' ').trim();
}

export function hasMeaningfulDescription(input: string): boolean {
  const clean = stripHtml(input);
  return clean.length >= 40 && /[a-z]{4}/i.test(clean);
}

export function detectCoverMime(bytes: Uint8Array): 'image/png'|'image/jpeg'|'image/webp'|null {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength < 32 || bytes.byteLength > 5 * 1024 * 1024) return null;
  if (IMAGE_SIGNATURES[0].bytes.every((v, i) => bytes[i] === v)) return 'image/png';
  if (IMAGE_SIGNATURES[1].bytes.every((v, i) => bytes[i] === v)) return 'image/jpeg';
  if (IMAGE_SIGNATURES[2].bytes.every((v, i) => bytes[i] === v) && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) return 'image/webp';
  return null;
}

export function validateCover(cover: CoverData): boolean {
  return !!cover && detectCoverMime(cover.bytes) !== null;
}

export function acceptanceGate(candidate: MetadataCandidate): {ok: boolean; reasons: string[]} {
  const reasons: string[] = [];
  if (!candidate.title.trim()) reasons.push('missing title');
  if (!candidate.gameType.trim()) reasons.push('unknown game type');
  if (!hasMeaningfulDescription(candidate.description)) reasons.push('missing meaningful description');
  if (!validateCover(candidate.cover)) reasons.push('invalid cover');
  if (candidate.platform !== 'windows') reasons.push('not verified for Windows');
  if (!candidate.provider.trim()) reasons.push('missing provider');
  if (!/^https:\/\//i.test(candidate.sourceUrl)) reasons.push('invalid source URL');
  return { ok: reasons.length === 0, reasons };
}

function tokenSimilarity(a: string, b: string): number {
  const aa = new Set(normalizeTitle(a).split(' ').filter(Boolean));
  const bb = new Set(normalizeTitle(b).split(' ').filter(Boolean));
  if (!aa.size || !bb.size) return 0;
  let common = 0;
  for (const token of aa) if (bb.has(token)) common++;
  return common / Math.max(aa.size, bb.size);
}

export function rankCandidate(query: string, candidate: MetadataCandidate): RankedCandidate {
  const normalizedQuery = normalizeTitle(query);
  const normalizedCandidate = normalizeTitle(candidate.title);
  const reasons: string[] = [];
  let score = 0;
  if (normalizedQuery && normalizedQuery === normalizedCandidate) { score += 45; reasons.push('exact title'); }
  else {
    const similarity = tokenSimilarity(query, candidate.title);
    score += similarity * 25;
    if (similarity >= 0.8) reasons.push('strong title similarity');
  }
  const aliases = (candidate.aliases || []).map(normalizeTitle);
  if (aliases.includes(normalizedQuery)) { score += 20; reasons.push('known alias'); }
  if (candidate.platform === 'windows') { score += 10; reasons.push('Windows compatible'); }
  if (candidate.gameType) { score += 5; reasons.push('game type'); }
  if (hasMeaningfulDescription(candidate.description)) { score += 5; reasons.push('description'); }
  if (validateCover(candidate.cover)) { score += 5; reasons.push('valid cover'); }
  score += Math.max(0, Math.min(10, candidate.sourceConfidence * 10));
  return { ...candidate, normalizedTitle: normalizedCandidate, score, reasons };
}

export function rankGlobally(query: string, candidates: MetadataCandidate[]): RankedCandidate[] {
  const ranked = candidates.map(c => rankCandidate(query, c));
  const dedup = new Map<string, RankedCandidate>();
  for (const item of ranked) {
    const key = item.normalizedTitle;
    const existing = dedup.get(key);
    if (!existing || item.score > existing.score) dedup.set(key, item);
  }
  return [...dedup.values()].sort((a,b) => b.score - a.score || a.provider.localeCompare(b.provider));
}

export async function resolveMetadata(query: string, providers: MetadataProvider[], signal?: AbortSignal): Promise<{status: 'accepted'|'ambiguous'|'rejected'; selected?: RankedCandidate; candidates: RankedCandidate[]; reasons: string[]}> {
  const results = await Promise.allSettled(providers.map(p => p.search(query, signal)));
  const all: MetadataCandidate[] = [];
  for (const result of results) if (result.status === 'fulfilled') all.push(...result.value);
  const ranked = rankGlobally(query, all);
  const accepted = ranked.filter(item => acceptanceGate(item).ok && item.score >= 70);
  if (!accepted.length) return { status: 'rejected', candidates: ranked, reasons: ranked[0] ? acceptanceGate(ranked[0]).reasons : ['no verified metadata candidate'] };
  const top = accepted[0];
  const second = accepted[1];
  if (second && top.score - second.score < 7) return { status: 'ambiguous', candidates: accepted.slice(0, 8), reasons: ['multiple strong metadata matches'] };
  return { status: 'accepted', selected: top, candidates: accepted.slice(0, 8), reasons: top.reasons };
}
