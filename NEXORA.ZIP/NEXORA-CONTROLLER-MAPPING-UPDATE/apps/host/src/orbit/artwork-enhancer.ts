import { app } from 'electron';
import { spawn } from 'node:child_process';
import { mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { promisify } from 'node:util';
import { execFile as rawExecFile } from 'node:child_process';

const execFile = promisify(rawExecFile);
const ENGINE_URL = 'https://github.com/xinntao/Real-ESRGAN-ncnn-vulkan/releases/download/v0.2.0/realesrgan-ncnn-vulkan-20220424-windows.zip';
const MAX_ENGINE_BYTES = 250 * 1024 * 1024;
const MAX_OUTPUT_BYTES = 5 * 1024 * 1024;
let enginePromise: Promise<string | null> | undefined;

export type ArtworkMime = 'image/png' | 'image/jpeg' | 'image/webp';
export type EnhancedArtwork = { bytes: Uint8Array; extension: 'png' | 'jpg' | 'webp'; mime: ArtworkMime; enhanced: boolean };

function extensionFor(mime: ArtworkMime): 'png' | 'jpg' | 'webp' {
  return mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : 'jpg';
}
async function findExecutable(dir: string): Promise<string | null> {
  let entries;
  try { entries = await readdir(dir, { withFileTypes: true }); } catch { return null; }
  for (const entry of entries) {
    const candidate = path.join(dir, entry.name);
    if (entry.isFile() && entry.name.toLowerCase() === 'realesrgan-ncnn-vulkan.exe') return candidate;
    if (entry.isDirectory()) { const nested = await findExecutable(candidate); if (nested) return nested; }
  }
  return null;
}
async function ensureEngine(): Promise<string | null> {
  if (process.platform !== 'win32') return null;
  const dir = path.join(app.getPath('userData'), 'artwork-engine');
  const existing = await findExecutable(dir);
  if (existing) return existing;
  await mkdir(dir, { recursive: true });
  const archive = path.join(dir, 'engine.zip');
  try {
    const response = await fetch(ENGINE_URL, { redirect: 'follow', signal: AbortSignal.timeout(120_000) });
    if (!response.ok) return null;
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength < 1_000_000 || bytes.byteLength > MAX_ENGINE_BYTES) return null;
    await writeFile(archive, bytes);
    await execFile('powershell.exe', [
      '-NoProfile', '-NonInteractive', '-Command',
      `Expand-Archive -LiteralPath '${archive.replace(/'/g, "''")}' -DestinationPath '${dir.replace(/'/g, "''")}' -Force`
    ], { timeout: 120_000, windowsHide: true });
    return await findExecutable(dir);
  } catch {
    return null;
  } finally {
    await rm(archive, { force: true }).catch(() => undefined);
  }
}
async function engine(): Promise<string | null> {
  if (!enginePromise) enginePromise = ensureEngine().catch(() => null);
  return enginePromise;
}
function runUpscaler(exe: string, input: string, output: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn(exe, ['-i', input, '-o', output, '-n', 'realesrgan-x4plus', '-s', '2'], {
      windowsHide: true,
      cwd: path.dirname(exe),
      stdio: ['ignore', 'ignore', 'pipe']
    });
    let stderr = '';
    child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-4000); });
    const timer = setTimeout(() => { child.kill(); reject(new Error('Artwork processing timed out')); }, 180_000);
    child.once('error', error => { clearTimeout(timer); reject(error); });
    child.once('close', code => {
      clearTimeout(timer);
      if (code === 0) resolve();
      else reject(new Error(`Artwork processing failed (${code}): ${stderr}`));
    });
  });
}

/**
 * Enhances an image locally where supported. It deliberately fails closed: any
 * download/model/driver/format failure returns the original bytes and never
 * prevents a game from being added to the library.
 */
export async function enhanceArtwork(bytes: Uint8Array, mime: ArtworkMime, cacheKey: string): Promise<EnhancedArtwork> {
  const original: EnhancedArtwork = { bytes, mime, extension: extensionFor(mime), enhanced: false };
  if (!bytes.byteLength || bytes.byteLength > MAX_OUTPUT_BYTES) return original;
  const exe = await engine();
  if (!exe) return original;
  const tempDir = path.join(app.getPath('userData'), 'artwork-temp');
  const safeKey = cacheKey.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 80) || 'artwork';
  const input = path.join(tempDir, `${safeKey}-in.${original.extension}`);
  const output = path.join(tempDir, `${safeKey}-out.png`);
  try {
    await mkdir(tempDir, { recursive: true });
    await writeFile(input, bytes);
    await runUpscaler(exe, input, output);
    const result = await readFile(output);
    // Avoid pathological cache growth; retain original if the enhanced output is oversized.
    if (result.byteLength < 100 || result.byteLength > MAX_OUTPUT_BYTES) return original;
    return { bytes: result, mime: 'image/png', extension: 'png', enhanced: true };
  } catch {
    return original;
  } finally {
    await rm(input, { force: true }).catch(() => undefined);
    await rm(output, { force: true }).catch(() => undefined);
  }
}
