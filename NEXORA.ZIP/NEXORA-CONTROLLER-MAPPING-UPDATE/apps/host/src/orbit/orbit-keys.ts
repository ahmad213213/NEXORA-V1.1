import { readFile } from 'node:fs/promises';
import path from 'node:path';

/** Reads a small text file: BOM and Windows line endings (Notepad) are handled; empty lines are dropped. */
async function readLines(file: string): Promise<string[]> {
  try {
    return (await readFile(file, 'utf8')).replace(/^\uFEFF/, '').split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  } catch {
    return [];
  }
}

/**
 * Optional cover/metadata keys for NEXORA ORBIT, same file names as the Orbit CLI. Put them in
 * <userData>/orbit/ . Environment variables that are already set win over the files.
 *   steamgriddb-key.txt  one line: API key
 *   igdb-key.txt         line 1 Client ID, line 2 Client Secret
 *   rawg-key.txt         one line: API key
 */
export async function loadOrbitKeys(dir: string, env: Record<string, string | undefined> = process.env): Promise<string[]> {
  const enabled: string[] = [];
  const [sgdb] = await readLines(path.join(dir, 'steamgriddb-key.txt'));
  if (sgdb) { if (!env.STEAMGRIDDB_API_KEY) env.STEAMGRIDDB_API_KEY = sgdb; enabled.push('SteamGridDB'); }
  const [igdbId, igdbSecret] = await readLines(path.join(dir, 'igdb-key.txt'));
  if (igdbId && igdbSecret) {
    if (!env.IGDB_CLIENT_ID) { env.IGDB_CLIENT_ID = igdbId; env.IGDB_CLIENT_SECRET = igdbSecret; }
    enabled.push('IGDB');
  }
  const [rawg] = await readLines(path.join(dir, 'rawg-key.txt'));
  if (rawg) { if (!env.RAWG_API_KEY) env.RAWG_API_KEY = rawg; enabled.push('RAWG'); }
  return enabled;
}

/** aliases.json (same format as the CLI): { "mw2": "Call of Duty: Modern Warfare II" } */
export async function loadOrbitAliases(file: string): Promise<Record<string, string>> {
  try {
    const raw = JSON.parse(await readFile(file, 'utf8')) as Record<string, unknown>;
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(raw)) if (!k.startsWith('_') && typeof v === 'string' && v.trim()) out[k] = v.trim();
    return out;
  } catch {
    return {};
  }
}
