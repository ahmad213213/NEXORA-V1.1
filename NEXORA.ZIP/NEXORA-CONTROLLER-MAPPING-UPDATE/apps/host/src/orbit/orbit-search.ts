import type {
  OrbitBestCover,
  OrbitGame,
  OrbitImage,
  OrbitProviderStatus,
  OrbitRecord,
  OrbitSearchResult
} from './orbit-lib.mjs';

/**
 * NEXORA ORBIT search + selection service for the "Add game" flow.
 *
 * - Searches run in the background while the user types (the renderer debounces; this class makes sure
 *   only ONE network search runs at a time and that outdated queries are skipped, latest wins).
 * - Each add-session keeps the top 4 options of the latest finished search. The renderer can only pick
 *   one of those by (requestId, index); it can never hand the main process a URL.
 * - After a pick, the full details, best cover and screenshots are loaded.
 * No Electron imports here, so it is unit-testable.
 */

export const ORBIT_MAX_OPTIONS = 4;
export const ORBIT_MIN_QUERY = 2;
export const ORBIT_MAX_QUERY = 120;
export const ORBIT_MAX_SCREENSHOTS = 5;
const SESSION_TTL_MS = 10 * 60 * 1000;
const SESSION_MAX = 5;
const CACHE_TTL_MS = 5 * 60 * 1000;
const CACHE_MAX = 40;
const THUMB_TIMEOUT_MS = 5000;
const THUMB_MAX_BYTES = 1_500_000;
export const ORBIT_COVER_MAX_BYTES = 12 * 1024 * 1024;
const SHOT_MAX_BYTES = 8 * 1024 * 1024;
const STORABLE_EXT = new Set(['jpg', 'png', 'webp']);

export interface OrbitApi {
  searchGames(query: string, options?: { limit?: number }): Promise<OrbitSearchResult>;
  getGameDetails(title: string, options?: { steamAppId?: string; extraCoverUrls?: string[] }): Promise<{ record: OrbitRecord | null; notices: string[] }>;
  downloadBestCover(urls: string[]): Promise<OrbitBestCover>;
  downloadImage(url: string): Promise<OrbitImage>;
  describeError(err: unknown): { status: string; message: string };
}

export async function loadDefaultOrbitApi(): Promise<OrbitApi> {
  const lib = await import('./orbit-lib.mjs');
  return {
    searchGames: lib.searchGames,
    getGameDetails: lib.getGameDetails,
    downloadBestCover: lib.downloadBestCover,
    downloadImage: lib.downloadImage,
    describeError: lib.describeError
  };
}

/** What the renderer is allowed to see about one option. */
export interface OrbitOption {
  index: number;
  title: string;
  provider: string;
  alsoOn: string[];
  matchPercent: number;
  thumbnail?: string;
}

export type OrbitSearchOutcome =
  | { status: 'superseded' }
  | { status: 'unknown-session' }
  | { status: 'error'; requestId: number; message: string }
  | {
      status: 'done';
      requestId: number;
      query: string;
      fromCache: boolean;
      options: OrbitOption[];
      providers: Array<{ provider: string; label: string; status: string; itemCount: number }>;
      didYouMean: boolean;
      message?: string;
    };

export interface OrbitLoaded {
  title: string;
  provider: string;
  description: string;
  shortDescription: string;
  genres: string[];
  developers: string[];
  publishers: string[];
  releaseDate: string;
  sourceUrl: string;
  cover: { bytes: Uint8Array; ext: string; width: number; height: number; source: string; fullQuality: boolean } | null;
  screenshots: Array<{ bytes: Uint8Array; ext: string }>;
  notices: string[];
  fetchedAt: string;
}

export type OrbitLoadOutcome =
  | { status: 'loaded'; loaded: OrbitLoaded }
  | { status: 'rejected'; reasons: string[] };

export type OrbitStage = 'details' | 'cover' | 'screenshots' | 'saving';

interface Session {
  latest: number;
  options: { requestId: number; games: OrbitGame[] } | null;
  loading: boolean;
  touchedAt: number;
}

interface CacheEntry {
  at: number;
  games: OrbitGame[];
  options: OrbitOption[];
  providers: OrbitProviderStatus[];
  didYouMean: boolean;
}

export function normalizeQuery(raw: unknown): string {
  return String(raw ?? '').replace(/\s+/g, ' ').trim();
}

function httpsOnly(url: unknown): string | null {
  return typeof url === 'string' && /^https:\/\//i.test(url) ? url : null;
}

export class OrbitSearchService {
  private readonly sessions = new Map<string, Session>();
  private readonly cache = new Map<string, CacheEntry>();
  private tail: Promise<void> = Promise.resolve();
  private api: OrbitApi | null;

  constructor(api?: OrbitApi, private readonly now: () => number = () => Date.now()) {
    this.api = api ?? null;
  }

  private async getApi(): Promise<OrbitApi> {
    if (!this.api) this.api = await loadDefaultOrbitApi();
    return this.api;
  }

  /* ---------------- sessions ---------------- */

  openSession(pendingId: string): void {
    this.purge();
    this.sessions.set(pendingId, { latest: -1, options: null, loading: false, touchedAt: this.now() });
    while (this.sessions.size > SESSION_MAX) {
      const oldest = [...this.sessions.entries()].sort((a, b) => a[1].touchedAt - b[1].touchedAt)[0];
      if (!oldest) break;
      this.sessions.delete(oldest[0]);
    }
  }

  closeSession(pendingId: string): void {
    this.sessions.delete(pendingId);
  }

  hasSession(pendingId: string): boolean {
    this.purge();
    return this.sessions.has(pendingId);
  }

  private purge(): void {
    const t = this.now();
    for (const [id, s] of this.sessions) if (t - s.touchedAt > SESSION_TTL_MS) this.sessions.delete(id);
  }

  /* ---------------- search ---------------- */

  async search(pendingId: string, rawQuery: unknown, requestId: number): Promise<OrbitSearchOutcome> {
    this.purge();
    const session = this.sessions.get(pendingId);
    if (!session) return { status: 'unknown-session' };
    if (!Number.isSafeInteger(requestId) || requestId < 0) return { status: 'error', requestId: -1, message: 'Invalid search request.' };
    if (requestId <= session.latest) return { status: 'superseded' };
    session.latest = requestId;
    session.touchedAt = this.now();

    const query = normalizeQuery(rawQuery);
    if (query.length < ORBIT_MIN_QUERY) return { status: 'error', requestId, message: `Type at least ${ORBIT_MIN_QUERY} characters.` };
    if (query.length > ORBIT_MAX_QUERY) return { status: 'error', requestId, message: `Game name is too long (max ${ORBIT_MAX_QUERY} characters).` };

    // One network search at a time. Queries typed meanwhile wait here and are skipped if a newer one exists.
    const previous = this.tail;
    let release: () => void = () => undefined;
    this.tail = new Promise<void>((resolve) => { release = resolve; });
    try {
      await previous;
      if (this.sessions.get(pendingId) !== session || session.latest !== requestId) return { status: 'superseded' };

      const key = query.toLowerCase();
      const hit = this.cache.get(key);
      if (hit && this.now() - hit.at <= CACHE_TTL_MS) {
        session.options = { requestId, games: hit.games };
        return this.done(requestId, query, true, hit.options, hit.providers, hit.didYouMean);
      }

      const api = await this.getApi();
      const result = await api.searchGames(query, { limit: 5 });
      if (this.sessions.get(pendingId) !== session || session.latest !== requestId) return { status: 'superseded' };

      const games = result.games.slice(0, ORBIT_MAX_OPTIONS);
      const options = await Promise.all(games.map((game, index) => this.toOption(api, game, index)));
      if (this.sessions.get(pendingId) !== session || session.latest !== requestId) return { status: 'superseded' };

      const didYouMean = games.length > 0 && games[0].matchScore < 0.9;
      session.options = { requestId, games };
      // Never cache a result that came from failing providers: one network hiccup must not stick for minutes.
      const healthy = result.providers.every((p) => p.status === 'ok' || p.status === 'needs_config');
      if (healthy && games.length > 0) this.remember(key, { at: this.now(), games, options, providers: result.providers, didYouMean });
      return this.done(requestId, query, false, options, result.providers, didYouMean);
    } catch (err) {
      const api = this.api;
      const message = api ? api.describeError(err).message : err instanceof Error ? err.message : 'Search failed.';
      return { status: 'error', requestId, message };
    } finally {
      release();
    }
  }

  private done(requestId: number, query: string, fromCache: boolean, options: OrbitOption[], providers: OrbitProviderStatus[], didYouMean: boolean): OrbitSearchOutcome {
    const live = providers.filter((p) => p.status === 'ok' || p.status === 'partial').length;
    const usable = providers.filter((p) => p.status !== 'needs_config').length;
    let message: string | undefined;
    if (!options.length) message = live === 0 ? 'No game source answered. Check your internet connection, firewall or antivirus.' : 'No matching game found. Try the full title.';
    return {
      status: 'done',
      requestId,
      query,
      fromCache,
      options,
      providers: providers.map((p) => ({ provider: p.provider, label: p.label, status: p.status, itemCount: p.itemCount })),
      didYouMean,
      message: message ?? (usable > 0 && live < usable && options.length ? `${live}/${usable} sources answered.` : undefined)
    };
  }

  private remember(key: string, entry: CacheEntry): void {
    this.cache.set(key, entry);
    while (this.cache.size > CACHE_MAX) {
      const first = this.cache.keys().next().value;
      if (first === undefined) break;
      this.cache.delete(first);
    }
  }

  private async toOption(api: OrbitApi, game: OrbitGame, index: number): Promise<OrbitOption> {
    return {
      index,
      title: game.title,
      provider: game.provider,
      alsoOn: [...(game.alsoOn ?? [])],
      matchPercent: Math.max(0, Math.min(100, Math.round(game.matchScore * 100))),
      thumbnail: await this.thumbnail(api, game.coverImageUrl)
    };
  }

  private async thumbnail(api: OrbitApi, url: string | null | undefined): Promise<string | undefined> {
    const safe = httpsOnly(url);
    if (!safe) return undefined;
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const image = await Promise.race([
        api.downloadImage(safe),
        new Promise<null>((resolve) => { timer = setTimeout(() => resolve(null), THUMB_TIMEOUT_MS); })
      ]);
      if (!image || !STORABLE_EXT.has(image.ext) || image.buf.byteLength > THUMB_MAX_BYTES) return undefined;
      const mime = image.ext === 'png' ? 'image/png' : image.ext === 'webp' ? 'image/webp' : 'image/jpeg';
      return `data:${mime};base64,${Buffer.from(image.buf).toString('base64')}`;
    } catch {
      return undefined;
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  /* ---------------- pick + load the rest ---------------- */

  async loadSelection(pendingId: string, requestId: number, index: number, onStage?: (stage: OrbitStage, detail?: string) => void): Promise<OrbitLoadOutcome> {
    this.purge();
    const session = this.sessions.get(pendingId);
    if (!session) return { status: 'rejected', reasons: ['This add-game session expired. Start again.'] };
    const shown = session.options;
    if (!shown || shown.requestId !== requestId || !Number.isInteger(index) || index < 0 || index >= shown.games.length) {
      return { status: 'rejected', reasons: ['That option is no longer current. Wait for the search to finish and pick again.'] };
    }
    if (session.loading) return { status: 'rejected', reasons: ['Already loading this game.'] };
    session.loading = true;
    session.touchedAt = this.now();
    try {
      const api = await this.getApi();
      const game = shown.games[index];
      const stage = (s: OrbitStage, d?: string) => { try { onStage?.(s, d); } catch { /* UI progress must never break loading */ } };

      stage('details');
      const steamAppId = game.provider === 'steam' ? game.providerId : game.alternatives?.find((a) => a.provider === 'steam')?.providerId;
      const extraCoverUrls = [game.coverImageUrl, ...(game.alternatives ?? []).map((a) => a.coverImageUrl)].filter((u): u is string => Boolean(httpsOnly(u)));
      const { record, notices } = await api.getGameDetails(game.title, { steamAppId, extraCoverUrls });
      if (!record) return { status: 'rejected', reasons: ['No source returned detail data for this game. Pick another option.', ...notices.slice(0, 2)] };

      const allNotices = [...notices];
      stage('cover');
      let cover: OrbitLoaded['cover'] = null;
      const coverUrls = (record.coverImageCandidates?.length ? record.coverImageCandidates : record.coverImageUrl ? [record.coverImageUrl] : []).filter((u) => Boolean(httpsOnly(u)));
      if (coverUrls.length) {
        try {
          const best = await api.downloadBestCover(coverUrls);
          if (!STORABLE_EXT.has(best.ext)) allNotices.push(`Best cover was a .${best.ext} image, which is not supported for covers. A placeholder is used.`);
          else if (best.buf.byteLength > ORBIT_COVER_MAX_BYTES) allNotices.push('Best cover was too large to store. A placeholder is used.');
          else {
            cover = { bytes: best.buf, ext: best.ext, width: best.width, height: best.height, source: best.source, fullQuality: best.fullQuality };
            if (!best.fullQuality) allNotices.push(`Cover is only ${best.width}x${best.height} (${best.source}); no store had a larger one.`);
          }
        } catch (err) {
          allNotices.push(`Cover not downloaded: ${api.describeError(err).message}`);
        }
      } else {
        allNotices.push('No cover image source was found for this game.');
      }

      const wanted = (record.screenshots ?? []).map((s) => httpsOnly(s.imageUrl)).filter((u): u is string => Boolean(u)).slice(0, ORBIT_MAX_SCREENSHOTS);
      const screenshots: OrbitLoaded['screenshots'] = [];
      if (wanted.length) {
        stage('screenshots', `0/${wanted.length}`);
        const results: Array<{ bytes: Uint8Array; ext: string } | null> = new Array(wanted.length).fill(null);
        let cursor = 0;
        let done = 0;
        const worker = async (): Promise<void> => {
          while (cursor < wanted.length) {
            const i = cursor++;
            try {
              const img = await api.downloadImage(wanted[i]);
              if (STORABLE_EXT.has(img.ext) && img.buf.byteLength <= SHOT_MAX_BYTES) results[i] = { bytes: img.buf, ext: img.ext };
            } catch { /* one missing screenshot is fine */ }
            done += 1;
            stage('screenshots', `${done}/${wanted.length}`);
          }
        };
        await Promise.all(Array.from({ length: Math.min(3, wanted.length) }, () => worker()));
        for (const r of results) if (r) screenshots.push(r);
        if (screenshots.length < wanted.length) allNotices.push(`${wanted.length - screenshots.length} of ${wanted.length} screenshots could not be downloaded.`);
      }

      const sourceUrl = httpsOnly(record.storeUrl) ?? httpsOnly(game.sourceUrl) ?? '';
      return {
        status: 'loaded',
        loaded: {
          title: record.title || game.title,
          provider: game.provider,
          description: record.description || record.shortDescription || '',
          shortDescription: record.shortDescription || '',
          genres: Array.isArray(record.genres) ? record.genres : [],
          developers: Array.isArray(record.developers) ? record.developers : [],
          publishers: Array.isArray(record.publishers) ? record.publishers : [],
          releaseDate: record.releaseDate || '',
          sourceUrl,
          cover,
          screenshots,
          notices: allNotices,
          fetchedAt: record.fetchedAt || new Date(this.now()).toISOString()
        }
      };
    } catch (err) {
      const api = this.api;
      return { status: 'rejected', reasons: [api ? api.describeError(err).message : err instanceof Error ? err.message : 'Loading failed.'] };
    } finally {
      session.loading = false;
    }
  }
}
