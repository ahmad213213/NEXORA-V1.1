import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const ui = path.join(project, 'apps/host/src/ui');

async function read(relative) { return readFile(path.join(ui, relative), 'utf8'); }

test('active renderer is byte-for-byte restored from the user-uploaded NEXORA V1.ZIP', async () => {
  const manifest = JSON.parse(await readFile(path.join(project, 'recovery/original-upload-ui-manifest.json'), 'utf8'));
  assert.equal(manifest.source_archive, 'NEXORA V1.ZIP');
  assert.equal(manifest.source_path_inside_archive, 'Already_Unpacked_App/dist/ui/');
  assert.ok(manifest.file_count >= 40, 'the full renderer and its assets are included');
  for (const item of manifest.files) {
    const bytes = await readFile(path.join(ui, item.path));
    assert.equal(bytes.length, item.size_bytes, `${item.path} size matches original upload`);
    assert.equal(createHash('sha256').update(bytes).digest('hex'), item.sha256, `${item.path} checksum matches original upload`);
  }
});

test('restored original Desktop, Console, Controls and Settings files are loaded as a matched set', async () => {
  const html = await read('index.html');
  assert.match(html, /id="desktop-ui"/);
  assert.match(html, /id="console-ui"/);
  assert.match(html, /id="to-console"[^>]*aria-label="Switch to Console mode"[\s\S]*?assets\/dualsense-mode\.svg/);
  assert.match(html, /data-view="controls"/);
  assert.match(html, /id="mapping-list"/);
  assert.match(html, /id="console-overlay"/);
  for (const file of ['styles.css', 'refinement.css', 'settings-system.css', 'empty-library-backgrounds.css', 'electron-chrome.css']) {
    assert.match(html, new RegExp(`href="${file.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}"`));
    await access(path.join(ui, file));
  }
  for (const file of ['background-rotation.js', 'settings-store.js', 'electron-chrome.js', 'app.js']) {
    assert.match(html, new RegExp(`src="${file.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}"`));
    await access(path.join(ui, file));
  }
  // The Phase 1 redesign overrides are intentionally not active; the uploaded stylesheet stack is.
  assert.doesNotMatch(html, /ui-preserved-controls\.css|phase1-glass\.css/);
});

test('original uploaded background rotation and settings modules are present', async () => {
  const rotation = await read('background-rotation.js');
  const settings = await read('settings-store.js');
  const css = await read('empty-library-backgrounds.css');
  for (const scene of ['space-horizon', 'nebula', 'forest-vista', 'earth-orbit']) {
    assert.ok(rotation.includes(scene), `rotation includes ${scene}`);
    await access(path.join(ui, 'assets/backgrounds', `${scene}.jpg`));
  }
  assert.match(settings, /function sanitise\(/);
  assert.match(settings, /function getBridge\(/);
  assert.match(settings, /localStorage/);
  assert.match(settings, /persistenceQueue/);
  assert.match(css, /--nexora-empty-wallpaper/);
});

test('current main/preload configuration IPC safeguards remain preserved', async () => {
  const main = await readFile(path.join(project, 'apps/host/src/main.ts'), 'utf8');
  const preload = await readFile(path.join(project, 'apps/host/src/preload.cts'), 'utf8');
  for (const channel of ['config:get', 'config:set', 'settings:capabilities', 'settings:export', 'settings:import', 'settings:reset']) {
    assert.ok(main.includes(`ipcMain.handle('${channel}'`), `main process registers ${channel}`);
  }
  for (const method of ['getConfig', 'setConfig', 'getSettingsCapabilities', 'exportSettings', 'importSettings', 'resetSettings']) {
    assert.ok(preload.includes(`${method}:`), `preload exposes ${method}`);
  }
});
