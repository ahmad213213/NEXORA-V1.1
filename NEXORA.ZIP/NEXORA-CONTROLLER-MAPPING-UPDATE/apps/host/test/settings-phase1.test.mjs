import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile, writeFile, mkdir, mkdtemp, rm, readdir } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const hostRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const projectRoot = path.resolve(hostRoot, '../..');
const source = async (relative) => readFile(path.join(projectRoot, relative), 'utf8');
const tempRoot = await mkdtemp(path.join(os.tmpdir(), 'nexora-settings-phase1-'));
const userData = path.join(tempRoot, 'userdata');
await mkdir(userData, { recursive: true });
await mkdir(path.join(tempRoot, 'node_modules', 'electron'), { recursive: true });
await writeFile(
  path.join(tempRoot, 'node_modules', 'electron', 'index.js'),
  "module.exports = { app: { getPath(name) { if (name !== 'userData') throw new Error('Unexpected path request: ' + name); return process.env.NEXORA_CONFIG_TEST_PATH; } } };\n"
);
process.env.NEXORA_CONFIG_TEST_PATH = userData;

const requireFromTest = createRequire(import.meta.url);
const ts = requireFromTest('typescript');
const configSource = await source('apps/host/src/config.ts');
const configOutput = ts.transpileModule(configSource, {
  fileName: 'config.ts',
  compilerOptions: {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.CommonJS,
    moduleResolution: ts.ModuleResolutionKind.Node10,
    esModuleInterop: true
  },
  reportDiagnostics: true
});
const syntaxErrors = (configOutput.diagnostics || []).filter(d => d.category === ts.DiagnosticCategory.Error);
assert.deepEqual(syntaxErrors.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')), [], 'config.ts must transpile without syntax diagnostics');
const configModulePath = path.join(tempRoot, 'config.cjs');
await writeFile(configModulePath, configOutput.outputText);
const config = createRequire(configModulePath)(configModulePath);
const defaults = config.DEFAULT_CONFIG;

after(async () => {
  delete process.env.NEXORA_CONFIG_TEST_PATH;
  await rm(tempRoot, { recursive: true, force: true });
});

test('settings schema provides safe defaults and migrates v2 config', () => {
  const legacy = config.normalize({
    version: 2,
    mode: 'performance',
    qualityPreset: '1080p',
    streaming: { encoder: 'nvenc', ffmpegPath: ' D:/tools/ffmpeg.exe ' }
  });
  assert.equal(legacy.version, 4);
  assert.equal(legacy.profileName, 'My PC');
  assert.equal(legacy.launchMode, 'desktop');
  assert.deepEqual(legacy.appearance, { theme: 'midnight', accent: 'cyan', reducedMotion: false, emptyLibraryBackground: 'space-horizon', rotateEmptyBackground: true });
  assert.equal(legacy.mode, 'performance');
  assert.equal(legacy.qualityPreset, '1080p');
  assert.equal(legacy.video.height, 1080);
  assert.equal(legacy.streaming.encoder, 'nvenc');
  assert.equal(legacy.streaming.ffmpegPath, 'D:/tools/ffmpeg.exe');
});


test('default backgrounds are validated, persisted in appearance, and patch-merged safely', () => {
  const current = config.normalize({ ...defaults, appearance: { ...defaults.appearance, emptyLibraryBackground: 'forest-vista', rotateEmptyBackground: false } });
  assert.equal(current.appearance.emptyLibraryBackground, 'forest-vista');
  assert.equal(current.appearance.rotateEmptyBackground, false);
  const accent = config.mergeConfigPatch(current, { appearance: { accent: 'rose' } });
  assert.equal(accent.appearance.emptyLibraryBackground, 'forest-vista');
  assert.equal(accent.appearance.rotateEmptyBackground, false);
  assert.throws(() => config.mergeConfigPatch(current, { appearance: { emptyLibraryBackground: '../../evil' } }), /unsupported value/);
  assert.throws(() => config.mergeConfigPatch(current, { appearance: { rotateEmptyBackground: 'yes' } }), /true or false/);
  assert.equal(config.normalize({ appearance: { emptyLibraryBackground: 'bad' } }).appearance.emptyLibraryBackground, 'space-horizon');
});

test('normalization bounds profile text and rejects unknown preference values', () => {
  const normalized = config.normalize({
    profileName: '  My\u0000 Gaming Rig\n' + 'x'.repeat(80),
    launchMode: 'evil-mode',
    appearance: { theme: 'random', accent: 'neon', reducedMotion: 'true' },
    qualityPreset: '8k',
    streaming: { encoder: 'not-an-encoder', capture: 'unknown', ffmpegPath: ' '.repeat(5), audioDevice: { toString: 'bad' } }
  });
  assert.equal(normalized.profileName.length, 32);
  assert.equal(normalized.profileName.includes('\u0000'), false);
  assert.equal(normalized.launchMode, 'desktop');
  assert.deepEqual(normalized.appearance, defaults.appearance);
  assert.equal(normalized.qualityPreset, '720p');
  assert.equal(normalized.streaming.encoder, 'auto');
  assert.equal(normalized.streaming.capture, 'ddagrab');
  assert.equal(normalized.streaming.ffmpegPath, 'ffmpeg.exe');
  assert.equal(normalized.streaming.audioDevice, null);
});

test('partial updates preserve unrelated top-level and nested settings', () => {
  const current = config.normalize({
    ...defaults,
    profileName: 'Studio PC',
    launchMode: 'console',
    appearance: { theme: 'earth', accent: 'emerald', reducedMotion: true },
    streaming: { capture: 'gdigrab', encoder: 'qsv', ffmpegPath: 'C:/custom/ffmpeg.exe', audioDevice: 'Speakers' }
  });
  const colorChange = config.mergeConfigPatch(current, { appearance: { accent: 'amber' } });
  assert.equal(colorChange.profileName, 'Studio PC');
  assert.equal(colorChange.launchMode, 'console');
  assert.deepEqual(colorChange.appearance, { theme: 'earth', accent: 'amber', reducedMotion: true, emptyLibraryBackground: 'space-horizon', rotateEmptyBackground: true });
  assert.deepEqual(colorChange.streaming, current.streaming);

  const qualityChange = config.mergeConfigPatch(colorChange, { qualityPreset: '1080p' });
  assert.equal(qualityChange.profileName, 'Studio PC');
  assert.equal(qualityChange.launchMode, 'console');
  assert.deepEqual(qualityChange.appearance, colorChange.appearance);
  assert.deepEqual(qualityChange.streaming, current.streaming);
  assert.deepEqual(qualityChange.video, { width: 1920, height: 1080, fps: 60, bitrateKbps: 8000 });

  const streamChange = config.mergeConfigPatch(qualityChange, { streaming: { encoder: 'nvenc' } });
  assert.equal(streamChange.streaming.encoder, 'nvenc');
  assert.equal(streamChange.streaming.capture, 'gdigrab');
  assert.equal(streamChange.streaming.ffmpegPath, 'C:/custom/ffmpeg.exe');
  assert.equal(streamChange.streaming.audioDevice, 'Speakers');
  assert.throws(() => config.mergeConfigPatch(current, null), /Settings must be an object/);
  assert.throws(() => config.mergeConfigPatch(current, { qualityPreset: '8k' }), /unsupported value/);
  assert.throws(() => config.mergeConfigPatch(current, { appearance: { reducedMotion: 'yes' } }), /true or false/);
  assert.throws(() => config.mergeConfigPatch(current, { streaming: { encoder: 'magic' } }), /unsupported value/);
});

test('serialized config persistence survives concurrent saves and restart-style reload', async () => {
  const configs = ['PC One', 'PC Two', 'PC Three', 'PC Four'].map(profileName => ({ ...defaults, profileName }));
  await Promise.all(configs.map(item => config.saveConfig(item)));
  const persisted = await config.loadConfig();
  assert.equal(persisted.profileName, 'PC Four', 'serialized calls must leave the last requested value on disk');
  const files = await readdir(userData);
  assert.equal(files.some(name => name.endsWith('.tmp')), false, 'no temporary save files should remain');

  await writeFile(path.join(userData, 'config.json'), '{broken json', 'utf8');
  const recovered = await config.loadConfig();
  assert.equal(recovered.profileName, 'My PC');
  const afterRecovery = await readdir(userData);
  assert.ok(afterRecovery.some(name => name.startsWith('config.invalid.')), 'invalid config should be quarantined, not silently reused');
});

test('Settings safety remains present alongside the restored original renderer', async () => {
  const main = await source('apps/host/src/main.ts');
  const preload = await source('apps/host/src/preload.cts');
  const types = await source('apps/host/src/types.d.ts');
  const settingsStore = await source('apps/host/src/ui/settings-store.js');
  const settingsCss = await source('apps/host/src/ui/settings-system.css');
  const appJs = await source('apps/host/src/ui/app.js');

  for (const channel of ['settings:capabilities', 'settings:export', 'settings:import', 'settings:reset']) {
    assert.ok(main.includes(`ipcMain.handle('${channel}'`), `main process registers ${channel}`);
    assert.ok(preload.includes(`ipcRenderer.invoke('${channel}'`), `preload exposes ${channel}`);
  }
  assert.match(main, /ipcMain\.handle\('config:set',[\s\S]*?isTrustedSender\(event\)/);
  for (const method of ['getSettingsCapabilities', 'exportSettings', 'importSettings', 'resetSettings']) assert.ok(types.includes(`${method}:`));
  for (const category of ['General', 'Appearance', 'Streaming', 'Network', 'Updates', 'Privacy & security']) assert.ok(settingsStore.includes(category));
  assert.match(settingsStore, /function sanitise\(/);
  assert.match(settingsStore, /function getBridge\(/);
  assert.match(settingsStore, /localStorage/);
  assert.match(settingsStore, /persistenceQueue/);
  assert.ok(settingsCss.includes('settings-nav'));
  assert.doesNotMatch((await source('apps/host/src/ui/index.html')), /ui-preserved-controls\.css|phase1-glass\.css/);
  assert.doesNotThrow(() => new vm.Script(appJs, { filename: 'app.js' }), 'original renderer JS must remain syntactically valid');
});
