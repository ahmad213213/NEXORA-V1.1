import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, mkdtemp, mkdir, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
const read = p => readFile(path.join(root, p), 'utf8');

test('updater scripts accept the installer exe name NEXORA.exe', async () => {
  for (const f of ['apply-local-update.ps1', 'apply-update.ps1']) {
    const s = await read(`scripts/release/${f}`);
    assert.match(s, /function Find-AppExe/);
    assert.match(s, /'NEXORA\.exe'/);
    assert.doesNotMatch(s, /Join-Path \$InstallDir 'NEXORA-Host\.exe'/);
  }
});

test('installer bundles shared without relying on node_modules', async t => {
  if (!existsSync(path.join(root, 'make-installer.bat'))) { t.skip('installer BAT intentionally deferred from Phase 0 preview-only package'); return; }
  const bat = await read('make-installer.bat');
  assert.match(bat, /vendor-shared\.mjs/);
  assert.doesNotMatch(bat, /node_modules\\@nexora/);
  assert.match(bat, /signAndEditExecutable: false/);
});

test('vendor-shared rewrites bare imports to relative paths', async () => {
  const tmp = await mkdtemp(path.join(os.tmpdir(), 'nx-vendor-'));
  const sharedDist = path.join(tmp, 'shared-dist');
  await mkdir(sharedDist, { recursive: true });
  await writeFile(path.join(sharedDist, 'index.js'), 'export const X = 1;\n');
  await mkdir(path.join(tmp, 'app', 'dist', 'input'), { recursive: true });
  await writeFile(path.join(tmp, 'app', 'dist', 'main.js'), "import { X } from '@nexora/shared';\n");
  await writeFile(path.join(tmp, 'app', 'dist', 'input', 'a.js'), "const m = await import('@nexora/shared');\n");
  execFileSync(process.execPath, [path.join(root, 'scripts/release/vendor-shared.mjs'), path.join(tmp, 'app'), sharedDist]);
  assert.match(await readFile(path.join(tmp, 'app/dist/main.js'), 'utf8'), /from '\.\/_shared\/index\.js'/);
  assert.match(await readFile(path.join(tmp, 'app/dist/input/a.js'), 'utf8'), /import\('\.\.\/_shared\/index\.js'\)/);
});
