import test from 'node:test';
import assert from 'node:assert/strict';
import { OrbitSearchService, ORBIT_MAX_OPTIONS } from '../dist/orbit/orbit-search.js';

const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(40)]);
const PID = 'game_' + 'a'.repeat(24);
const sleep = ms => new Promise(r => setTimeout(r, ms));

const game = (n, extra = {}) => ({
  id: `steam:${n}`, provider: 'steam', providerId: String(n), title: `Game ${n}`, sourceUrl: `https://store.steampowered.com/app/${n}/`,
  coverImageUrl: `https://cdn.example.com/${n}.png`, matchScore: 1 - n / 20, alsoOn: ['gog'], alternatives: [], ...extra
});
const okProviders = [{ provider: 'steam', label: 'Steam Store', itemCount: 5, status: 'ok' }, { provider: 'rawg', label: 'RAWG', itemCount: 0, status: 'needs_config' }];

function fakeApi(overrides = {}) {
  const calls = { search: [], details: [], images: [] };
  const api = {
    calls,
    async searchGames(query, opts) {
      calls.search.push({ query, opts });
      if (overrides.searchDelay) await sleep(overrides.searchDelay);
      return { query, expandedQueries: [], fuzzy: false, hiddenLowMatches: 0, providers: overrides.providers ?? okProviders, games: overrides.games ?? [1, 2, 3, 4, 5].map(n => game(n)) };
    },
    async getGameDetails(title, opts) {
      calls.details.push({ title, opts });
      return overrides.details ?? {
        record: {
          title: 'Game 1', storeUrl: 'https://store.steampowered.com/app/1/', coverImageCandidates: ['https://cdn.example.com/c1.png', 'https://cdn.example.com/c2.png'],
          shortDescription: 'short', description: 'long description of the game', releaseDate: '2020', developers: ['Dev'], publishers: ['Pub'], genres: ['Action'],
          screenshots: [1, 2, 3, 4, 5, 6].map(n => ({ thumbnailUrl: '', imageUrl: `https://cdn.example.com/s${n}.png` })), fetchedAt: '2026-10-08T00:00:00.000Z'
        },
        notices: ['RAWG is optional']
      };
    },
    async downloadBestCover(urls) {
      calls.images.push(['cover', urls]);
      if (overrides.cover) return overrides.cover(urls);
      return { buf: PNG, ext: 'png', url: urls[0], width: 600, height: 900, orientation: 'portrait', source: 'Steam', fullQuality: false, tried: urls.length, downloaded: 1 };
    },
    async downloadImage(url) {
      calls.images.push(['img', url]);
      if (overrides.image) return overrides.image(url);
      if (/s3\.png$/.test(url)) throw new Error('boom');
      return { buf: PNG, ext: 'png', url, width: 10, height: 10 };
    },
    describeError: err => ({ status: 'error', message: err instanceof Error ? err.message : String(err) })
  };
  return api;
}

test('search returns at most 3 options with thumbnails and keeps only that in the renderer view', async () => {
  const api = fakeApi();
  const svc = new OrbitSearchService(api);
  svc.openSession(PID);
  const out = await svc.search(PID, '  game   one ', 1);
  assert.equal(out.status, 'done');
  assert.equal(out.options.length, ORBIT_MAX_OPTIONS);
  assert.equal(out.query, 'game one');
  assert.match(out.options[0].thumbnail, /^data:image\/png;base64,/);
  assert.deepEqual(Object.keys(out.options[0]).sort(), ['alsoOn', 'index', 'matchPercent', 'provider', 'thumbnail', 'title']);
  assert.equal(api.calls.search[0].opts.limit, 5);
});

test('latest query wins: only one network search at a time and outdated queries are skipped', async () => {
  const api = fakeApi({ searchDelay: 30 });
  const svc = new OrbitSearchService(api);
  svc.openSession(PID);
  const [a, b, c] = await Promise.all([svc.search(PID, 'ha', 1), svc.search(PID, 'had', 2), svc.search(PID, 'hades', 3)]);
  assert.equal(b.status, 'superseded');
  assert.equal(c.status, 'done');
  assert.equal(c.query, 'hades');
  assert.ok(['done', 'superseded'].includes(a.status));
  assert.ok(api.calls.search.length <= 2, `expected <=2 network searches, got ${api.calls.search.length}`);
  assert.equal(api.calls.search.at(-1).query, 'hades');
  const old = await svc.search(PID, 'zzz', 2);
  assert.equal(old.status, 'superseded');
});

test('healthy results are cached, results from failing providers are not', async () => {
  const healthy = fakeApi();
  const s1 = new OrbitSearchService(healthy);
  s1.openSession(PID);
  await s1.search(PID, 'Hades', 1);
  const again = await s1.search(PID, 'hades', 2);
  assert.equal(again.fromCache, true);
  assert.equal(healthy.calls.search.length, 1);

  const flaky = fakeApi({ providers: [{ provider: 'steam', label: 'Steam', itemCount: 0, status: 'unreachable', message: 'timeout' }, ...okProviders] });
  const s2 = new OrbitSearchService(flaky);
  s2.openSession(PID);
  await s2.search(PID, 'Hades', 1);
  const second = await s2.search(PID, 'Hades', 2);
  assert.equal(second.fromCache, false);
  assert.equal(flaky.calls.search.length, 2);
});

test('too short / unknown session / provider crash are handled without throwing', async () => {
  const svc = new OrbitSearchService(fakeApi());
  assert.equal((await svc.search(PID, 'hades', 1)).status, 'unknown-session');
  svc.openSession(PID);
  assert.equal((await svc.search(PID, 'h', 1)).status, 'error');
  const crash = new OrbitSearchService({ ...fakeApi(), searchGames: async () => { throw new Error('network down'); } });
  crash.openSession(PID);
  const out = await crash.search(PID, 'hades', 1);
  assert.equal(out.status, 'error');
  assert.match(out.message, /network down/);
});

test('no result gives a readable message and no options', async () => {
  const svc = new OrbitSearchService(fakeApi({ games: [] }));
  svc.openSession(PID);
  const out = await svc.search(PID, 'qqqqqq', 1);
  assert.equal(out.status, 'done');
  assert.equal(out.options.length, 0);
  assert.match(out.message, /No matching game/);
});

test('thumbnails ignore non-https, non-image, oversized and slow images', async () => {
  const games = [game(1, { coverImageUrl: 'http://insecure.example/1.png' }), game(2, { coverImageUrl: 'https://cdn.example.com/2.gif' }), game(3, { coverImageUrl: null })];
  const api = fakeApi({ games, image: async url => ({ buf: PNG, ext: 'gif', url, width: 1, height: 1 }) });
  const svc = new OrbitSearchService(api);
  svc.openSession(PID);
  const out = await svc.search(PID, 'game', 1);
  assert.ok(out.options.every(o => o.thumbnail === undefined));
});

test('choosing loads details, best cover and up to 5 screenshots; a failed screenshot only adds a notice', async () => {
  const api = fakeApi();
  const svc = new OrbitSearchService(api);
  svc.openSession(PID);
  const found = await svc.search(PID, 'game', 7);
  const stages = [];
  const res = await svc.loadSelection(PID, found.requestId, 0, (s, d) => stages.push(`${s}${d ? ':' + d : ''}`));
  assert.equal(res.status, 'loaded');
  assert.equal(res.loaded.title, 'Game 1');
  assert.equal(res.loaded.cover.ext, 'png');
  assert.equal(res.loaded.screenshots.length, 4); // 5 requested, #3 failed
  assert.ok(res.loaded.notices.some(n => /screenshots could not be downloaded/.test(n)));
  assert.ok(res.loaded.notices.some(n => /only 600x900/.test(n)));
  assert.equal(api.calls.details[0].opts.steamAppId, '1');
  assert.deepEqual(stages.filter(s => !s.includes(':')), ['details', 'cover']);
  assert.ok(stages.some(s => s === 'screenshots:5/5'));
});

test('choosing rejects stale request ids, bad indexes and double loads', async () => {
  const svc = new OrbitSearchService(fakeApi());
  svc.openSession(PID);
  const found = await svc.search(PID, 'game', 4);
  assert.equal((await svc.loadSelection(PID, 3, 0)).status, 'rejected');
  assert.equal((await svc.loadSelection(PID, found.requestId, 4)).status, 'rejected');
  assert.equal((await svc.loadSelection(PID, found.requestId, -1)).status, 'rejected');
  assert.equal((await svc.loadSelection(PID, found.requestId, 1.5)).status, 'rejected');
  const [one, two] = await Promise.all([svc.loadSelection(PID, found.requestId, 0), svc.loadSelection(PID, found.requestId, 0)]);
  assert.deepEqual([one.status, two.status].sort(), ['loaded', 'rejected']);
  svc.closeSession(PID);
  assert.equal((await svc.loadSelection(PID, found.requestId, 0)).status, 'rejected');
});

test('unsupported or missing covers do not block the game; no detail data rejects with a reason', async () => {
  const gif = fakeApi({ cover: async urls => ({ buf: PNG, ext: 'gif', url: urls[0], width: 1, height: 1, orientation: '', source: 'x', fullQuality: true, tried: 1, downloaded: 1 }) });
  const svc = new OrbitSearchService(gif);
  svc.openSession(PID);
  const f = await svc.search(PID, 'game', 1);
  const r = await svc.loadSelection(PID, f.requestId, 0);
  assert.equal(r.status, 'loaded');
  assert.equal(r.loaded.cover, null);
  assert.ok(r.loaded.notices.some(n => /not supported for covers/.test(n)));

  const none = new OrbitSearchService(fakeApi({ details: { record: null, notices: ['Steam did not return a detail record'] } }));
  none.openSession(PID);
  const f2 = await none.search(PID, 'game', 1);
  const r2 = await none.loadSelection(PID, f2.requestId, 0);
  assert.equal(r2.status, 'rejected');
  assert.match(r2.reasons[0], /No source returned detail data/);
});

test('sessions expire', async () => {
  let t = 1_000_000;
  const svc = new OrbitSearchService(fakeApi(), () => t);
  svc.openSession(PID);
  assert.equal(svc.hasSession(PID), true);
  t += 11 * 60 * 1000;
  assert.equal(svc.hasSession(PID), false);
});
