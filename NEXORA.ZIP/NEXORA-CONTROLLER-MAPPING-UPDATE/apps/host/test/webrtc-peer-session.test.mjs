import test from 'node:test';
import assert from 'node:assert/strict';
import { WebRtcPeerSession } from '../dist/webrtc/peer-session.js';

function fakeTransport() {
  const calls = [];
  return {
    calls,
    async createOffer(){ calls.push('offer'); return {type:'offer',sdp:'v=0\r\n'}; },
    async createAnswer(){ calls.push('answer'); return {type:'answer',sdp:'v=0\r\n'}; },
    async setLocalDescription(d){ calls.push(['local',d.type]); },
    async setRemoteDescription(d){ calls.push(['remote',d.type]); },
    async addIceCandidate(c){ calls.push(['ice',c.candidate]); },
    async close(){ calls.push('close'); }
  };
}

test('offer/answer flow reaches connected', async () => {
  const a = fakeTransport(); const b = fakeTransport();
  const host = new WebRtcPeerSession(a); const receiver = new WebRtcPeerSession(b);
  const offer = await host.createOffer();
  const answer = await receiver.acceptOffer(offer);
  await host.acceptAnswer(answer);
  assert.equal(host.getState(), 'connected');
  assert.equal(receiver.getState(), 'connecting');
});

test('oversized SDP is rejected before transport mutation', async () => {
  const t = fakeTransport(); const p = new WebRtcPeerSession(t);
  await assert.rejects(() => p.acceptOffer({type:'offer', sdp:'x'.repeat(256*1024+1)}));
  assert.deepEqual(t.calls, []);
});

test('close is idempotent', async () => {
  const t = fakeTransport(); const p = new WebRtcPeerSession(t);
  await p.close(); await p.close();
  assert.equal(t.calls.filter(x => x === 'close').length, 1);
  await assert.rejects(() => p.createOffer(), /closed/);
});
