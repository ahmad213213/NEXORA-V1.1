import test from 'node:test';
import assert from 'node:assert/strict';
import { InputManager } from '../dist/input/input-manager.js';

function event(sequence, action='down') {
  return { kind:'gamepad-button', action, code:'A', sequence, timestamp:Date.now() };
}

test('integration input boundary rejects replay and preserves ordering', async () => {
  const sent=[];
  const manager=new InputManager({send:async e=>sent.push(e),releaseAll:async()=>{}});
  assert.equal(await manager.handle(event(1)), true);
  assert.equal(await manager.handle(event(1)), false);
  assert.equal(await manager.handle(event(0)), false);
  assert.equal(await manager.handle(event(2,'up')), true);
  assert.deepEqual(sent.map(x=>x.sequence), [1,2]);
});
