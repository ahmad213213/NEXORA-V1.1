import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import { mkdtemp, readFile } from 'node:fs/promises';
import { loadOrCreateIdentity, verifySignature, sessionSignatureBytes } from '../dist/networking/security.js';
import { PairingStore, PinManager } from '../dist/networking/pairing.js';
import { SessionSecurity } from '../dist/networking/session-security.js';

test('identity is persistent, self-consistent and signs/verifies', async () => {
  const d = await mkdtemp(path.join(os.tmpdir(), 'nexora-id-')); const a = await loadOrCreateIdentity(d); const b = await loadOrCreateIdentity(d);
  assert.equal(a.deviceId, b.deviceId); const bytes = Buffer.from('hello'); const sig = a.sign(bytes); assert.equal(verifySignature(a.publicKey, bytes, sig), true); assert.equal(verifySignature(a.publicKey, Buffer.from('tampered'), sig), false);
});

test('pairing PIN is six digits, single-use and rate limited', () => {
  const p = new PinManager(60_000, 2, 10_000); const o = p.open(1000); assert.match(o.pin, /^\d{6}$/); assert.equal(p.consume('000000','ip',1001), 'invalid'); assert.equal(p.consume('111111','ip',1002), 'rate_limited'); assert.equal(p.consume(o.pin,'ip',1003), 'rate_limited');
  const q = new PinManager(60_000, 5, 10_000); const x = q.open(1000); assert.equal(q.consume(x.pin,'ip',1001), 'accepted'); assert.equal(q.consume(x.pin,'ip',1002), 'expired');
});

test('paired device persistence and revocation work', async () => {
  const d = await mkdtemp(path.join(os.tmpdir(), 'nexora-pair-')); const p = new PairingStore(d); await p.init(); const dev = { deviceId:'a'.repeat(32), publicKey:'A'.repeat(43), name:'Phone', pairedAt:1, lastSeenAt:null }; await p.authorize(dev); assert.equal(p.isAuthorized(dev.deviceId), true); const raw = JSON.parse(await readFile(path.join(d,'paired-devices.json'),'utf8')); assert.equal(raw.length,1); await p.revoke(dev.deviceId,2); assert.equal(p.isAuthorized(dev.deviceId), false);
});

test('session security binds peer, session, sequence, timestamp and signature', async () => {
  const d = await mkdtemp(path.join(os.tmpdir(), 'nexora-sec-')); const id = await loadOrCreateIdentity(d); const peer = await loadOrCreateIdentity(await mkdtemp(path.join(os.tmpdir(), 'nexora-peer-'))); const s = new SessionSecurity('sess_abcdefgh', id.deviceId, peer.deviceId, 1); s.transition('negotiating');
  const payload={candidate:'x'}; const seq=1; const sig=peer.sign(sessionSignatureBytes({type:'ice.candidate',from:peer.deviceId,to:id.deviceId,sessionId:s.sessionId,sequence:seq,payload,protocolVersion:1})); const msg={protocol:'NEXORA',version:1,type:'ice.candidate',sessionId:s.sessionId,sequence:seq,timestamp:1000,from:peer.deviceId,to:id.deviceId,payload,signature:sig}; assert.equal(s.validateInbound(msg,peer.publicKey,1000),true); assert.equal(s.validateInbound(msg,peer.publicKey,1000),false); assert.equal(s.validateInbound({...msg,sequence:2,to:'b'.repeat(32)},peer.publicKey,1000),false);
});

test('signaling core enforces authorization, single-use session opens and signed relay', async () => {
  const { SignalingCore } = await import('../dist/networking/signaling-core.js');
  const { loadOrCreateIdentity, authBytes, sessionSignatureBytes } = await import('../dist/networking/security.js');
  const a=await mkdtemp(path.join(os.tmpdir(),'nexora-host-')); const b=await mkdtemp(path.join(os.tmpdir(),'nexora-phone-')); const host=await loadOrCreateIdentity(a); const phone=await loadOrCreateIdentity(b); const c=new SignalingCore();
  assert.equal(c.authenticate({role:'host',deviceId:host.deviceId,publicKey:host.publicKey,name:'PC'},'n',host.sign(authBytes('host',host.deviceId,'n',1))),true);
  assert.equal(c.authenticate({role:'receiver',deviceId:phone.deviceId,publicKey:phone.publicKey,name:'Phone'},'m',phone.sign(authBytes('receiver',phone.deviceId,'m',1))),true);
  const pin=c.openPairing(host.deviceId,0); const req=c.requestPair(phone.deviceId,pin.pin,'ip',1); assert.equal(req?.type,'pair.request'); assert.equal(c.approvePair(host.deviceId,phone.deviceId,true)?.type,'pair.accept');
  const payload={requestedAt:2}; const sig=phone.sign(sessionSignatureBytes({type:'session.open',from:phone.deviceId,to:host.deviceId,sessionId:'sess_abcdefgh',sequence:1,payload,protocolVersion:1})); assert.ok(c.openSession(phone.deviceId,host.deviceId,'sess_abcdefgh',1,sig,payload)); assert.equal(c.openSession(phone.deviceId,host.deviceId,'sess_abcdefgh',1,sig,payload),null);
  const rp={candidate:'x'}; const rs=phone.sign(sessionSignatureBytes({type:'ice.candidate',from:phone.deviceId,to:host.deviceId,sessionId:'sess_abcdefgh',sequence:2,payload:rp,protocolVersion:1})); assert.equal(c.relay(phone.deviceId,'ice.candidate','sess_abcdefgh',host.deviceId,2,rs,rp)?.type,'ice.candidate');
});
