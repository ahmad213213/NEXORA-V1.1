import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const ui = path.join(project, 'apps/host/src/ui');

test('active UI is restored byte-for-byte from the uploaded renderer', async () => {
  const manifest = JSON.parse(await readFile(path.join(project, 'recovery/original-upload-ui-manifest.json'), 'utf8'));
  for (const item of manifest.files) {
    const bytes = await readFile(path.join(ui, item.path));
    assert.equal(bytes.length, item.size_bytes, `${item.path} size matches`);
    assert.equal(createHash('sha256').update(bytes).digest('hex'), item.sha256, `${item.path} matches uploaded renderer`);
  }
});

test('original background rotation and settings resources are active', async () => {
  const html = await readFile(path.join(ui, 'index.html'), 'utf8');
  const rotation = await readFile(path.join(ui, 'background-rotation.js'), 'utf8');
  const settings = await readFile(path.join(ui, 'settings-store.js'), 'utf8');
  assert.match(html, /background-rotation\.js/);
  assert.match(html, /settings-store\.js/);
  for (const scene of ['space-horizon', 'nebula', 'forest-vista', 'earth-orbit']) {
    assert.ok(rotation.includes(scene));
    await access(path.join(ui, 'assets/backgrounds', `${scene}.jpg`));
  }
  for (const category of ['General', 'Appearance', 'Streaming', 'Network', 'Updates', 'Privacy & security']) assert.ok(settings.includes(category));
});

test('original Desktop/Console UI retains the controller switch and Controls mapping layout', async () => {
  const html = await readFile(path.join(ui, 'index.html'), 'utf8');
  const css = await readFile(path.join(ui, 'styles.css'), 'utf8');
  assert.match(html, /id="to-console"[^>]*aria-label="Switch to Console mode"[\s\S]*?assets\/dualsense-mode\.svg/);
  assert.match(html, /data-view="controls"/);
  assert.match(html, /id="mapping-list"/);
  assert.match(css, /\.mode-switch/);
});
