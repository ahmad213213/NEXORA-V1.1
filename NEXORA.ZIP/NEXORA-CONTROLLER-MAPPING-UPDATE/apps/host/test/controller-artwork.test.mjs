import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const ui = path.resolve(here, '..', 'src', 'ui');
const read = (...parts) => readFile(path.join(...parts), 'utf8');

test('controller art uses separate sourced local-first images with a safe local fallback', async () => {
  const js = await read(ui, 'app.js');
  assert.match(js, /playstation-dualsense\.png/);
  assert.match(js, /xbox-wireless\.png/);
  assert.match(js, /www\.citypng\.com/);
  assert.match(js, /img\.itch\.zone/);
  assert.ok(js.includes('assets/dualsense-mode.svg'));
  assert.ok(js.includes('assets/xbox-controller.svg'));
  assert.match(js, /function setControllerArtwork/);
});

test('controller buttons are hit targets inside the same square artwork canvas', async () => {
  const html = await read(ui, 'index.html');
  const css = await read(ui, 'refinement.css');
  assert.match(html, /class="controller-art" id="controller-art"/);
  assert.match(html, /class="controller-hotspot face south"/);
  assert.doesNotMatch(html, /mapping-wire|The line will connect/);
  assert.match(css, /controller-art\{[^}]*aspect-ratio:1\/1/);
  assert.match(css, /data-family="xbox"[^\n]*controller-hotspot\.face\.south\{left:71\.7%;top:42\.5%\}/);
  assert.match(css, /data-family="playstation"[^\n]*controller-hotspot\.face\.south\{left:75\.8%;top:45\.9%\}/);
  assert.match(css, /data-family="xbox"[^\n]*controller-hotspot\.face\.north\{left:71\.7%;top:31\.5%\}/);
  assert.match(css, /\.controller-hotspot\{[^}]*background:transparent;box-shadow:none/);
  assert.doesNotMatch(css, /\.mapping-wire/);
});

test('controller artwork downloader validates image bytes before replacement', async () => {
  const root = path.resolve(here, '..', '..', '..');
  const script = await readFile(path.join(root, 'scripts', 'download-controller-artwork.ps1'), 'utf8');
  assert.match(script, /Invoke-WebRequest/);
  assert.match(script, /PNG/);
  assert.match(script, /Get-FileHash/);
  assert.match(script, /Move-Item -LiteralPath \$temporary/);
});
