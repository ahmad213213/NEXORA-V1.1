import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const host = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const project = path.resolve(host, '../..');
const ui = path.join(project, 'apps/host/src/ui');

test('restored uploaded UI keeps the original Desktop/Console switch and controller artwork', async () => {
  const html = await readFile(path.join(ui, 'index.html'), 'utf8');
  const css = await readFile(path.join(ui, 'styles.css'), 'utf8');
  const icon = path.join(ui, 'assets/dualsense-mode.svg');
  await access(icon);
  assert.match(html, /id="to-console"[^>]*aria-label="Switch to Console mode"[\s\S]*?mode-controller-art[^>]*src="assets\/dualsense-mode\.svg"/);
  assert.match(css, /\.mode-switch/);
  assert.match(await readFile(icon, 'utf8'), /<svg[\s\S]*?viewBox="0 0 72 46"/);
  assert.match(html, /id="desktop-ui"[\s\S]*id="console-ui"/);
});

test('restored UI retains original controls mapping, window chrome, and settings modules', async () => {
  const html = await readFile(path.join(ui, 'index.html'), 'utf8');
  const app = await readFile(path.join(ui, 'app.js'), 'utf8');
  const settings = await readFile(path.join(ui, 'settings-store.js'), 'utf8');
  for (const id of ['active-controller-image', 'mapping-list', 'mapping-save-status', 'console-overlay']) assert.ok(html.includes(`id="${id}"`), `${id} exists`);
  assert.match(html, /data-view="controls"/);
  assert.match(html, /electron-chrome\.css/);
  assert.match(html, /settings-store\.js/);
  assert.match(app, /getKeyMap/);
  assert.match(settings, /Appearance/);
  assert.match(settings, /General/);
  assert.match(settings, /Streaming/);
  assert.match(settings, /Network/);
  assert.match(settings, /Updates/);
  assert.match(settings, /Privacy & security/);
});
