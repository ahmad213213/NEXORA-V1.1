import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyConnectionHealth } from '../dist/integration/health.js';

test('excellent health stays excellent', () => {
  assert.equal(classifyConnectionHealth({ rttMs: 28, packetLossPct: 0.1, jitterMs: 4, encodeFps: 60, decodeFps: 59 }).health, 'excellent');
});

test('degraded conditions are classified conservatively', () => {
  assert.equal(classifyConnectionHealth({ rttMs: 110, packetLossPct: 0.2, jitterMs: 8, encodeFps: 60, decodeFps: 56 }).health, 'degraded');
});

test('poor conditions include loss and high latency', () => {
  assert.equal(classifyConnectionHealth({ rttMs: 180, packetLossPct: 4, jitterMs: 55, encodeFps: 60, decodeFps: 40 }).health, 'poor');
});

test('invalid measurements are normalized safely', () => {
  const result = classifyConnectionHealth({ rttMs: -1, packetLossPct: Number.NaN, jitterMs: Infinity });
  assert.deepEqual(result, { health: 'excellent', rttMs: 0, packetLossPct: 0, jitterMs: 0, fpsDropPct: 0 });
});
