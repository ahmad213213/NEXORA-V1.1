plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.nexora.receiver"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexora.receiver"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
        debug { applicationIdSuffix = ".debug" }
    }
}

dependencies {
    // Pinned WebRTC AAR; media is peer-to-peer and never routed through signaling.
    implementation("org.webrtc:google-webrtc:1.0.32006")
}

kotlin { jvmToolchain(17) }
