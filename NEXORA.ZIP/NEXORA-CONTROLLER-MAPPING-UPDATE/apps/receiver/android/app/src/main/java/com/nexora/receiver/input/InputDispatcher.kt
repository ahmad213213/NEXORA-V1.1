package com.nexora.receiver.input

interface InputDispatcher { fun dispatch(event: InputEvent) }

class SequencedInputDispatcher(private val transport: (InputEvent) -> Unit) : InputDispatcher {
    private var sequence = 0L
    private val pressed = HashSet<String>()
    override fun dispatch(event: InputEvent) {
        if (event.sequence <= sequence) return
        sequence = event.sequence
        val key = "${event.kind}:${event.code}"
        when (event.action) { "down" -> pressed.add(key); "up" -> pressed.remove(key) }
        transport(event)
    }
    fun releaseAll(now: Long) {
        pressed.toList().forEach { key ->
            val parts = key.split(':', limit = 2)
            transport(InputEvent(parts[0], "up", parts[1], sequence = ++sequence, timestamp = now))
        }
        pressed.clear()
    }
}
