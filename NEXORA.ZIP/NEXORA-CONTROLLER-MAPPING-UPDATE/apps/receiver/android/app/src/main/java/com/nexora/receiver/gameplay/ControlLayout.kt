package com.nexora.receiver.gameplay
data class ControlLayoutItem(val id:String,val type:String,val action:String,val label:String,val x:Float,val y:Float,val width:Float,val height:Float,val opacity:Float,val z:Int)
data class ControlLayout(val id:String,val name:String,val genre:String,val version:Int,val controls:List<ControlLayoutItem>)
object DefaultLayouts {
    fun action() = ControlLayout("layout_action","Action Default","action",1,listOf(
        ControlLayoutItem("dpad","dpad","move","D-PAD",.06f,.62f,.18f,.30f,.78f,1),
        ControlLayoutItem("a","button","A","A",.82f,.66f,.07f,.10f,.82f,1),
        ControlLayoutItem("b","button","B","B",.73f,.76f,.07f,.10f,.82f,1),
        ControlLayoutItem("x","button","X","X",.73f,.56f,.07f,.10f,.82f,1),
        ControlLayoutItem("y","button","Y","Y",.82f,.46f,.07f,.10f,.82f,1),
        ControlLayoutItem("l1","trigger","L1","L1",.06f,.06f,.16f,.09f,.70f,1),
        ControlLayoutItem("r1","trigger","R1","R1",.78f,.06f,.16f,.09f,.70f,1)
    ))
}
