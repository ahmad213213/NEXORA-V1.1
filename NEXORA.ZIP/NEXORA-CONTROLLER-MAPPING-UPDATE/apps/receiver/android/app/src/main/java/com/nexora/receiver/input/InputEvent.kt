package com.nexora.receiver.input

data class InputEvent(
    val kind: String,
    val action: String,
    val code: String,
    val value: Float? = null,
    val x: Float? = null,
    val y: Float? = null,
    val sequence: Long,
    val timestamp: Long
)
