# Controller artwork sources and use notes

The Controls page uses two real controller pictures sourced from the web. It tries the locally cached PNG first, then the remote image URL, then the existing in-app SVG as a last-resort fallback. Run `scripts/download-controller-artwork.ps1` on Windows with internet access to download the PNGs into `apps/host/src/ui/assets/controllers/` for local/offline use. The script validates PNG signatures before replacing a destination file and records SHA-256 hashes.

## PlayStation DualSense
- Image URL: https://www.citypng.com/public/uploads/preview/sony-playstation5-ps5-white-controller-design-701751695142717blpzualcqv.png?v=2026010405
- Source page: https://www.citypng.com/photo/851/sony-playstation5-ps5-white-controller-design
- The source page describes the image as a transparent 2000 × 2000 PNG and states personal use only; commercial use is not authorized by that source.

## Xbox wireless controller
- Image URL: https://img.itch.zone/aW1nLzI0NzM5OTIyLnBuZw%3D%3D/original/qbTOf3.png
- Source page: https://zj-goloyogo.itch.io/balete-mansion-2
- This is an image hosted by the referenced itch.io page. The source page does not provide a clear standalone license for this image; permission for redistribution has not been independently verified.

## Practical note
The editing environment could not resolve the image-host domains, so the actual PNG files could not be bundled in this ZIP. The app will request the remote PNGs when online, and the included PowerShell script lets you cache them locally from Windows. No downloaded image binaries are being represented as included when they are not.

Only the Controls/controller artwork and its specific CSP allowlist were modified for this task. The rest of the original NEXORA UI is unchanged.
