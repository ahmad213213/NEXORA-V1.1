# NEXORA — Phase 0 Rechecked Source Package

This is the current cumulative NEXORA source workspace. After the Phase 1 UI regression, the active renderer at `apps/host/src/ui/` was restored byte-for-byte from the exact user-uploaded `NEXORA V1.ZIP` renderer tree. The alternate renderer from the prior Phase 1 package is preserved only in `recovery/phase1-ui-before-restore/` for recovery. The separate frosted-glass prototype remains in `design-reference/` and must not overwrite the active renderer.

## Current Phase 0 result

**Source consolidation: performed. Formal Phase 0 acceptance: still blocked.** The workspace root is identified and a clean package inventory is included. Node/pnpm/Electron/TypeScript version pins are recorded. The root `test` command now builds both workspace packages before attempting tests, which addresses a reproducibility defect found during this recheck.

The required `pnpm-lock.yaml` is still absent. Creating a truthful lockfile requires pnpm resolving the workspace against the package registry; this execution environment cannot reach `registry.npmjs.org`. A lockfile was not fabricated. Consequently dependency installation, clean workspace build/typecheck and the built-source full test suite are still blocked pending a network-enabled Windows/development machine.

## Project layout

- `apps/host/` — Electron main process, preload, live renderer, systems, and host tests.
- `apps/receiver/android/` — Android receiver source and Gradle configuration.
- `packages/shared/` — shared protocol and input contracts/tests.
- `scripts/` — static source verifiers and release-support scripts.
- `design-reference/current-frosted-glass-ui-prototype/` — separate visual reference; it is not the active renderer.
- `recovery/phase1-ui-before-restore/` — exact backup of the alternate renderer that was active before the user's original UI was restored.
- `recovery/original-upload-ui-manifest.json` — byte-level hashes/sizes proving the active UI files match the uploaded archive.
- `design-reference/previews/` — UI reference screenshots.
- `docs/` — architecture, source map, phase checks, integration specs, and the new Phase 0 recheck/build reports.
- `baseline/` — untouched copies of the exact uploaded `NEXORA V1.ZIP` and the source bundle used as the starting point for this recheck. These are audit backups, not alternative project roots.

## Current source-of-truth root

After extraction, open the folder containing this `README.md`. Do not use the contents of `baseline/NEXORA-V1-UPLOADED-ARCHIVE-UNMODIFIED.zip` as the source tree: that archive is an installed-app reconstruction containing compiled `dist` files, not the complete development project.

## Preview

On Windows, double-click `PREVIEW.bat`. It opens the live renderer HTML in the default browser; it is not the full Electron runtime and cannot verify native IPC, window chrome, streaming, pairing, or Android behavior.

## Checks

See:
- `UI-RESTORATION-FROM-ORIGINAL-UPLOAD.md` — restoration details and file-by-file integrity checks.

- `docs/PHASE0-RECHECK-REPORT.md` — findings, exact artifact identities, and pass/fail/blocker decisions.
- `docs/PHASE0-CHECKS.md` — current test and static-check results.
- `docs/BUILD-AND-TEST-GUIDE.md` — reproducible setup commands and lockfile recovery.
- `docs/CURRENT-SOURCE-INVENTORY.csv` — current delivery inventory. `docs/PHASE0-SOURCE-INVENTORY.csv` is the earlier Phase 0 audit snapshot.
- `PHASE0-RECHECKED-PACKAGE-MANIFEST.sha256` — SHA-256 manifest for this delivery's files (excluding the manifest file itself).

No installer or program-build BAT is included; `PREVIEW.bat` remains the only root-level BAT file, in line with the existing project scope.
