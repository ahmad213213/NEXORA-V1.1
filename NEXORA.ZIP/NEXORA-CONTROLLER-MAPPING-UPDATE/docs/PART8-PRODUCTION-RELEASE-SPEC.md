# NEXORA Part 8 — Production / Release System

Part 8 closes the planned rebuild with production-safe release infrastructure.

## Update model
1. Host downloads a signed HTTPS manifest.
2. Manifest is schema/product/platform/version validated.
3. Ed25519 signature is verified before an update is considered valid.
4. Package is downloaded to a versioned temporary staging directory.
5. Size and SHA-256 are checked before launch.
6. An external PowerShell updater is detached from the Host process.
7. Host exits cleanly.
8. Updater waits for the old PID to disappear, verifies the package again, stages it, swaps the installation directory, and launches the new executable.
9. Failed replacement attempts restore the previous installation when possible.

The updater is deliberately outside the Electron process so locked application files are not replaced while the app is running.

## Release signing
`create-manifest.mjs` creates the unsigned manifest. `sign-manifest.mjs` signs its canonical payload using an Ed25519 private key supplied only at release time. The private key is never stored in the application repository.

Before a real public release, replace the runtime public-key placeholder in `apps/host/src/update/manifest.ts` with the release public key.

## Portable package contract
A Windows release package must contain:
- `NEXORA-Host.exe`
- Electron application files
- `vendor/ffmpeg.exe`
- required resources

The portable package must not depend on a developer's Node, pnpm, or global FFmpeg installation.
