# NEXORA Final Recheck (hardened)

## Result
Static checks: **16/16 PASS** (final recheck), foundation 7/7, release 9/9.

## Bugs fixed in this pass
1. `publicGame` fully typed (no more `any`).
2. Pending metadata Map: 5-minute TTL + max 20 entries (purge on add/select).
3. `renderView` visibility rewritten with a single clear policy.
4. Cover fallback is neutral `placeholder.svg` (not RDR2).
5. Steam metadata search parallelized (concurrency 3).
6. Controls no longer mutates opacity as a fake "edit".
7. `engines.node >= 22` set in package.json.
8. Bitrate floor lowered to 500 kbps; default quality 720p30 @ 2500 kbps for weak links.
9. ABR: aggressive drop / cautious climb, jitter-aware, shorter drop cooldown.
10. FFmpeg: lower bitrate floor, tighter GOP for lower latency.

## Low-latency / low-Mbps hardening
- Default stream: 1280×720 @ 30 fps, 2500 kbps (usable on ~3–6 Mbps).
- ABR min 500 kbps, fast drop on loss/RTT/jitter, slow climb when healthy.
- Encoder args already use zerolatency / ultrafast / no B-frames / short keyint.
- ICE config validation unchanged (STUN/TURN allowlist).

## Still external (cannot be pure-TS)
- Native `nexora-sendinput` addon
- Real RTP → WebRTC track publisher
- Production WSS signaling + Android auth
- Real-device NAT/TURN matrix

Application contracts, security boundaries, library, UI, and ABR policy are hardened.
