# NEXORA AI Patcher

## Workflow
1. Open the AI Patcher navigation item.
2. Select the root directory of the source project.
3. Select a provider and model ID, save its API key, then describe the bug/change.
4. Approve sending source context to the provider.
5. Review the proposed file-by-file diff.
6. Explicitly apply the patch. Existing files are backed up first, and files changed after proposal generation are rejected to avoid overwriting newer edits.
7. Run `typecheck`, `build`, or `test` from the app after confirming that you trust the selected project's scripts. If the result is bad, use **Rollback last patch**.

## Providers
- Gemini API: default model ID `gemini-3.7-flash`. Check the current API free-tier quota and data-use terms.
- OpenRouter: default model ID `openrouter/free`, a router that selects from available free models. The specific model can vary.
- Groq: default model ID `openai/gpt-oss-120b`. Check the account's pricing before use; do not assume API calls are free.

## Safety boundaries
- Provider API keys are encrypted using Electron `safeStorage` and stored per provider in the app's user data directory.
- The renderer never receives stored API keys.
- Source upload requires an explicit confirmation.
- The context collector is bounded and skips dependency/generated folders, lockfiles, environment files, and common key/credential files.
- The model cannot directly execute commands. Only explicit UI actions can apply a patch or run one of the fixed check names (`typecheck`, `build`, `test`). Project scripts can still execute code, so only run checks for projects you trust.
- Paths must be relative and cannot traverse outside the selected workspace. Symlinks and directories are rejected as patch targets. The patch engine hashes files before proposal generation and refuses stale changes.
- Apply is approval-gated, creates a backup, and rolls back partial writes on an apply error. The UI offers rollback of the latest successful patch.

This is a source-code patch assistant, not a guarantee that generated code is correct. Review the diff and run the project's checks before relying on a patch.
