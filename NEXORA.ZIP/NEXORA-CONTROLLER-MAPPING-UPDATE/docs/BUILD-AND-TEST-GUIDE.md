# NEXORA — Build and Test Guide

## Prerequisites

- Windows 10/11 development machine for the intended Electron runtime and installer acceptance.
- Node.js 22 or newer.
- Corepack (ships with supported Node.js distributions) and network access to the npm registry for the first pnpm setup and dependency resolution.
- Android Studio/Gradle and an Android device or emulator only for later receiver verification.

The repository pins `pnpm@10.17.1` in the root `package.json`. Electron, TypeScript, `@types/node`, and electron-builder versions are pinned in workspace package metadata. `pnpm-lock.yaml` is not included because it could not be generated without registry access; this is an open Phase 0 blocker.

## First bootstrap (run on a network-enabled development machine)

Open PowerShell in the folder containing the root `package.json`.

```powershell
node --version
corepack --version
corepack prepare pnpm@10.17.1 --activate
pnpm --version
```

Generate the lockfile from the pinned workspace manifests, then inspect the diff before accepting it:

```powershell
pnpm install --lockfile-only
Test-Path .\pnpm-lock.yaml
git diff -- .\pnpm-lock.yaml
```

After reviewing the generated lockfile, preserve it in the project. Subsequent clean installs should use the lockfile strictly:

```powershell
pnpm install --frozen-lockfile
```

Do not invent a lockfile by hand or silently regenerate it during a normal build. If dependency manifests change later, deliberately update and review the lockfile.

## Repeatable verification commands

```powershell
node .\scripts\phase0-preflight.mjs
pnpm build
pnpm typecheck
pnpm test
pnpm verify:phase0
pnpm verify:phase1
pnpm verify
pnpm verify:part3
pnpm verify:part4
pnpm verify:part6
pnpm verify:part7
pnpm verify:part8
pnpm verify:integration
pnpm verify:integration:stage2
pnpm verify:integration-stage3
pnpm verify:integration-stage4
pnpm verify:integration-stage5
pnpm verify:final-release
```

The root `test` script first invokes `pnpm build`, because the workspace tests import compiled modules from `apps/host/dist` and `packages/shared/dist`. Running `node --test` directly against a fresh source-only tree before building will predictably fail tests that import those absent generated files.

## Preview versus real runtime

`PREVIEW.bat` opens the live renderer HTML in the browser. It is useful for checking HTML/CSS/renderer layout only. It does not emulate Electron IPC, native window controls, game launching, system permissions, capture, signaling, WebRTC, Android input or updater operations.

No program-build or installer batch file is included in this delivery. Windows package generation and install/upgrade/uninstall acceptance must be performed later as a separate release step, with logs and an actual generated artifact.

## Non-destructive rules

- Do not run install/build/test from the `baseline/` ZIP files; work from the extracted project root.
- Do not delete user data, app configuration, paired-device identity, credentials, or the last successful installer to make a build pass.
- Keep build outputs in normal ignored `dist/` folders; stage release artifacts separately.
- Report passed, failed, skipped and environment-blocked results separately.

## Phase 1 checks

The live renderer stylesheet, background settings, Controls/Key Mapping routes and controller visual choices are covered by:

```sh
node --check apps/host/src/ui/app.js
node --test apps/host/test/phase1-live-ui.test.mjs apps/host/test/ui-shell-phase1.test.mjs apps/host/test/settings-phase1.test.mjs apps/host/test/phase1-completion.test.mjs
```

Then, on a network-enabled development machine, use the pinned package manager and a reviewed lockfile to run `pnpm install --frozen-lockfile`, `pnpm build`, `pnpm typecheck`, and `pnpm test`. Launch Electron and test preference persistence across restart; browser preview does not verify Electron IPC or native window controls. Current details: `docs/PHASE1-COMPLETION-REPORT.md`.
