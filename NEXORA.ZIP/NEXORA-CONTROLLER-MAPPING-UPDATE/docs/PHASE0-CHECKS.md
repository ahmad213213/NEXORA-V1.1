# NEXORA Phase 0 — Recheck and Test Report

This report reflects commands actually rerun against the cumulative source tree used for this delivery. Static checks do not prove full runtime functionality.

## Passed

| Check | Current result |
|---|---|
| Uploaded `NEXORA V1.ZIP` ZIP integrity | Passed; 216 files, 6,242,229 uncompressed bytes |
| Uploaded archive JavaScript syntax | 64 `.js`/`.mjs`/`.cjs` files checked, 0 syntax failures |
| Final `NEXORA-PHASE0-RECHECKED.zip` archive integrity | Passed after packaging and again after extraction check |
| `scripts/phase0-preflight.mjs` | 41 pass conditions, 0 failures; current delivery manifest verified 258/258 entries; one expected warning for the missing lockfile |
| Static verifier scripts | 14 distinct verifier scripts passed; 152 aggregate checks according to verifier summaries |
| Focused live UI / shell / Settings tests | 10/10 passed |
| Live renderer JavaScript syntax | Passed |
| Starting source package integrity manifest before this recheck | 250/250 file entries matched `PHASE1-UI-RESTORE-MANIFEST.sha256` |
| Root package metadata | Valid JSON; pins `pnpm@10.17.1`, Electron `38.2.0`, TypeScript `5.9.2`, `@types/node` `24.0.0`, and `electron-builder` `26.0.12` |
| Root test command | Corrected in this recheck to run `pnpm build` before `node --test` |

## Failed or blocked

| Check | Result / reason |
|---|---|
| `pnpm-lock.yaml` | Missing; Corepack attempted `https://registry.npmjs.org/pnpm/-/pnpm-10.17.1.tgz` but DNS failed with `EAI_AGAIN` |
| Dependency installation | Blocked because pinned pnpm could not be downloaded from the registry |
| Full direct test run without build | 58 passed, 14 failed, 3 skipped out of 75; all 14 failures were `ERR_MODULE_NOT_FOUND` for ungenerated `apps/host/dist` or `packages/shared/dist` files |
| Strict TypeScript workspace check | Blocked: a scratch-copy `tsc -b --pretty false` using the environment's unpinned global TypeScript exited with TS2688 because `@types/node` is not installed; project-pinned TypeScript 5.9.2 is unavailable |
| Clean workspace build after lockfile install | Blocked: pnpm/dependencies unavailable |
| Real Electron runtime | Not run in this environment |
| Windows installer install/upgrade/uninstall | Not run; no installer BAT was added or claimed built |

## Historical manifest note

The pre-existing `PHASE0-SOURCE-MANIFEST.sha256` and `docs/PHASE0-BASELINE-SHA256.txt` are retained as historical records of earlier checkpoints. The Phase 1 UI restoration modified a limited set of live UI/documentation/package files, so those historical hashes are not expected to describe every current file. The untouched starting archive is separately preserved; the pre-recheck current package's `PHASE1-UI-RESTORE-MANIFEST.sha256` matched all 250 listed file entries. The new `PHASE0-RECHECKED-PACKAGE-MANIFEST.sha256` verifies 258/258 entries in the final delivery.
