# NEXORA Phase 0 — Baseline Identity

This record distinguishes the exact archive uploaded by the user from the source archive used to perform this recheck.

## Exact user upload / GitHub file

- Name: `NEXORA V1.ZIP`
- Compressed bytes: `5,377,893`
- SHA-256: `217cff3f1edff82035fb8556298e23f5e89dba70e10c641ae41a5d4284acca7f`
- GitHub repository: `ahmad213213/NEXORA-V1`
- GitHub blob SHA-1: `d94f734188f14d1277c076ebe8daaa37770b0df5`
- Local Git-compatible blob check: `git hash-object` produced the same SHA-1 `d94f734188f14d1277c076ebe8daaa37770b0df5`.
- ZIP contents: 216 files, 6,242,229 bytes uncompressed, all entries pass `unzip -t`. Its payload is limited to `Already_Unpacked_App/dist/` and `Already_Unpacked_App/package.json`; 50 `.js.map` files contain no `sourcesContent`. It is an installed-app reconstruction/compiled output snapshot, not the full development project.
- The exact archive is preserved byte-for-byte at `baseline/NEXORA-V1-UPLOADED-ARCHIVE-UNMODIFIED.zip`.

## Source project archive used for this recheck

- Name: `NEXORA-PHASE1-UI-RESTORED.zip` (prior cumulative source package; retained unmodified)
- Compressed bytes: `11,962,805`
- SHA-256: `2f8900951339ca074d1b2438df2902435334bed63047c078a2fe7a0aa6644175`
- Archive contents include Electron TypeScript/renderer source, Android receiver source, shared workspace package, tests, scripts, docs, visual previews, and the separate current frosted-glass prototype.
- The exact archive is preserved byte-for-byte at `baseline/NEXORA-PHASE1-UI-RESTORED-SOURCE-BASELINE-UNMODIFIED.zip`.

## Toolchain recorded during recheck

- Node.js: `v22.16.0`
- npm: `10.9.2`
- Corepack: `0.32.0`
- Declared package manager: `pnpm@10.17.1` (not available locally; Corepack download failed with `EAI_AGAIN registry.npmjs.org`)
- Declared Electron: `38.2.0`
- Declared TypeScript: `5.9.2`
- Declared `@types/node`: `24.0.0`
- Declared electron-builder: `26.0.12`

The installed global `tsc` in this environment reports `5.8.3`, not the project-pinned `5.9.2`. It is not treated as a successful project typecheck.
