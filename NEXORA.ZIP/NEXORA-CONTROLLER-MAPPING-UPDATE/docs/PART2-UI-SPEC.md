# NEXORA Part 2 — UI/UX specification

## Visual source of truth
The approved NEXORA reference image defines the visual target: cinematic full-screen artwork, premium glass panels, left navigation, central hero/game area, right-side quick connect/system information, recent games, and a persistent bottom streaming bar.

The reference is **not embedded as the UI**. Every surface is implemented as real HTML/CSS components. Local SVG artwork is only placeholder content for the Part 2 visual shell; real game metadata/artwork belongs to Part 3.

## Performance rules
- No `backdrop-filter`.
- No CSS blur filters.
- No continuous large-area transforms.
- `contain: layout paint` / `contain: paint` on expensive isolated regions.
- Horizontal game cards use fixed/minimum widths and cannot shrink.
- Animations are short state transitions only.
- No per-frame JavaScript rendering loop.
- Clock updates every 30 seconds, not every frame.
- UI interactions update only the affected DOM state.
- No remote fonts, remote images, CDN scripts, or runtime web requests.

## Component map
- Sidebar: branding, primary navigation, pinned games, host profile.
- Top bar: connection status, compact actions, clock.
- Hero: current game, metadata, description, primary play action.
- Recently Played: non-wrapping horizontal game strip.
- Control Dashboard: glass feature panel for streaming/control status.
- System Usage: CPU/GPU/RAM rings and stream diagnostics.
- Quick Connect: six-digit PIN input shell.
- Game Info: selected-game summary and control entry point.
- Stream bar: persistent host/game/quality/audio controls.

## Integration boundary
Part 2 intentionally does not implement game lookup, streaming, pairing, input injection, or system telemetry. Buttons are deterministic UI states until Parts 3–7 connect them to real services.
