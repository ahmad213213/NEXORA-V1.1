# NEXORA Part 3 — Game Library / Metadata

Part 3 connects the Part 2 launcher surface to a real, persistent Windows game library.

## Flow

EXE selection → pending game → provider search → global ranking → metadata acceptance gate → verified cover → atomic library commit → UI update.

A selected executable is **never permanently added before metadata verification**.

## Acceptance gate

A candidate must have:
- reliable title evidence,
- known game type,
- meaningful description,
- verified Windows compatibility,
- HTTPS source identity,
- image bytes matching a supported PNG/JPEG/WebP signature.

Failed lookup/validation leaves the library unchanged.

## Ambiguity

If multiple strong candidates are close in global score, NEXORA keeps the executable pending and presents a selection dialog. The user must explicitly select a candidate before commit.

## Persistence

- `library.json` is written atomically.
- Covers are stored separately under the NEXORA user-data directory.
- A failed library write removes the newly written cover and leaves the previous library intact.
- Duplicate executable paths are rejected before another metadata lookup.

## Provider boundary

The provider interface is independent from the library. Part 3 ships a Steam Store provider using HTTPS, bounded timeouts, platform/type validation, and a cover-host allowlist. More providers can be added without changing the library contract.

## UI

Part 2's game strip, pinned rail, hero metadata, and library status are now driven by verified library records. Game names/descriptions are inserted with DOM text APIs rather than HTML interpolation.
