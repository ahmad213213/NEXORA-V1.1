# Part 8 Verification

Static and runtime checks cover:
- semver parsing/comparison
- manifest validation
- HTTPS-only update URLs
- SHA-256 package verification
- signature verification path
- staging path isolation
- external updater script presence
- rollback logic presence
- release manifest generation/signing scripts
- portable-package FFmpeg contract
- Part 1–7 regression scripts

Windows-only checks remain target-machine checks: Electron packaging, PowerShell updater execution, actual replacement of locked Windows binaries, bundled FFmpeg startup, GPU encoders, and Android Gradle/APK generation.
