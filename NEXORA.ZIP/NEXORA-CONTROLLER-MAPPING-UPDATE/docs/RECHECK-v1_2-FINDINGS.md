# Recheck findings (v1.2 installer/typefix)

Fixed
1. Preload was ES module under sandbox:true -> window.nexora never existed (UI dead). Now preload.cts -> preload.cjs; main.ts loads preload.cjs; tsconfig includes *.cts; regression test preload-format.test.mjs.
2. Installer app package.json lacked "type": "module" (installed app could not start).
3. Installer YAML used backslash Windows paths in double quotes (invalid escapes) -> forward slashes.
4. Installer config written inside ( ) blocks broke on folder names containing ")" -> line-by-line writes.
5. Installer scripts moved from resources/ to project root.
6. Android app/build.gradle.kts re-declared the Kotlin plugin version already set in the root build file (Gradle error) -> version removed.

Not verified (no Windows/Android SDK/network here)
- Real Electron/@types/node typecheck, pnpm install, electron-builder packaging, Gradle build, actual app launch.
- Whether electron-builder keeps the hand-staged node_modules/@nexora/shared (not declared as a dependency in the staged package.json).
- Real WebRTC media, ViGEm virtual gamepad, SendInput: native addons are optional and not present.

## Second recheck fixes
1. In-app Patch/Restore and online updater looked for NEXORA-Host.exe, but the installer produces NEXORA.exe -> scripts now accept either (Find-AppExe); BOM added so the progress window text is not garbled.
2. @nexora/shared was hand-copied into node_modules (electron-builder may prune it) -> now bundled into dist/_shared with imports rewritten (scripts/release/vendor-shared.mjs).
3. Installer config: signAndEditExecutable false (avoids the common winCodeSign symlink failure on Windows without admin).
4. Host tsconfig now lists "types": ["node"]; root package.json lets pnpm 10 run electron's postinstall; stale tsbuildinfo files removed from the zip.
5. New regression test: apps/host/test/installer-fixes.test.mjs.

Still open (needs real work, not a quick fix)
- main.ts does not start streaming, signaling, WebRTC or the connection flow; no signaling server exists in the repo; Android app has no pairing/connect screen.
- ffmpeg and native input modules not bundled; no app icon.
- Not verified without Windows/network: pnpm install, electron-builder, real launch, Gradle build.
