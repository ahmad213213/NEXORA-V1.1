NEXORA WINDOWS INSTALLER — DEFERRED TO RELEASE PHASE

This Phase 1 delivery focuses on the live UI integration and Settings source. It intentionally does not include a program-build or installer batch file. Only PREVIEW.bat is provided at the project root.

Do not treat the source ZIP as a prebuilt Windows application. Before creating an installer, the project needs a reproducible dependency lockfile, a successful workspace typecheck/build, a live Electron smoke test, and a Windows packaging run. The previously reported NSIS StdUtils.nsh issue remains a later release task.

For now, use PREVIEW.bat to inspect the live renderer visually in a browser. Electron-only actions need the actual Electron host.
